#ifndef AST_H
#define AST_H

#include <memory>
#include <vector>
#include <string>
#include <variant>
#include <optional>
#include <unordered_map>
#include <map>
#include <set>
#include <sstream>
#include <algorithm>
#include <stack>
#include <queue>
#include "scanner.hh"
#include "../backend/types.hh"

namespace LM {
namespace Frontend {

// Forward declarations
namespace AST {
    struct Node;
    struct Expression;
    struct Statement;
    struct Program;
    struct ErrorExpr;
    struct BinaryExpr;
    struct UnaryExpr;
    struct LiteralExpr;
    struct VariableExpr;
    struct ThisExpr;
    struct SuperExpr;
    struct CallExpr;
    struct CallClosureExpr;
    struct CastExpr;
    struct AssignExpr;
    struct TernaryExpr;
    struct GroupingExpr;
    struct IndexExpr;
    struct MemberExpr;
    struct ListExpr;
    struct DictExpr;
    struct ObjectLiteralExpr;
    struct FrameInstantiationExpr;
    struct RangeExpr;
    struct ExprStatement;
    struct VarDeclaration;
    struct DestructuringDeclaration;
    struct FunctionDeclaration;
    struct BlockStatement;
    struct IfStatement;
    struct ForStatement;
    struct WhileStatement;
    struct IterStatement;
    struct ReturnStatement;
    struct BreakStatement;
    struct ContinueStatement;
    struct PrintStatement;
    struct HandleClause;
    struct ParallelStatement;
    struct ConcurrentStatement;
    struct TaskStatement;
    struct WorkerStatement;
    struct AwaitExpr;
    struct AsyncFunctionDeclaration;
    struct ImportStatement;
    struct FallibleExpr;
    struct ErrorConstructExpr;
    struct OkConstructExpr;
    struct SomeConstructExpr;
    struct NoneConstructExpr;
    struct EnumDeclaration;
    struct MatchStatement;
    struct MatchCase;
    struct TypePatternExpr;
    struct BindingPatternExpr;
    struct ListPatternExpr;
    struct DictPatternExpr;
    struct TuplePatternExpr;
    struct TupleExpr;
    struct ValPatternExpr;
    struct ErrPatternExpr;
    struct ErrorTypePatternExpr;
    struct LambdaExpr;
    struct TypeAnnotation;
    struct FunctionTypeAnnotation;
    struct StructuralTypeField;
    struct TypeDeclaration;
    struct TraitDeclaration;
    struct InterfaceDeclaration;
    struct FrameDeclaration;
    struct FrameField;
    struct FrameMethod;
    struct ModuleDeclaration;
    struct UnsafeStatement;
    struct ContractStatement;
    struct ComptimeStatement;
    
    // Channel operation nodes
    struct ChannelOfferExpr;
    struct ChannelPollExpr;
    struct ChannelSendExpr;
    struct ChannelRecvExpr;
    
    // Memory operation nodes (inserted by type checker)
    struct MakeLinearExpr;
    struct MakeRefExpr;
    struct MoveExpr;
    struct DropExpr;
}

// AST Node definitions
namespace AST {
    // Visibility levels for module-level declarations and class members
    enum class VisibilityLevel {
        Private,    // Default - no keyword
        Protected,  // prot
        Public,     // pub
        Const       // const (read-only public)
    };

    inline std::string visibilityToString(VisibilityLevel level) {
        switch (level) {
            case VisibilityLevel::Private: return "private";
            case VisibilityLevel::Protected: return "protected";
            case VisibilityLevel::Public: return "public";
            case VisibilityLevel::Const: return "const";
            default: return "unknown";
        }
    }

    // Memory ownership and lifetime information
    struct MemoryInfo {
        std::size_t region_id = 0;           // Which memory region owns this value
        std::size_t generation = 0;          // Generation for reference validity
        bool is_linear = false;              // Is this a linear (move-only) type
        bool is_moved = false;               // Has this linear value been moved
        bool is_reference = false;           // Is this a reference to a linear type
        std::string target_linear_var;       // For references: which linear var do we reference
        int creation_scope = 0;              // Scope level where this was created
        bool needs_drop = false;             // Does this need explicit cleanup
        
        MemoryInfo() = default;
        MemoryInfo(std::size_t rid, std::size_t gen, bool linear = false) 
            : region_id(rid), generation(gen), is_linear(linear) {}
    };

    // Base node type
    struct Node : public std::enable_shared_from_this<Node> {
        int line;
        
        // Inferred type after type checking (null before type checking)
        // For strictly statically typed language, all nodes should have type info
        mutable TypePtr inferred_type = nullptr;
        
        // Memory safety information (set by type checker)
        mutable MemoryInfo memory_info;
        
        virtual ~Node() = default;
    };

    // Base expression type
    struct Expression : public Node {
        // inferred_type is inherited from Node
        
        virtual ~Expression() = default;
    };

    // Error expression for graceful error recovery
    struct ErrorExpr : public Expression {
        std::string message;
        int line;
    };

    // Base statement type
    struct Statement : public Node {
        std::vector<LM::Frontend::Token> annotations;
        // Module/frame-level visibility. Default private per language.md §3.3.2
        // (no explicit 'private' keyword — vars/fns are private when neither
        // pub nor prot is specified).
        VisibilityLevel visibility = VisibilityLevel::Private;

        // inferred_type is inherited from Node
        // For statements, this typically represents the type of value produced by the statement
        // (e.g., return type for return statements, declaration type for var declarations)

        virtual ~Statement() = default;
    };

    // Type annotation structure - forward declaration
    struct TypeAnnotation;
    
    // Field in a structural type
    struct StructuralTypeField {
        std::string name;
        std::shared_ptr<TypeAnnotation> type;
    };
    
    // Function parameter for function type annotations
    struct FunctionParameter {
        std::string name;                                      // Parameter name (optional)
        std::shared_ptr<TypeAnnotation> type;                  // Parameter type
        bool hasDefaultValue = false;                          // Whether parameter has default value
        
        FunctionParameter() = default;
        FunctionParameter(const std::string& n, std::shared_ptr<TypeAnnotation> t) 
            : name(n), type(t) {}
        FunctionParameter(std::shared_ptr<TypeAnnotation> t) 
            : type(t) {}
    };

    // Type annotation structure
    struct TypeAnnotation {
        virtual ~TypeAnnotation() = default;                  // Make polymorphic for dynamic_cast
        
        std::string typeName;                                  // The name of the type (e.g., "int", "str", "Person")
        bool isOptional = false;                               // Whether this is an optional type (e.g., int?)
        bool isPrimitive = false;                              // Whether this is a primitive type (e.g., int, str, bool)
        bool isUserDefined = false;                            // Whether this is a user-defined type (e.g., Person, Vehicle)
        bool isStructural = false;                             // Whether this is a structural type (e.g., { name: str, age: int })
        bool isUnion = false;                                  // Whether this is a union type (e.g., int | str)
        bool isIntersection = false;                           // Whether this is an intersection type (e.g., HasName and HasAge)
        bool isList = false;                                   // Whether this is a list type (e.g., [int], ListOfString)
        bool isDict = false;                                   // Whether this is a dictionary type (e.g., {str: int}, DictOfStrToInt)
        bool isFunction = false;                               // Whether this is a function type
        bool isTuple = false;
        bool isDeferred = false;                                  // Whether this is a tuple type (e.g., (int, str))
        bool isRefined = false;                                // Whether this is a refined type (e.g., int where value > 0)
        bool hasRest = false;                                  // Whether this structural type has a rest parameter (...)
        
        std::string baseRecord = "";                           // Name of the base record for extensible records
        std::vector<std::string> baseRecords;                  // Multiple base records for extensible records
        
        // Enhanced function type support
        std::vector<FunctionParameter> functionParameters;              // Named function parameters with types
        std::vector<std::shared_ptr<TypeAnnotation>> functionParams;    // Legacy function parameters (for backward compatibility)
        std::vector<std::shared_ptr<TypeAnnotation>> unionTypes;        // Types in a union (e.g., int | str)
        std::vector<std::shared_ptr<TypeAnnotation>> tupleTypes;        // Types in a tuple (e.g., (int, str))
        std::vector<std::shared_ptr<TypeAnnotation>> associatedTypes;   // Associated types for type constructors (e.g., Success(str))
        std::vector<StructuralTypeField> structuralFields;              // Fields in a structural type
        
        std::shared_ptr<Expression> refinementCondition = nullptr;      // For refined types (e.g., int where value > 0)
        std::shared_ptr<TypeAnnotation> returnType = nullptr;           // Return type for function types
        std::shared_ptr<TypeAnnotation> elementType = nullptr;          // Element type for list types (e.g., [int])
        std::shared_ptr<TypeAnnotation> keyType = nullptr;              // Key type for dictionary types (e.g., {str: int})
        std::shared_ptr<TypeAnnotation> valueType = nullptr;            // Value type for dictionary types (e.g., {str: int})
        
        // Error handling support
        bool isFallible = false;                                         // Whether this type can fail (Type?)
        std::vector<std::string> errorTypes;                             // Specific error types (Type?Error1, Error2)
    };

    // Function type annotation with specific signature (e.g., fn(a: int, b: str): bool)
    struct FunctionTypeAnnotation : public TypeAnnotation {
        std::vector<FunctionParameter> parameters;                       // Named parameters with types
        std::shared_ptr<TypeAnnotation> returnType;                      // Return type
        bool isVariadic = false;                                         // Whether function accepts variable arguments
        
        FunctionTypeAnnotation() {
            typeName = "function";
            isFunction = true;
        }
        
        // Helper methods
        size_t getParameterCount() const { return parameters.size(); }
        
        bool hasNamedParameters() const {
            return std::any_of(parameters.begin(), parameters.end(),
                             [](const FunctionParameter& param) { return !param.name.empty(); });
        }
        
        std::vector<TypePtr> getParameterTypes() const;  // Convert to TypePtr vector
        
        // Type compatibility checking
        bool isCompatibleWith(const FunctionTypeAnnotation& other) const;
        
        // String representation
        std::string toString() const;
    };

    // Program - the root of our AST
    struct Program : public Node {
        std::vector<std::shared_ptr<Statement>> statements;
        
        // Map of imported symbols: "alias.name" or "name" -> original function/frame declaration
        std::unordered_map<std::string, std::shared_ptr<Statement>> imported_symbols;
    };

    // Binary expression (e.g., a + b, x == y)
    struct BinaryExpr : public Expression {
        std::shared_ptr<Expression> left;
        LM::Frontend::TokenType op;
        std::shared_ptr<Expression> right;
    };

    // Unary expression (e.g., !x, -y)
    struct UnaryExpr : public Expression {
        LM::Frontend::TokenType op;
        std::shared_ptr<Expression> right;
    };

    // Interpolated string expression (e.g., "Hello, {name}!")
    struct InterpolatedStringExpr : public Expression {
        // Each part is either a string literal or an expression
        std::vector<std::variant<std::string, std::shared_ptr<Expression>>> parts;
        
        // Add a string part
        void addStringPart(const std::string& str) {
            parts.push_back(str);
        }
        
        // Add an expression part
        void addExpressionPart(std::shared_ptr<Expression> expr) {
            parts.push_back(expr);
        }
    };

    // Literal values (numbers, strings, booleans, nil)
    struct LiteralExpr : public Expression {
        std::variant<std::string, bool, std::nullptr_t> value;
        LM::Frontend::TokenType literalType = LM::Frontend::TokenType::STRING; // Store the original token type for type inference
    };

    // Variable reference
    struct VariableExpr : public Expression {
        std::string name;
    };

    // 'self' reference in methods
    struct ThisExpr : public Expression {
        // No additional fields needed, just represents 'self'
    };

    // 'super' reference for parent class access
    struct SuperExpr : public Expression {
        // No additional fields needed, just represents 'super'
    };

    // Function call
    struct CallExpr : public Expression {
        std::shared_ptr<Expression> callee;
        std::vector<std::shared_ptr<Expression>> arguments;
        std::unordered_map<std::string, std::shared_ptr<Expression>> namedArgs;
    };

    // Closure call (for calling closure variables)
    struct CallClosureExpr : public Expression {
        std::shared_ptr<Expression> closure;  // The closure expression to call
        std::vector<std::shared_ptr<Expression>> arguments;
        std::unordered_map<std::string, std::shared_ptr<Expression>> namedArgs;
    };

    // Cast expression (e.g., x as int)
    struct CastExpr : public Expression {
        std::shared_ptr<Expression> expression;
        std::shared_ptr<TypeAnnotation> targetType;
    };

    // Assignment expression
    struct AssignExpr : public Expression {
        std::string name;
    // For member or index assignment
    std::shared_ptr<Expression> object;
    std::optional<std::string> member; // for member assignment
    std::shared_ptr<Expression> index; // for index assignment


        std::shared_ptr<Expression> value;
        LM::Frontend::TokenType op = LM::Frontend::TokenType::EQUAL; // Default is simple assignment, but can be +=, -=, etc.
    };

    // Ternary expression (condition ? thenExpr : elseExpr)
    struct TernaryExpr : public Expression {
        std::shared_ptr<Expression> condition;
        std::shared_ptr<Expression> thenBranch;
        std::shared_ptr<Expression> elseBranch;
    };

    // Grouping expression (parenthesized expressions)
    struct GroupingExpr : public Expression {
        std::shared_ptr<Expression> expression;
    };

    // Array/list indexing (arr[idx])
    struct IndexExpr : public Expression {
        std::shared_ptr<Expression> object;
        std::shared_ptr<Expression> index;
    };

    // Member access (obj.member)
    struct MemberExpr : public Expression {
        std::shared_ptr<Expression> object;
        std::string name;
    };

    // List literal [1, 2, 3]
    struct ListExpr : public Expression {
        std::vector<std::shared_ptr<Expression>> elements;
    };

    // Tuple literal (1, 2, 3)
    struct TupleExpr : public Expression {
        std::vector<std::shared_ptr<Expression>> elements;
    };

    // Dictionary literal {'a': 1, 'b': 2}
    struct DictExpr : public Expression {
        std::vector<std::pair<std::shared_ptr<Expression>, std::shared_ptr<Expression>>> entries;
    };
    
    // Object literal with constructor name (e.g., Some { kind: "Some", value: 42 })
    struct ObjectLiteralExpr : public Expression {
        std::string constructorName;
        std::unordered_map<std::string, std::shared_ptr<Expression>> properties;
    };
    
    // Frame instantiation expression (e.g., Point() or Point(x=1, y=2))
    struct FrameInstantiationExpr : public Expression {
        std::string frameName;
        std::vector<std::shared_ptr<Expression>> positionalArgs;  // For positional arguments
        std::unordered_map<std::string, std::shared_ptr<Expression>> namedArgs;  // For named arguments (field=value)
    };
    
    // Range expression (e.g., 1..10)
    struct RangeExpr : public Expression {
        std::shared_ptr<Expression> start;
        std::shared_ptr<Expression> end;
        std::shared_ptr<Expression> step; // Optional step value
        bool inclusive; // Whether the range includes the step value
    };

    // Expression statement
    struct ExprStatement : public Statement {
        std::shared_ptr<Expression> expression;
    };

    // Variable declaration
    struct VarDeclaration : public Statement {
        std::string name;
        std::optional<std::shared_ptr<TypeAnnotation>> type;
        std::shared_ptr<Expression> initializer;

        // Module-level visibility (for module-level variables)
        VisibilityLevel visibility = VisibilityLevel::Private;  // Default to private
        bool isStatic = false;                                  // For static variables
        bool isConst = false;                                   // True for const/val bindings (immutable after init)
    };

    // Destructuring assignment (e.g., var (x, y, z) = tuple)
    struct DestructuringDeclaration : public Statement {
        std::vector<std::string> names;  // Variable names to destructure into
        std::shared_ptr<Expression> initializer;  // The tuple/array expression to destructure
        bool isTuple = true;  // Whether destructuring a tuple (true) or array (false)
    };

    // Function declaration
    struct FunctionDeclaration : public Statement {
        std::string name;
        std::vector<std::pair<std::string, std::shared_ptr<TypeAnnotation>>> params;
        std::vector<std::pair<std::string, std::pair<std::shared_ptr<TypeAnnotation>, std::shared_ptr<Expression>>>> optionalParams;
        std::optional<std::shared_ptr<TypeAnnotation>> returnType;
        std::shared_ptr<BlockStatement> body;
        std::vector<std::string> genericParams;
        bool throws = false;
        
        // Error type annotations for function signature
        bool canFail = false;                                    // Whether function can return errors
        std::vector<std::string> declaredErrorTypes;             // Specific error types function can return
        
        // Module-level visibility (for module-level functions)
        VisibilityLevel visibility = VisibilityLevel::Private;  // Default to private
        bool isStatic = false;                                  // For static functions
        bool isAbstract = false;                                // For abstract functions
        bool isFinal = false;                                   // For final functions
    };

    // Async function declaration
    struct AsyncFunctionDeclaration : public FunctionDeclaration {
        // Constructor that takes a FunctionDeclaration
        AsyncFunctionDeclaration(const FunctionDeclaration& func) {
            name = func.name;
            params = func.params;
            optionalParams = func.optionalParams;
            returnType = func.returnType;
            body = func.body;
            genericParams = func.genericParams;
            throws = func.throws;
            line = func.line;
        }
        
        // Default constructor
        AsyncFunctionDeclaration() = default;
    };

    // Block statement (sequence of statements)
    struct BlockStatement : public Statement {
        std::vector<std::shared_ptr<Statement>> statements;
    };

    // If statement
    struct IfStatement : public Statement {
        std::shared_ptr<Expression> condition;
        std::shared_ptr<Statement> thenBranch;
        std::shared_ptr<Statement> elseBranch;
    };

    // For statement
    struct ForStatement : public Statement {
        // Traditional C-style for loop: for (var i = 0; i < 5; i++)
        std::shared_ptr<Statement> initializer;
        std::shared_ptr<Expression> condition;
        std::shared_ptr<Expression> increment;
        std::shared_ptr<Statement> body;
    };

    // While statement
    struct WhileStatement : public Statement {
        std::shared_ptr<Expression> condition;
        std::shared_ptr<Statement> body;
    };

    // Break statement
    struct BreakStatement : public Statement {};

    // Continue statement
    struct ContinueStatement : public Statement {};

    // Return statement
    struct ReturnStatement : public Statement {
        std::shared_ptr<Expression> value;
    };

    // Print statement
    struct PrintStatement : public Statement {
        std::vector<std::shared_ptr<Expression>> arguments;
    };

    // Concurrency constructs
    struct ParallelStatement : public Statement {
        std::string cores;     // Number of cores to use (or "auto")
        std::string timeout;   // Timeout duration
        std::string grace;     // Grace period for cleanup
        std::string on_error;  // Error handling strategy (Stop, Continue, Partial)
        std::shared_ptr<BlockStatement> body;
    };

    struct ConcurrentStatement : public Statement {
        std::string channel;  // Channel name for communication
        std::string channelParam; // Parameter name for channel (e.g., "ch" in "ch=counts")
        std::string mode;     // Execution mode (batch, stream, async)
        std::string cores;    // Number of cores to use (or "auto")
        std::string onError;  // Error handling strategy
        std::string timeout;  // Timeout duration
        std::string on_error;  // Error handling strategy (Stop, Continue, Partial)
        std::string grace;    // Grace period for cleanup
        std::string onTimeout; // Action on timeout
        std::shared_ptr<BlockStatement> body;
    };

    // Concurrent task statement - for I/O-bound event processing with channels
    struct TaskStatement : public Statement {
        bool isAsync = false;
        std::string loopVar;
        std::shared_ptr<Expression> iterable;
        std::shared_ptr<BlockStatement> body;
        std::string task_function_name; // Name of the compiled task function
        
        // Channel information for this task (concurrent only)
        std::string channel_param; // Channel parameter name (e.g., "ch")
    };

    // Worker statement inside a concurrent block
    struct WorkerStatement : public Statement {
        bool isAsync = false;
        std::string param;
        std::string paramName; // Name of the parameter variable
        std::shared_ptr<Expression> iterable; // Source iterable (array, channel, etc.)
        std::shared_ptr<BlockStatement> body;
        std::string worker_function_name; // Generated function name for LIR
        std::string channel_param; // Channel parameter name (e.g., "ch" in "ch=counts")
    };

    // Await expression
    struct AwaitExpr : public Expression {
        std::shared_ptr<Expression> expression;
    };

    // Channel offer expression - non-blocking send
    struct ChannelOfferExpr : public Expression {
        std::shared_ptr<Expression> value;          // value being sent
        std::shared_ptr<Expression> channel;        // channel expression
    };

    // Channel poll expression - non-blocking receive
    struct ChannelPollExpr : public Expression {
        std::shared_ptr<Expression> channel;        // channel expression
        std::string target;                       // variable to assign
    };

    // Channel send expression - blocking send
    struct ChannelSendExpr : public Expression {
        std::shared_ptr<Expression> value;          // value being sent
        std::shared_ptr<Expression> channel;        // channel expression
    };

    // Channel receive expression - blocking receive
    struct ChannelRecvExpr : public Expression {
        std::shared_ptr<Expression> channel;        // channel expression
        std::string target;                       // variable to assign
    };

    // Import statement filter type
    enum class ImportFilterType {
        Show,
        Hide
    };

    // Import statement filter
    struct ImportFilter {
        ImportFilterType type;
        std::vector<std::string> identifiers;
    };

    // Import statement
    struct ImportStatement : public Statement {
        std::string modulePath;
        bool isStringLiteralPath = false;
        std::optional<std::string> alias;
        std::optional<ImportFilter> filter;
    };

    // Enum declaration
    struct EnumDeclaration : public Statement {
        std::string name;
        std::vector<std::pair<std::string, std::vector<std::shared_ptr<TypeAnnotation>>>> variants;
    };

    // Pattern matching
    struct BindingPatternExpr;
    struct ListPatternExpr;
    struct OrPatternExpr;  // forward-declare

    struct MatchCase {
        std::shared_ptr<Expression> pattern;
        std::shared_ptr<Expression> guard;
        std::shared_ptr<Statement> body;
    };

    struct MatchStatement : public Statement {
        std::shared_ptr<Expression> value;
        std::vector<MatchCase> cases;
    };

    // Type pattern in a match statement
    struct TypePatternExpr : public Expression {
        std::shared_ptr<TypeAnnotation> type;
    };

    // Or-pattern: A | B | C — matches if any of the inner patterns matches.
    struct OrPatternExpr : public Expression {
        std::vector<std::shared_ptr<Expression>> patterns;
    };

    // Binding pattern in a match statement (e.g., Some(x))
    struct BindingPatternExpr : public Expression {
        std::string typeName;
        std::vector<std::shared_ptr<Expression>> patterns;
    };

    // List pattern in a match statement (e.g., [x, ...xs])
    struct ListPatternExpr : public Expression {
        std::vector<std::shared_ptr<Expression>> elements;
        std::optional<std::string> restElement;
    };

    // Dictionary/Record destructuring pattern (e.g., {name, age} or {name: x, age: y})
    struct DictPatternExpr : public Expression {
        struct Field {
            std::string key;
            std::shared_ptr<Expression> pattern; // If empty, use key as binding name
        };
        std::vector<Field> fields;
        bool hasRestElement = false;
        std::optional<std::string> restBinding;
    };

    // Tuple destructuring pattern (e.g., (x, y, z))
    struct TuplePatternExpr : public Expression {
        std::vector<std::shared_ptr<Expression>> elements;
    };

    // Error pattern matching expressions
    
    // Success value pattern (val identifier)
    struct ValPatternExpr : public Expression {
        std::string variableName;
    };

    // Error pattern (err identifier)
    struct ErrPatternExpr : public Expression {
        std::string variableName;
        std::optional<std::string> errorType;  // Optional specific error type
    };

    // Specific error type pattern (ErrorType or ErrorType(params))
    struct ErrorTypePatternExpr : public Expression {
        std::string errorType;
        std::vector<std::string> parameterNames;  // For extracting error parameters
    };
    
    // Type declaration (type aliases)
    struct TypeDeclaration : public Statement {
        std::string name;
        std::shared_ptr<TypeAnnotation> type;
    };
    
    // Trait declaration
    struct TraitDeclaration : public Statement {
        std::string name;
        std::vector<std::shared_ptr<FunctionDeclaration>> methods;
        std::vector<std::string> extends;  // Trait inheritance
        bool isOpen = false;
        
        // JIT Focus: Dynamic dispatch info
        std::vector<std::string> method_names;
    };
    
    // Frame field with visibility and default values
    struct FrameField {
        std::string name;
        std::shared_ptr<TypeAnnotation> type;
        VisibilityLevel visibility;
        std::shared_ptr<Expression> defaultValue;  // Optional default value
        bool isConst = false;                      // True for const/val fields (immutable after init)

        FrameField() : visibility(VisibilityLevel::Private), defaultValue(nullptr), isConst(false) {}
        FrameField(const std::string& n, std::shared_ptr<TypeAnnotation> t,
                   VisibilityLevel v = VisibilityLevel::Private)
            : name(n), type(t), visibility(v), defaultValue(nullptr), isConst(false) {}
    };

    // Frame method with visibility
    struct FrameMethod : public Statement {
        std::string name;
        std::shared_ptr<TypeAnnotation> returnType;
        std::vector<std::pair<std::string, std::shared_ptr<TypeAnnotation>>> parameters;
        std::vector<std::pair<std::string, std::pair<std::shared_ptr<TypeAnnotation>, std::shared_ptr<Expression>>>> optionalParams;
        VisibilityLevel visibility;
        std::shared_ptr<BlockStatement> body;
        bool isInit = false;  // Special marker for init() method
        bool isDeinit = false;  // Special marker for deinit() method
        bool isStatic = false;   // Static method (no self binding)
        bool isAbstract = false; // Abstract method (no body, must be overridden)
        bool isFinal = false;    // Final method (cannot be overridden)

        FrameMethod() : visibility(VisibilityLevel::Private), body(nullptr), isInit(false), isDeinit(false),
                        isStatic(false), isAbstract(false), isFinal(false) {}
    };

    // Frame declaration - modern OOP construct.
    // Note: 'data' modifier was removed — traits cover the same ground.
    struct FrameDeclaration : public Statement {
        std::string name;
        std::vector<std::shared_ptr<FrameField>> fields;
        std::vector<std::shared_ptr<FrameMethod>> methods;
        std::vector<std::string> implements;  // Trait names this frame implements
        std::shared_ptr<FrameMethod> init;    // Optional init() method
        std::shared_ptr<FrameMethod> deinit;  // Optional deinit() method

        // Visibility and modifiers
        bool isAbstract = false;
        bool isFinal = false;

        FrameDeclaration() : init(nullptr), deinit(nullptr), isAbstract(false), isFinal(false) {}
    };
    
    // Interface declaration
    struct InterfaceDeclaration : public Statement {
        std::string name;
        std::vector<std::shared_ptr<FunctionDeclaration>> methods;
        bool isOpen = false;
    };
    
    // Module declaration
    struct ModuleDeclaration : public Statement {
        std::string name;
        std::vector<std::shared_ptr<Statement>> publicMembers;
        std::vector<std::shared_ptr<Statement>> protectedMembers;
        std::vector<std::shared_ptr<Statement>> privateMembers;
    };
    
    // Iter statement (for modern iteration)
    struct IterStatement : public Statement {
        std::vector<std::string> loopVars;
        std::shared_ptr<Expression> iterable;
        std::shared_ptr<Statement> body;
    };
    
    // Unsafe block
    struct UnsafeStatement : public Statement {
        std::shared_ptr<BlockStatement> body;
    };
    
    // Contract statement
    struct ContractStatement : public Statement {
        std::shared_ptr<Expression> condition;
        std::shared_ptr<Expression> message;
    };
    
    // Compile-time statement
    struct ComptimeStatement : public Statement {
        std::shared_ptr<Statement> declaration;
    };

    // Error handling expressions
    
    // Fallible expression with ? operator
    struct FallibleExpr : public Expression {
        std::shared_ptr<Expression> expression;
        std::shared_ptr<Statement> elseHandler;  // Optional else block
        std::string elseVariable;                // Optional error variable name
    };

    // Error construction expression (err() calls)
    struct ErrorConstructExpr : public Expression {
        std::string errorType;                   // Error type name
        std::vector<std::shared_ptr<Expression>> arguments;  // Constructor arguments
    };

    // Success value construction (ok() calls)
    struct OkConstructExpr : public Expression {
        std::shared_ptr<Expression> value;
    };

    // Option type construction expressions
    struct SomeConstructExpr : public Expression {
        std::shared_ptr<Expression> value;
    };

    struct NoneConstructExpr : public Expression {
        // None takes no arguments, but may have type annotation context
    };

    // Lambda expression (e.g., fn(x, y) {x + y})
    struct LambdaExpr : public Expression {
        std::vector<std::pair<std::string, std::shared_ptr<TypeAnnotation>>> params;
        std::shared_ptr<BlockStatement> body;  // Block body
        std::optional<std::shared_ptr<TypeAnnotation>> returnType;
        
        // Captured variables (determined during analysis)
        std::vector<std::string> capturedVars;
    };
    
    // Memory operation expressions (inserted by type checker)
    
    // Create a linear (move-only) value
    struct MakeLinearExpr : public Expression {
        std::shared_ptr<Expression> value;      // The value to make linear
        std::size_t region_id;                  // Target memory region
        std::size_t generation;                 // Initial generation
        
        MakeLinearExpr(std::shared_ptr<Expression> val, std::size_t rid, std::size_t gen)
            : value(val), region_id(rid), generation(gen) {}
    };
    
    // Create a reference to a linear value
    struct MakeRefExpr : public Expression {
        std::string target_var;                 // Name of linear variable to reference
        bool is_mutable;                        // Is this a mutable reference
        std::size_t creation_scope;             // Scope level where reference is created
        
        MakeRefExpr(const std::string& target, bool mutable_ref, std::size_t scope)
            : target_var(target), is_mutable(mutable_ref), creation_scope(scope) {}
    };
    
    // Move a linear value (invalidates original)
    struct MoveExpr : public Expression {
        std::shared_ptr<Expression> value;      // The linear value to move
        std::string source_var;                 // Name of source variable (for tracking)
        
        MoveExpr(std::shared_ptr<Expression> val, const std::string& src)
            : value(val), source_var(src) {}
    };
    
    // Explicitly drop a linear value
    struct DropExpr : public Expression {
        std::shared_ptr<Expression> value;      // The linear value to drop
        std::string target_var;                 // Name of variable being dropped
        
        DropExpr(std::shared_ptr<Expression> val, const std::string& target)
            : value(val), target_var(target) {}
    };

    // ============================================================================
    // AST OPTIMIZATION FRAMEWORK
    // ============================================================================

    // Optimization context for tracking constants and variable states
    struct OptimizationContext {
        // Variable to constant mapping for constant propagation
        std::unordered_map<std::string, std::shared_ptr<Expression>> constants;
        
        // Set of variables that have been reassigned (not constant)
        std::set<std::string> reassigned_vars;
        
        // Variables that escape current scope (cannot propagate)
        std::set<std::string> escaping_vars;
        
        // Current scope depth for tracking variable lifetimes
        int scope_depth = 0;
        
        // Stack of scope changes for rollback
        std::vector<std::pair<std::string, std::shared_ptr<Expression>>> constant_stack;
        std::vector<std::string> reassigned_stack;
        
        // Flag to track if we are inside a loop
        bool in_loop = false;
        
        // Optimization statistics
        struct Stats {
            int constant_folds = 0;
            int constant_propagations = 0;
            int dead_code_eliminated = 0;
            int branches_simplified = 0;
            int interpolations_lowered = 0;
            int algebraic_simplifications = 0;
            int strings_canonicalized = 0;
        } stats;
        
        // Push a new scope
        void pushScope() {
            scope_depth++;
        }
        
        // Pop current scope and restore previous state
        void popScope() {
            scope_depth--;
            // Restore constants that were added in this scope
            while (!constant_stack.empty() && constant_stack.back().second != nullptr) {
                constants.erase(constant_stack.back().first);
                constant_stack.pop_back();
            }
            // Restore reassigned variables
            while (!reassigned_stack.empty()) {
                reassigned_vars.erase(reassigned_stack.back());
                reassigned_stack.pop_back();
            }
        }
        
        // Check if a variable is a known constant
        bool isConstant(const std::string& name) const {
            return constants.find(name) != constants.end() && 
                   reassigned_vars.find(name) == reassigned_vars.end() &&
                   escaping_vars.find(name) == escaping_vars.end();
        }
        
        // Get constant value for a variable
        std::shared_ptr<Expression> getConstant(const std::string& name) const {
            auto it = constants.find(name);
            return (it != constants.end()) ? it->second : nullptr;
        }
        
        // Set a variable to a constant value
        void setConstant(const std::string& name, std::shared_ptr<Expression> value) {
            constants[name] = value;
            constant_stack.emplace_back(name, value);
        }
        
        // Mark variable as reassigned (no longer constant)
        void markReassigned(const std::string& name) {
            reassigned_vars.insert(name);
            reassigned_stack.push_back(name);
        }
        
        // Mark variable as escaping (cannot propagate)
        void markEscaping(const std::string& name) {
            escaping_vars.insert(name);
        }
    };

    // Base optimizer class
    class ASTOptimizer {
    protected:
        OptimizationContext context;
        
    public:
        virtual ~ASTOptimizer() = default;
        
        // Main optimization entry point
        virtual std::shared_ptr<Program> optimize(std::shared_ptr<Program> program) {
            return optimizeProgram(program);
        }
        
        // Get optimization statistics
        const OptimizationContext::Stats& getStats() const { return context.stats; }
        
    protected:
        // Optimization methods for each node type
        virtual std::shared_ptr<Program> optimizeProgram(std::shared_ptr<Program> program);
        virtual std::shared_ptr<Expression> optimizeExpression(std::shared_ptr<Expression> expr);
        virtual std::shared_ptr<Statement> optimizeStatement(std::shared_ptr<Statement> stmt);
        
        // Specific expression optimizations
        virtual std::shared_ptr<Expression> optimizeBinaryExpr(std::shared_ptr<BinaryExpr> expr);
        virtual std::shared_ptr<Expression> optimizeUnaryExpr(std::shared_ptr<UnaryExpr> expr);
        virtual std::shared_ptr<Expression> optimizeInterpolatedStringExpr(std::shared_ptr<InterpolatedStringExpr> expr);
        virtual std::shared_ptr<LiteralExpr> optimizeLiteralExpr(std::shared_ptr<LiteralExpr> expr);
        virtual std::shared_ptr<VariableExpr> optimizeVariableExpr(std::shared_ptr<VariableExpr> expr);
        virtual std::shared_ptr<Expression> optimizeGroupingExpr(std::shared_ptr<GroupingExpr> expr);
        virtual std::shared_ptr<CallExpr> optimizeCallExpr(std::shared_ptr<CallExpr> expr);
        virtual std::shared_ptr<TernaryExpr> optimizeTernaryExpr(std::shared_ptr<TernaryExpr> expr);
        virtual std::shared_ptr<AssignExpr> optimizeAssignExpr(std::shared_ptr<AssignExpr> expr);
        
        // Specific statement optimizations
        virtual std::shared_ptr<VarDeclaration> optimizeVarDeclaration(std::shared_ptr<VarDeclaration> stmt);
        virtual std::shared_ptr<BlockStatement> optimizeBlockStatement(std::shared_ptr<BlockStatement> stmt);
        virtual std::shared_ptr<Statement> optimizeIfStatement(std::shared_ptr<IfStatement> stmt);
        virtual std::shared_ptr<WhileStatement> optimizeWhileStatement(std::shared_ptr<WhileStatement> stmt);
        virtual std::shared_ptr<ForStatement> optimizeForStatement(std::shared_ptr<ForStatement> stmt);
        virtual std::shared_ptr<ReturnStatement> optimizeReturnStatement(std::shared_ptr<ReturnStatement> stmt);
        virtual std::shared_ptr<PrintStatement> optimizePrintStatement(std::shared_ptr<PrintStatement> stmt);
        
        // Core optimization utilities
        std::shared_ptr<Expression> foldConstants(std::shared_ptr<Expression> expr);
        std::shared_ptr<Expression> propagateConstants(std::shared_ptr<Expression> expr);
        std::shared_ptr<Expression> simplifyBranches(std::shared_ptr<Expression> expr);
        std::shared_ptr<Expression> simplifyAlgebraic(std::shared_ptr<Expression> expr);
        std::shared_ptr<Expression> lowerInterpolation(std::shared_ptr<InterpolatedStringExpr> expr);
        std::shared_ptr<Expression> canonicalizeStrings(std::shared_ptr<Expression> expr);
        
        // Utility methods
        bool isLiteralConstant(std::shared_ptr<Expression> expr);
        std::shared_ptr<Expression> evaluateBinaryOp(LM::Frontend::TokenType op, std::shared_ptr<Expression> left, std::shared_ptr<Expression> right);
        std::shared_ptr<Expression> evaluateUnaryOp(LM::Frontend::TokenType op, std::shared_ptr<Expression> right);
        bool isCompileTimeFalse(std::shared_ptr<Expression> expr);
        bool isCompileTimeTrue(std::shared_ptr<Expression> expr);
        
        // Dead code detection
        bool isUnreachableCode(std::shared_ptr<Statement> stmt);
        std::shared_ptr<Statement> eliminateDeadCode(std::shared_ptr<Statement> stmt);
        
        // Pre-analysis for reassignment detection
        void preAnalyzeReassignments(std::shared_ptr<Program> program);
        void preAnalyzeStatement(std::shared_ptr<Statement> stmt);
        void preAnalyzeExpression(std::shared_ptr<Expression> expr);
    };
}

// FunctionTypeAnnotation method implementations
namespace AST {
    inline std::vector<TypePtr> FunctionTypeAnnotation::getParameterTypes() const {
        std::vector<TypePtr> types;
        for (const auto& param : parameters) {
            if (param.type) {
                // This would need to be converted from AST::TypeAnnotation to TypePtr
                // For now, we'll return empty vector as this requires TypeSystem integration
            }
        }
        return types; // Placeholder - needs TypeSystem integration
    }

    inline bool FunctionTypeAnnotation::isCompatibleWith(const FunctionTypeAnnotation& other) const {
        // Check parameter count
        if (parameters.size() != other.parameters.size()) {
            return false;
        }
        
        // For now, do basic comparison - full implementation needs TypeSystem
        for (size_t i = 0; i < parameters.size(); ++i) {
            if (!parameters[i].type || !other.parameters[i].type) {
                return false;
            }
            
            // Basic type name comparison (would need proper type checking)
            if (parameters[i].type->typeName != other.parameters[i].type->typeName) {
                return false;
            }
        }
        
        // Check return types
        if (returnType && other.returnType) {
            return returnType->typeName == other.returnType->typeName;
        }
        
        return returnType == other.returnType; // Both null or both non-null
    }

    inline std::string FunctionTypeAnnotation::toString() const {
        std::ostringstream oss;
        oss << "fn(";
        
        for (size_t i = 0; i < parameters.size(); ++i) {
            if (i > 0) oss << ", ";
            
            // Add parameter name if available
            if (!parameters[i].name.empty()) {
                oss << parameters[i].name << ": ";
            }
            
            // Add parameter type
            if (parameters[i].type) {
                oss << parameters[i].type->typeName;
            } else {
                oss << "unknown";
            }
            
            // Add default indicator if applicable
            if (parameters[i].hasDefaultValue) {
                oss << "?";
            }
        }
        
        if (isVariadic) {
            if (!parameters.empty()) oss << ", ";
            oss << "...";
        }
        
        oss << ")";
        
        // Add return type
        if (returnType) {
            oss << ": " << returnType->typeName;
        }
        
        return oss.str();
    }
}

} // namespace Frontend
} // namespace LM

#endif // AST_H
