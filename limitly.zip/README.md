# Limit Programming Language

Limit is a modern programming language designed with static typing, structured concurrency, and memory safety features. It combines the performance of systems programming with the safety and expressiveness of modern language design.

## 🚀 Get Started

To learn how to use the Limit language, check out our comprehensive, step-by-step guide:

**[➡️ Read the Full Guide](./docs/guide.md)**

## ✨ Features

*   **Static Typing:** A strong, static type system with type inference.
*   **Structured Concurrency:** High-level `parallel` and `concurrent` blocks for safe and efficient multi-tasking.
*   **Modern Error Handling:** `Option` and `Result` types for robust error handling without exceptions.
*   **Object-Oriented (Frames & Traits):** Efficient, modern OOP with static dispatch, traits, and automatic lifecycle management (init/deinit).
*   **First-Class Functions:** Higher-order functions and closures.
*   **Pattern Matching:** Powerful `match` statements for expressive control flow.
*   **Modules:** A flexible module system for organizing code.
*   **AOT Compilation:** An AOT compiler for high-performance applications.

## ✅ VM-backed Current Status (Source of Truth)

The **runtime source of truth** for currently supported syntax/behavior is the `tests/` directory.
If docs and examples ever disagree, prefer what is covered by passing tests in:

- `tests/basic/`, `tests/expressions/`, `tests/loops/`, `tests/functions/`
- `tests/types/` (including enums and match usage)
- `tests/modules/`
- `tests/oop/` (frames/traits/visibility/composition)
- `tests/concurrency/` (`parallel`/`concurrent`, task/worker/channel flows)

The compiler currently targets the VM/register execution path and supports tested constructs including:
- enums + `match`-based handling,
- list/tuple/dict usage,
- frame/trait OOP features,
- structured concurrency blocks and channels.

## 🛠️ Building and Running

### Prerequisites
- CMake 3.10 or higher
- C++20 compatible compiler

### Build Instructions
```bash
# Using Make (recommended for cross-platform)
make

# Using Windows Batch (MSYS2/MinGW64)
build.bat

# Using Unix Shell
./build.sh
```

### Running
```bash
# Execute a source file
./limitly sample.lm

# Start the REPL (interactive mode)
./limitly -repl
```

## Testing

The project includes a comprehensive test suite in the `tests/` directory.

```bash
# Run all tests (silent mode)
./tests/run_tests.bat
./tests/run_tests.sh

```

> Note: test syntax and behavior in `tests/` should be treated as canonical language reference.
