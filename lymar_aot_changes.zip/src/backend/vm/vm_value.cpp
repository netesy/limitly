#define BUILDING_RUNTIME
#include "memory/numeric_conversion.hh"
#include "memory/numeric_semantics.hh"
#include <cstring>
#define _POSIX_C_SOURCE 200809L
#include "vm_value.hh"
#include "vm_value_base.hh"
#include "vm_list.hh"
#include "vm_dict.hh"
#include "vm_tuple.hh"
#include "vm_string.hh"
#include "vm_runtime.hh"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <inttypes.h>
#include <math.h>
#include <string>

// Phase 6: Centralized Runtime Constructors
RUNTIME_API LmValue make_i64(int64_t v) {
    if (fits_smi_i64(v)) return BOX_INT(v);
    return lm_alloc_i64(v);
}

RUNTIME_API LmValue make_u64(uint64_t v) {
    if (fits_smi_u64(v)) return BOX_INT(v);
    return lm_alloc_u64(v);
}

RUNTIME_API LmValue make_i128(__int128 v) {
    if (v >= MIN_SMI && v <= MAX_SMI) return BOX_INT((int64_t)v);
    if (v >= INT64_MIN && v <= INT64_MAX) return lm_alloc_i64((int64_t)v);
    return lm_alloc_i128(v);
}

RUNTIME_API LmValue make_u128(unsigned __int128 v) {
    if (v <= (unsigned __int128)MAX_SMI) return BOX_INT((int64_t)v);
    if (v <= UINT64_MAX) return lm_alloc_u64((uint64_t)v);
    return lm_alloc_u128(v);
}

RUNTIME_API LmValue make_float(double v) {
    return lm_alloc_float(v);
}

// Phase 7: Centralized Extraction Helpers
RUNTIME_API bool is_integer(LmValue v) {
    if (IS_INT(v)) return true;
    if (IS_PTR(v)) {
        ObjHeader* h = (ObjHeader*)UNBOX_PTR(v);
        if (h->type_id == TYPE_I64 || h->type_id == TYPE_U64 ||
            h->type_id == TYPE_I128 || h->type_id == TYPE_U128) return true;
        if (h->type_id == TYPE_BOX) {
            LmBox* box = (LmBox*)h;
            return box->type == LM_BOX_INT;
        }
    }
    return false;
}

RUNTIME_API bool is_float(LmValue v) {
    if (IS_PTR(v)) {
        ObjHeader* h = (ObjHeader*)UNBOX_PTR(v);
        if (h->type_id == TYPE_FLOAT) return true;
        if (h->type_id == TYPE_BOX) {
            LmBox* box = (LmBox*)h;
            return box->type == LM_BOX_FLOAT;
        }
    }
    return false;
}

static inline bool is_numeric_internal(LmValue v) {
    return is_integer(v) || is_float(v);
}

RUNTIME_API int64_t as_i64(LmValue v) {
    if (IS_INT(v)) return UNBOX_INT(v);
    if (IS_PTR(v)) {
        ObjHeader* h = (ObjHeader*)UNBOX_PTR(v);
        if (h->type_id == TYPE_I64) return ((ObjI64*)h)->value;
        if (h->type_id == TYPE_U64) return (int64_t)((ObjU64*)h)->value;
        if (h->type_id == TYPE_I128) return (int64_t)((ObjI128*)h)->value;
        if (h->type_id == TYPE_U128) return (int64_t)((ObjU128*)h)->value;
        if (h->type_id == TYPE_FLOAT) return LM::Memory::truncate_i64(((ObjFloat*)h)->value);
        if (h->type_id == TYPE_BOX) {
            LmBox* box = (LmBox*)h;
            if (box->type == LM_BOX_INT) return box->value.as_int;
            if (box->type == LM_BOX_FLOAT) return LM::Memory::truncate_i64(box->value.as_float);
        }
    }
    return 0;
}

RUNTIME_API uint64_t as_u64(LmValue v) {
    if (IS_INT(v)) return (uint64_t)UNBOX_INT(v);
    if (IS_PTR(v)) {
        ObjHeader* h = (ObjHeader*)UNBOX_PTR(v);
        if (h->type_id == TYPE_I64) return (uint64_t)((ObjI64*)h)->value;
        if (h->type_id == TYPE_U64) return ((ObjU64*)h)->value;
        if (h->type_id == TYPE_I128) return (uint64_t)((ObjI128*)h)->value;
        if (h->type_id == TYPE_U128) return (uint64_t)((ObjU128*)h)->value;
        if (h->type_id == TYPE_FLOAT) return (uint64_t)((ObjFloat*)h)->value;
        if (h->type_id == TYPE_BOX) {
            LmBox* box = (LmBox*)h;
            if (box->type == LM_BOX_INT) return (uint64_t)box->value.as_int;
        }
    }
    return 0;
}

RUNTIME_API __int128 as_i128(LmValue v) {
    if (IS_INT(v)) return (__int128)UNBOX_INT(v);
    if (IS_PTR(v)) {
        ObjHeader* h = (ObjHeader*)UNBOX_PTR(v);
        if (h->type_id == TYPE_I64) return (__int128)((ObjI64*)h)->value;
        if (h->type_id == TYPE_U64) return (__int128)((ObjU64*)h)->value;
        if (h->type_id == TYPE_I128) return ((ObjI128*)h)->value;
        if (h->type_id == TYPE_U128) return (__int128)((ObjU128*)h)->value;
        if (h->type_id == TYPE_FLOAT) return (__int128)((ObjFloat*)h)->value;
        if (h->type_id == TYPE_BOX) {
            LmBox* box = (LmBox*)h;
            if (box->type == LM_BOX_INT) return (__int128)box->value.as_int;
            if (box->type == LM_BOX_FLOAT) return (__int128)box->value.as_float;
        }
    }
    return 0;
}

RUNTIME_API unsigned __int128 as_u128(LmValue v) {
    if (IS_INT(v)) return (unsigned __int128)UNBOX_INT(v);
    if (IS_PTR(v)) {
        ObjHeader* h = (ObjHeader*)UNBOX_PTR(v);
        if (h->type_id == TYPE_I64) return (unsigned __int128)((ObjI64*)h)->value;
        if (h->type_id == TYPE_U64) return (unsigned __int128)((ObjU64*)h)->value;
        if (h->type_id == TYPE_I128) return (unsigned __int128)((ObjI128*)h)->value;
        if (h->type_id == TYPE_U128) return ((ObjU128*)h)->value;
        if (h->type_id == TYPE_FLOAT) return (unsigned __int128)((ObjFloat*)h)->value;
        if (h->type_id == TYPE_BOX) {
            LmBox* box = (LmBox*)h;
            if (box->type == LM_BOX_INT) return (unsigned __int128)box->value.as_int;
        }
    }
    return 0;
}

RUNTIME_API double as_float(LmValue v) {
    if (IS_PTR(v)) {
        ObjHeader* h = (ObjHeader*)UNBOX_PTR(v);
        if (h->type_id == TYPE_FLOAT) return ((ObjFloat*)h)->value;
        if (h->type_id == TYPE_BOX) {
            LmBox* box = (LmBox*)h;
            if (box->type == LM_BOX_FLOAT) return box->value.as_float;
            if (box->type == LM_BOX_INT) return (double)box->value.as_int;
        }
    }
    if (is_integer(v)) return (double)as_i64(v);
    return 0.0;
}

// Phase 13: Numeric Comparison
RUNTIME_API int numeric_compare(LmValue a, LmValue b) {
    if (a == b) return 0;
    if (is_numeric_internal(a) && is_numeric_internal(b)) {
        if (is_float(a) || is_float(b)) {
            double f1 = as_float(a);
            double f2 = as_float(b);
            if (f1 < f2) return -1;
            if (f1 > f2) return 1;
            return 0;
        } else {
            __int128 i1 = as_i128(a);
            __int128 i2 = as_i128(b);
            if (i1 < i2) return -1;
            if (i1 > i2) return 1;
            return 0;
        }
    }
    return (a < b) ? -1 : 1;
}

RUNTIME_API int lm_value_eq(LmValue v1, LmValue v2) {
    if (v1 == v2) return 1;
    if (IS_PTR(v1) && IS_PTR(v2)) {
        ObjHeader* h1 = (ObjHeader*)UNBOX_PTR(v1);
        ObjHeader* h2 = (ObjHeader*)UNBOX_PTR(v2);
        if (h1 && h2) {
            // Erased casts can return a boxed string while literals use the
            // length-bearing string header. Representation is not identity.
            if ((h1->type_id == TYPE_STRING && h2->type_id == TYPE_BOX &&
                 reinterpret_cast<LmBox*>(h2)->type == LM_BOX_STRING) ||
                (h2->type_id == TYPE_STRING && h1->type_id == TYPE_BOX &&
                 reinterpret_cast<LmBox*>(h1)->type == LM_BOX_STRING)) {
                auto* string = reinterpret_cast<LmStringHeader*>(h1->type_id == TYPE_STRING ? h1 : h2);
                auto* box = reinterpret_cast<LmBox*>(h1->type_id == TYPE_BOX ? h1 : h2);
                auto* data = static_cast<const char*>(box->value.as_ptr);
                return data && string->len == std::strlen(data) && std::memcmp(string->data, data, string->len) == 0;
            }
            if (h1->type_id == TYPE_STRING && h2->type_id == TYPE_STRING) {
                LmStringHeader* s1 = (LmStringHeader*)h1;
                LmStringHeader* s2 = (LmStringHeader*)h2;
                if (s1->len != s2->len) return 0;
                return memcmp(s1->data, s2->data, s1->len) == 0;
            }
            if (h1->type_id == TYPE_BOX && h2->type_id == TYPE_BOX) {
                LmBox* b1 = (LmBox*)h1;
                LmBox* b2 = (LmBox*)h2;
                if (b1->type == b2->type && b1->type == LM_BOX_STRING) {
                    return strcmp((char*)b1->value.as_ptr, (char*)b2->value.as_ptr) == 0;
                }
            }
        }
    }
    if (IS_INT(v1) && IS_PTR(v2)) {
        ObjHeader* h2 = (ObjHeader*)UNBOX_PTR(v2);
        if (h2 && h2->type_id == TYPE_STRING) {
            LmStringHeader* s2 = (LmStringHeader*)h2;
            if (s2->len == 1 && (uint8_t)s2->data[0] == (uint8_t)UNBOX_INT(v1)) return 1;
        }
    }
    if (IS_PTR(v1) && IS_INT(v2)) {
        ObjHeader* h1 = (ObjHeader*)UNBOX_PTR(v1);
        if (h1 && h1->type_id == TYPE_STRING) {
            LmStringHeader* s1 = (LmStringHeader*)h1;
            if (s1->len == 1 && (uint8_t)s1->data[0] == (uint8_t)UNBOX_INT(v2)) return 1;
        }
    }
    if (is_numeric_internal(v1) && is_numeric_internal(v2)) {
        if (is_float(v1) || is_float(v2)) {
            return as_float(v1) == as_float(v2);
        } else {
            return as_i128(v1) == as_i128(v2);
        }
    }
    return 0;
}

// Stringification
static void append_to_buffer(char** buf, uint64_t* pos, uint64_t* capacity, const char* str) {
    if (!str) return;
    uint64_t str_len = strlen(str);
    while (*pos + str_len >= *capacity) {
        *capacity *= 2;
        char* new_buf = (char*)realloc(*buf, *capacity);
        if (!new_buf) return;
        *buf = new_buf;
    }
    memcpy(*buf + *pos, str, str_len);
    *pos += str_len;
}

static char* int128_to_str(__int128 n) {
    char* buf = (char*)malloc(64);
    if (n == 0) { strcpy(buf, "0"); return buf; }
    int sign = 0;
    if (n < 0) { sign = 1; n = -n; }
    int i = 62;
    buf[63] = '\0';
    while (n > 0) {
        buf[i--] = (char)((n % 10) + '0');
        n /= 10;
    }
    if (sign) buf[i--] = '-';
    char* res = strdup(&buf[i+1]);
    free(buf);
    return res;
}

static char* uint128_to_str(unsigned __int128 n) {
    char* buf = (char*)malloc(64);
    if (n == 0) { strcpy(buf, "0"); return buf; }
    int i = 62;
    buf[63] = '\0';
    while (n > 0) {
        buf[i--] = (char)((n % 10) + '0');
        n /= 10;
    }
    char* res = strdup(&buf[i+1]);
    free(buf);
    return res;
}

static LmStringHeader* format_value(LmValue value);

static LmStringHeader* format_tuple(LmTuple* tuple) {
    uint64_t capacity = 256;
    char* buf = (char*)malloc(capacity);
    uint64_t pos = 0;
    buf[0] = 0;
    append_to_buffer(&buf, &pos, &capacity, "(");
    for (uint64_t i = 0; i < tuple->size; i++) {
        if (i > 0) append_to_buffer(&buf, &pos, &capacity, ", ");
        LmStringHeader* s = format_value(tuple->elements[i]);
        append_to_buffer(&buf, &pos, &capacity, s ? s->data : "nil");
        lm_str_free(s);
    }
    append_to_buffer(&buf, &pos, &capacity, ")");
    buf[pos] = 0;
    LmStringHeader* res = lm_str_from_bytes(buf, pos);
    free(buf);
    return res;
}

static LmStringHeader* format_list(LmList* list) {
    uint64_t capacity = 256;
    char* buf = (char*)malloc(capacity);
    uint64_t pos = 0;
    buf[0] = 0;
    append_to_buffer(&buf, &pos, &capacity, "[");
    for (uint64_t i = 0; i < list->size; i++) {
        if (i > 0) append_to_buffer(&buf, &pos, &capacity, ", ");
        LmStringHeader* s = format_value(list->data[i]);
        append_to_buffer(&buf, &pos, &capacity, s ? s->data : "nil");
        lm_str_free(s);
    }
    append_to_buffer(&buf, &pos, &capacity, "]");
    buf[pos] = 0;
    LmStringHeader* res = lm_str_from_bytes(buf, pos);
    free(buf);
    return res;
}

static LmStringHeader* format_dict(LmDict* dict) {
    uint64_t capacity = 256;
    char* buf = (char*)malloc(capacity);
    uint64_t pos = 0;
    buf[0] = 0;
    append_to_buffer(&buf, &pos, &capacity, "{");
    uint64_t count = 0;
    LmValue* items = lm_dict_items(dict, &count);
    for (uint64_t i = 0; i < count; i++) {
        if (i > 0) append_to_buffer(&buf, &pos, &capacity, ", ");
        LmStringHeader* k = format_value(items[i * 2]);
        append_to_buffer(&buf, &pos, &capacity, k ? k->data : "nil");
        lm_str_free(k);
        append_to_buffer(&buf, &pos, &capacity, ": ");
        LmStringHeader* v = format_value(items[i * 2 + 1]);
        append_to_buffer(&buf, &pos, &capacity, v ? v->data : "nil");
        lm_str_free(v);
    }
    if (items) free(items);
    append_to_buffer(&buf, &pos, &capacity, "}");
    buf[pos] = 0;
    LmStringHeader* res = lm_str_from_bytes(buf, pos);
    free(buf);
    return res;
}

static LmStringHeader* format_value(LmValue value) {
    if (IS_INT(value)) return lm_int_to_str(UNBOX_INT(value));
    if (IS_NIL(value)) return lm_str_from_cstr("nil");
    if (IS_BOOL(value)) return lm_bool_to_str(UNBOX_BOOL(value) ? 1 : 0);
    if (IS_PTR(value)) {
        ObjHeader* h = (ObjHeader*)UNBOX_PTR(value);
        switch (h->type_id) {
            case TYPE_STRING: {
                LmStringHeader* sh = (LmStringHeader*)h;
                return lm_str_from_bytes(sh->data, sh->len);
            }
            case TYPE_BOX: {
                LmBox* box = (LmBox*)h;
                switch (box->type) {
                    case LM_BOX_INT: return lm_int_to_str(box->value.as_int);
                    case LM_BOX_FLOAT: return lm_double_to_str(box->value.as_float);
                    case LM_BOX_BOOL: return lm_bool_to_str(box->value.as_bool);
                    case LM_BOX_STRING: return lm_str_from_cstr((char*)box->value.as_ptr);
                    case LM_BOX_NULLPTR: return lm_str_from_cstr("nil");
                }
                break;
            }
            case TYPE_I64: return lm_int_to_str(((ObjI64*)h)->value);
            case TYPE_U64: {
                char b[64];
                snprintf(b, sizeof(b), "%" PRIu64, ((ObjU64*)h)->value);
                return lm_str_from_cstr(b);
            }
            case TYPE_I128: {
                char* s = int128_to_str(((ObjI128*)h)->value);
                LmStringHeader* res = lm_str_from_cstr(s);
                free(s);
                return res;
            }
            case TYPE_U128: {
                char* s = uint128_to_str(((ObjU128*)h)->value);
                LmStringHeader* res = lm_str_from_cstr(s);
                free(s);
                return res;
            }
            case TYPE_FLOAT: return lm_double_to_str(((ObjFloat*)h)->value);
            case TYPE_LIST: return format_list((LmList*)h);
            case TYPE_TUPLE: return format_tuple((LmTuple*)h);
            case TYPE_DICT: return format_dict((LmDict*)h);
            case TYPE_FRAME: {
                LmFrame* f = (LmFrame*)h;
                if (f->name && strcmp(f->name, "__lir_internal_enum__") == 0) {
                    int64_t tag = as_i64(f->fields[0]);
                    LmValue payload = f->field_count > 1 ? f->fields[1] : VAL_NIL;
                    LmValue variant_name_val = f->field_count > 2 ? f->fields[2] : VAL_NIL;

                    LmStringHeader* vname_hdr = nullptr;
                    if (!IS_NIL(variant_name_val) && IS_PTR(variant_name_val)) {
                        ObjHeader* vhdr = (ObjHeader*)UNBOX_PTR(variant_name_val);
                        if (vhdr && vhdr->type_id == TYPE_STRING) {
                            vname_hdr = (LmStringHeader*)vhdr;
                        }
                    }

                    if (!IS_NIL(payload)) {
                        LmStringHeader* payload_str = format_value(payload);
                        if (vname_hdr) {
                            std::string res_str = std::string(vname_hdr->data, vname_hdr->len) + "(" + (payload_str ? std::string(payload_str->data, payload_str->len) : "nil") + ")";
                            if (payload_str) lm_str_free(payload_str);
                            return lm_str_from_bytes(res_str.data(), res_str.length());
                        }
                        return payload_str;
                    } else if (vname_hdr) {
                        return lm_str_from_bytes(vname_hdr->data, vname_hdr->len);
                    }
                    char tag_str[32];
                    snprintf(tag_str, sizeof(tag_str), "%lld", (long long)tag);
                    return lm_str_from_cstr(tag_str);
                }
                if (f->name && strcmp(f->name, "__lir_internal_ok__") == 0) {
                    LmValue payload = f->field_count > 1 ? f->fields[1] : VAL_NIL;
                    uint64_t capacity = 128;
                    char* buf = (char*)malloc(capacity);
                    uint64_t pos = 0;
                    buf[0] = 0;
                    append_to_buffer(&buf, &pos, &capacity, "ok(");
                    if (!IS_NIL(payload)) {
                        LmStringHeader* s = format_value(payload);
                        append_to_buffer(&buf, &pos, &capacity, s ? s->data : "nil");
                        lm_str_free(s);
                    }
                    append_to_buffer(&buf, &pos, &capacity, ")");
                    buf[pos] = 0;
                    LmStringHeader* res = lm_str_from_bytes(buf, pos);
                    free(buf);
                    return res;
                }
                if (f->name && strcmp(f->name, "__lir_internal_error__") == 0) {
                    LmValue payload = f->field_count > 1 ? f->fields[1] : VAL_NIL;
                    uint64_t capacity = 128;
                    char* buf = (char*)malloc(capacity);
                    uint64_t pos = 0;
                    buf[0] = 0;
                    append_to_buffer(&buf, &pos, &capacity, "err(");
                    if (!IS_NIL(payload)) {
                        LmStringHeader* s = format_value(payload);
                        append_to_buffer(&buf, &pos, &capacity, s ? s->data : "nil");
                        lm_str_free(s);
                    }
                    append_to_buffer(&buf, &pos, &capacity, ")");
                    buf[pos] = 0;
                    LmStringHeader* res = lm_str_from_bytes(buf, pos);
                    free(buf);
                    return res;
                }
                uint64_t capacity = 128;
                char* buf = (char*)malloc(capacity);
                uint64_t pos = 0;
                buf[0] = 0;
                append_to_buffer(&buf, &pos, &capacity, f->name ? f->name : "Frame");
                append_to_buffer(&buf, &pos, &capacity, "{");
                for (int i = 0; i < f->field_count; i++) {
                    if (i > 0) append_to_buffer(&buf, &pos, &capacity, ", ");
                    LmStringHeader* s = format_value(f->fields[i]);
                    append_to_buffer(&buf, &pos, &capacity, s ? s->data : "nil");
                    lm_str_free(s);
                }
                append_to_buffer(&buf, &pos, &capacity, "}");
                buf[pos] = 0;
                LmStringHeader* res = lm_str_from_bytes(buf, pos);
                free(buf);
                return res;
            }
            default: break;
        }
    }
    return lm_str_from_cstr("<unknown>");
}

RUNTIME_API LmStringHeader* lm_value_to_string(LmValue value) {
    return format_value(value);
}

// Phase 12: Overflow-aware Arithmetic
RUNTIME_API LmValue lm_add(LmValue a, LmValue b) {
    if (IS_PTR(a) && IS_PTR(b)) {
        ObjHeader* h1 = (ObjHeader*)UNBOX_PTR(a);
        ObjHeader* h2 = (ObjHeader*)UNBOX_PTR(b);
        if (h1 && h2) {
        if (h1->type_id == TYPE_LIST && h2->type_id == TYPE_LIST) {
            LmList* l1 = (LmList*)h1;
            LmList* l2 = (LmList*)h2;
            LmList* result = lm_list_new();
            if (result) {
                for (uint64_t i = 0; i < l1->size; ++i) {
                    lm_list_append(result, l1->data[i]);
                }
                for (uint64_t i = 0; i < l2->size; ++i) {
                    lm_list_append(result, l2->data[i]);
                }
                return BOX_PTR(result);
            }
        }
        if (h1->type_id == TYPE_STRING && h2->type_id == TYPE_STRING) {
            LmStringHeader* s1 = (LmStringHeader*)h1;
            LmStringHeader* s2 = (LmStringHeader*)h2;
            LmStringHeader* combined = lm_str_concat(s1, s2);
            return BOX_PTR(combined);
        }
        if (h1->type_id == TYPE_BOX && h2->type_id == TYPE_BOX) {
            LmBox* b1 = (LmBox*)h1;
            LmBox* b2 = (LmBox*)h2;
            if (b1->type == LM_BOX_STRING && b2->type == LM_BOX_STRING) {
                LmStringHeader* s1 = lm_str_from_cstr((const char*)b1->value.as_ptr);
                LmStringHeader* s2 = lm_str_from_cstr((const char*)b2->value.as_ptr);
                LmStringHeader* combined = lm_str_concat(s1, s2);
                lm_str_free(s1);
                lm_str_free(s2);
                return BOX_PTR(combined);
            }
        }
        }
    }
    if (is_integer(a) && is_integer(b)) {
        __int128 i1 = as_i128(a);
        __int128 i2 = as_i128(b);
        __int128 res;
        if (!LM::Memory::add_integer(i1, i2, res)) return VAL_NIL;
        return make_i128(res);
    }
    if (is_numeric_internal(a) && is_numeric_internal(b)) {
        return make_float(as_float(a) + as_float(b));
    }
    return VAL_NIL;
}

RUNTIME_API LmValue lm_rt_str_format(LmValue fmt_val, LmValue arg_val) {
    LmStringHeader* fmt = lm_value_to_string(fmt_val);
    LmStringHeader* arg = lm_value_to_string(arg_val);
    LmStringHeader* res = lm_str_format(fmt, arg);
    lm_str_free(fmt);
    lm_str_free(arg);
    return BOX_PTR(res);
}

RUNTIME_API LmValue lm_sub(LmValue a, LmValue b) {
    if (is_integer(a) && is_integer(b)) {
        __int128 i1 = as_i128(a);
        __int128 i2 = as_i128(b);
        __int128 res;
        if (!LM::Memory::add_integer(i1, i2, res, true)) return VAL_NIL;
        return make_i128(res);
    }
    if (is_numeric_internal(a) && is_numeric_internal(b)) {
        return make_float(as_float(a) - as_float(b));
    }
    return VAL_NIL;
}

RUNTIME_API LmValue lm_mul(LmValue a, LmValue b) {
    if (is_integer(a) && is_integer(b)) {
        __int128 i1 = as_i128(a);
        __int128 i2 = as_i128(b);
        __int128 res;
        if (__builtin_mul_overflow(i1, i2, &res)) return VAL_NIL;
        return make_i128(res);
    }
    if (is_numeric_internal(a) && is_numeric_internal(b)) {
        return make_float(as_float(a) * as_float(b));
    }
    return VAL_NIL;
}

RUNTIME_API LmValue lm_div(LmValue a, LmValue b) {
    if (is_integer(a) && is_integer(b)) {
        __int128 i1 = as_i128(a);
        __int128 i2 = as_i128(b);
        if (i2 == 0) return VAL_NIL;
        return make_i128(i1 / i2);
    }
    if (is_numeric_internal(a) && is_numeric_internal(b)) {
        double f2 = as_float(b);
        if (f2 == 0.0) return VAL_NIL;
        return make_float(as_float(a) / f2);
    }
    return VAL_NIL;
}
