#ifndef REGISTER_H
#define REGISTER_H

#include "../../lir/lir.hh"
#include "../../memory/contracts.hh"
#include "../../memory/region_instances.hh"
#include "../../frontend/type_checker.hh"
#include "../register_value.hh"
#include "../task.hh"
#include "../scheduler.hh"
#include "../channel.hh"
#include "vm_runtime.hh"
#include "vm_value.hh"
#include "callstack.hh"
#include "resource_types.hh"
#include <vector>
#include <string>
#include <unordered_map>
#include <map>
#include <unordered_set>
#include <memory>
#include <mutex>
#include <atomic>
#include <queue>
#include <chrono>
#include <algorithm>
#include <stdexcept>

namespace LM {
namespace Backend {
namespace VM {
namespace Register {

inline bool is_decimal_type(const TypePtr& type) {
    return type && (type->tag == ::TypeTag::Decimal2 || type->tag == ::TypeTag::Decimal4 || type->tag == ::TypeTag::Decimal6);
}

void* box_register_value(const RegisterValue& value);
RegisterValue unbox_register_value(void* boxed_value);
ValuePtr register_to_value_ptr(RegisterValue rv, TypePtr lang_type = nullptr);

class RegisterVM {
public:
    RegisterVM();
    ~RegisterVM();

    void execute(const LIR::LIR_Function& function);
    void execute_function(const LIR::LIR_Function& function);
    void execute_instructions(const LIR::LIR_Function& function, uint64_t start_pc, uint64_t end_pc);
    void reset();
    
    RegisterValue get_global(const std::string& name) const;
    void set_global(const std::string& name, RegisterValue value);
    // Native modules share tagged heap objects and the caller's ownership region.
    void register_native_allocation(RegisterValue value);
    LmFrame* checked_frame(RegisterValue value, uint32_t index);
    void update_atomic_frame(RegisterValue receiver, uint32_t index, RegisterValue value, bool subtract);
    void transfer_native_ownership(RegisterValue child, RegisterValue container) {
        transfer_ownership(child, container);
    }

    uint64_t borrow_memory(RegisterValue value, bool writable);
    RegisterValue resolve_memory(uint64_t token, bool writable);
    void release_memory_borrow(uint64_t token) {
        std::lock_guard<std::recursive_mutex> lock(heap_mutex_);
        memory_lifetimes_.end_borrow(token);
    }
    void consume_memory(RegisterValue value);
    uint64_t move_memory_reference(uint64_t token, uint32_t lexical);
    size_t live_allocation_count() const { return vm_allocation_types.size(); }
    size_t live_raw_allocation_count() const { return owned_raw_memory.size(); }
    size_t live_callback_count() const { return owned_callbacks.size(); }
    void finalize_frame(RegisterValue value);
    void finalize_owned_frames(uint64_t region, bool all = false);
    void track_resource(int64_t id) { if (id >= 0) owned_resources.insert(id); }
    void untrack_resource(int64_t id) { owned_resources.erase(id); }
    void publish_value(RegisterValue value) { export_graph(value); }
    uint64_t begin_native_call();
    void end_native_call(uint64_t depth, RegisterValue result);
    void native_region(LIR::LIR_Op op, uint32_t lexical, RegisterValue value = VAL_NIL);
    bool has_active_fibers() const;
    std::string to_string(const RegisterValue& value) const;
    Fiber* get_current_fiber();
    
    void set_current_function(const LIR::LIR_Function* func) { current_function_ = func; }

    ValuePtr createErrorValue(const std::string& errorType, const std::string& message);
    ValuePtr createSuccessValue(const RegisterValue& value);

    // Called by native FFI trampolines to re-enter the VM synchronously.
    // Saves full VM state, executes `func_name` with `args`, restores state,
    // and returns whatever the Lymar function left in registers[0].
    RegisterValue invoke_for_callback(const std::string& func_name,
                                      const std::vector<RegisterValue>& args,
                                      bool propagate_errors = false);

private:
    RegisterValue call_interpreted(const std::string& name,
                                   const std::vector<RegisterValue>& args);
    // Reuse register storage across calls; caller values remain isolated.
    std::vector<std::vector<RegisterValue>> spare_register_files_;

    // Opcode execution modules
    void execute_arithmetic(const LIR::LIR_Inst* pc);
    void execute_comparison(const LIR::LIR_Inst* pc);
    void execute_collections(const LIR::LIR_Inst* pc);
    void execute_frames(const LIR::LIR_Inst* pc);
    void execute_control_flow(const LIR::LIR_Inst*& pc, const LIR::LIR_Function& function);
    void execute_concurrency(const LIR::LIR_Inst* pc);
    void execute_io(const LIR::LIR_Inst* pc);
    void execute_bitwise(const LIR::LIR_Inst* pc);
    void execute_modules(const LIR::LIR_Inst* pc);
    void execute_objects(const LIR::LIR_Inst* pc);
    void execute_strings(const LIR::LIR_Inst* pc);
    void execute_calls(const LIR::LIR_Inst* pc);
    void execute_cast(const LIR::LIR_Inst* pc);
    
    // Intrinsic layer
    void execute_memory(const LIR::LIR_Inst* pc);
    
    // Data construction layer
    void execute_construction(const LIR::LIR_Inst* pc);
    
    // External C interop layer
    void execute_ffi(const LIR::LIR_Inst* pc);

    // Memory operations
    void execute_memory_load(const LIR::LIR_Inst* pc);
    void execute_memory_store(const LIR::LIR_Inst* pc);
    void execute_memory_copy(const LIR::LIR_Inst* pc);
    void execute_memory_fill(const LIR::LIR_Inst* pc);
    void execute_memory_compare(const LIR::LIR_Inst* pc);
    void execute_memory_alloc(const LIR::LIR_Inst* pc);
    void execute_memory_free(const LIR::LIR_Inst* pc);
    void execute_memory_realloc(const LIR::LIR_Inst* pc);

    // Pointer operations
    void execute_ptr_add(const LIR::LIR_Inst* pc);
    void execute_ptr_sub(const LIR::LIR_Inst* pc);
    void execute_ptr_diff(const LIR::LIR_Inst* pc);
    void execute_ptr_align(const LIR::LIR_Inst* pc);
    void execute_ptr_is_aligned(const LIR::LIR_Inst* pc);
    
    // Marshaling operations
    void execute_marshal(const LIR::LIR_Inst* pc);
    void execute_unmarshal(const LIR::LIR_Inst* pc);
    void execute_buffer_view(const LIR::LIR_Inst* pc);
    void execute_buffer_create(const LIR::LIR_Inst* pc);
    void execute_buffer_resize(const LIR::LIR_Inst* pc);
    
    // Dynamic linking operations
    void execute_library_load(const LIR::LIR_Inst* pc);
    void execute_library_unload(const LIR::LIR_Inst* pc);
    void execute_library_symbol(const LIR::LIR_Inst* pc);
    
    // Foreign call operations
    void execute_foreign_call(const LIR::LIR_Inst* pc);
    void execute_foreign_call_direct(const LIR::LIR_Inst* pc);
    
    // Callback operations
    void execute_callback_create(const LIR::LIR_Inst* pc);
    void execute_callback_destroy(const LIR::LIR_Inst* pc);
    
    // Region operations
    void execute_regions(const LIR::LIR_Inst* pc);
    void auto_register_output(const LIR::LIR_Inst* pc);
    void reclaim_value(RegisterValue val);
    void transfer_ownership(RegisterValue child, RegisterValue container);
    
    // Data construction helpers
    void execute_construct_string_from_cstr(const LIR::LIR_Inst* pc);
    void execute_construct_cstr_from_string(const LIR::LIR_Inst* pc);
    void execute_construct_free_cstr(const LIR::LIR_Inst* pc);
    void execute_construct_buffer_alloc(const LIR::LIR_Inst* pc);
    void execute_construct_buffer_from_ptr(const LIR::LIR_Inst* pc);
    void execute_construct_buffer_capacity(const LIR::LIR_Inst* pc);
    void execute_construct_buffer_size(const LIR::LIR_Inst* pc);
    void execute_construct_buffer_as_ptr(const LIR::LIR_Inst* pc);
    void execute_construct_cstring_from_ptr(const LIR::LIR_Inst* pc);
    void execute_construct_cstring_ptr(const LIR::LIR_Inst* pc);
    
    // External C interop helpers
    void execute_extern_library_load(const LIR::LIR_Inst* pc);
    void execute_extern_library_unload(const LIR::LIR_Inst* pc);
    void execute_extern_library_get_symbol(const LIR::LIR_Inst* pc);
    void execute_extern_call_function(const LIR::LIR_Inst* pc);
    void execute_extern_register_callback(const LIR::LIR_Inst* pc);
    void execute_extern_unregister_callback(const LIR::LIR_Inst* pc);
    void execute_extern_get_callback_ptr(const LIR::LIR_Inst* pc);
    void execute_extern_ccall_frame_create(const LIR::LIR_Inst* pc);
    void execute_extern_ccall_frame_destroy(const LIR::LIR_Inst* pc);
    void execute_extern_ccall_frame_set_reg(const LIR::LIR_Inst* pc);
    void execute_extern_ccall_frame_get_reg(const LIR::LIR_Inst* pc);
    void execute_extern_ccall_frame_set_stack_arg(const LIR::LIR_Inst* pc);
    void execute_extern_ccall_frame_get_stack_arg(const LIR::LIR_Inst* pc);
    void execute_extern_vm_save(const LIR::LIR_Inst* pc);
    void execute_extern_vm_restore(const LIR::LIR_Inst* pc);
    void execute_extern_calc_struct_layout(const LIR::LIR_Inst* pc);
    void execute_extern_get_abi_info(const LIR::LIR_Inst* pc);

    std::vector<RegisterValue> registers;
    
    Memory::LifetimeRegistry memory_lifetimes_;
    // Region and memory model tracking
    struct RegionInstance {
        uint32_t lexical_id;
        uint64_t parent;
        size_t depth;
        uintptr_t raw_head = 0;
    };
    uint64_t active_region_id = 0;
    uint64_t next_region_id = 1;
    std::vector<uint64_t> vm_region_stack;
    std::vector<size_t> region_depth_table;
    inline size_t get_region_depth(uint64_t id) const {
        return (id < region_depth_table.size()) ? region_depth_table[id] : 0;
    }
    Memory::RegionInstances<RegionInstance> region_instances;
    std::unordered_map<uint64_t, std::unordered_set<uintptr_t>> region_allocations;
    std::unordered_map<uintptr_t, uint64_t> vm_allocation_regions;
    std::vector<uint64_t> invocation_parents;
    std::unordered_set<int64_t> owned_callbacks;
    std::unordered_set<int64_t> owned_resources;
    void release_resources();
    struct RawOwnership { uint64_t region; uintptr_t previous = 0, next = 0; };
    std::map<uintptr_t, RawOwnership> owned_raw_memory;
    std::multimap<uintptr_t, uintptr_t> raw_aliases;
    void index_raw_alias(uintptr_t wrapper);
    void unindex_raw_alias(uintptr_t wrapper);
    uintptr_t root_raw_head = 0;
    uintptr_t& raw_head(uint64_t region);
    void attach_raw_memory(uintptr_t address, uint64_t region);
    void detach_raw_memory(uintptr_t address);
    void export_raw_memory(RegisterVM& parent);
    std::unordered_set<uintptr_t> borrowed_constants;
    std::unordered_set<uintptr_t> opaque_runtime_pointers;
    RegisterVM* heap_parent_ = nullptr;
    std::recursive_mutex heap_mutex_;
    void export_graph(RegisterValue value);
    std::unordered_map<uintptr_t, RegisterValue> constant_copies;
    RegisterValue load_constant(RegisterValue value);
    void promote_graph(RegisterValue value, uint64_t target);
    void exit_region();
    void revoke_callbacks();
    void release_raw_memory();
    void release_region_raw_memory(uint64_t region);
    void promote_raw_memory(void* address, uint64_t region);
    void invalidate_raw_aliases(uintptr_t address, size_t size);
    RegisterValue allocate_raw_memory(size_t size);
    size_t raw_memory_size(RegisterValue value);
    std::unordered_map<uintptr_t, uint32_t> vm_allocation_types;
    
    struct ErrorInfo {
        std::string errorType;
        std::string message;
        bool isError;
        
        ErrorInfo() : isError(false) {}
        ErrorInfo(const std::string& type, const std::string& msg, bool error = true)
            : errorType(type), message(msg), isError(error) {}
    };
    
    std::unordered_map<int64_t, ErrorInfo> error_table;
    
    const LIR::LIR_Function* current_function_ = nullptr;
    std::unordered_map<std::string, RegisterValue> globals_;
    std::unique_ptr<TypeSystem> type_system;
    
    std::vector<std::unique_ptr<TaskContext>> task_contexts;
    std::vector<std::unique_ptr<LM::Backend::Channel>> channels;
    std::unique_ptr<Scheduler> scheduler;
    uint64_t current_time;
    struct ConcurrencyExecutionConfig {
        uint32_t cores = 1;
        uint64_t timeout_ms = 0;
        uint64_t grace_ms = 0;
        LIR::Metadata::ErrorPolicy error_policy = LIR::Metadata::ErrorPolicy::Stop;
        LIR::Metadata::ErrorPolicy timeout_policy = LIR::Metadata::ErrorPolicy::Stop;
        std::chrono::steady_clock::time_point started{};
    } parallel_config, scheduler_config;
    struct RuntimeSliceCapability {
        RegisterValue collection = VAL_NIL;
        uint32_t begin = 0;
        uint32_t end = 0;
        bool active = true;
    };
    std::vector<RuntimeSliceCapability> slice_capabilities;
    
    std::unordered_map<std::string, std::atomic<int64_t>> shared_variables;
    
    std::unordered_map<uint64_t, FrameInstancePtr> frame_instances;
    uint64_t next_frame_id = 1;
    
    std::atomic<int64_t> default_atomic{0};
    std::vector<std::queue<uint64_t>> work_queues;
    std::atomic<uint64_t> work_queue_counter{0};
    
    std::vector<RegisterValue> argument_stack;
    
    // Call stack and VM state management for FFI
    CallStack call_stack;
    VMStateManager vm_state_manager;

    
    inline LIR::Type get_register_type(LIR::Reg reg) const {
        if (!current_function_) return LIR::Type::Void;
        auto it = current_function_->register_types.find(reg);
        return (it != current_function_->register_types.end()) ? it->second : LIR::Type::Void;
    }
    
    inline TypePtr get_register_language_type(LIR::Reg reg) const {
        if (!current_function_) return nullptr;
        return current_function_->get_register_language_type(reg);
    }
    
    inline bool is_numeric(const RegisterValue& value) const {
        return is_integer(value) || is_float(value);
    }
    
    inline int64_t to_int(const RegisterValue& value) const {
        return as_i64(value);
    }
    
    inline uint64_t to_uint(const RegisterValue& value) const {
        return as_u64(value);
    }
    
    inline double to_float(const RegisterValue& value) const {
        return as_float(value);
    }
    
    inline bool to_bool(const RegisterValue& value) const {
        if (IS_BOOL(value)) return UNBOX_BOOL(value);
        if (IS_NIL(value)) return false;
        if (is_integer(value)) return as_i128(value) != 0;
        if (IS_PTR(value)) {
            ObjHeader* h = (ObjHeader*)UNBOX_PTR(value);
            if (h->type_id == TYPE_FLOAT) return ((ObjFloat*)h)->value != 0.0;
            if (h->type_id == TYPE_BOX && ((LmBox*)h)->type == LM_BOX_STRING) {
                LmBox* box = (LmBox*)h;
                return box->value.as_ptr && ((char*)box->value.as_ptr)[0] != '\0';
            }
            return true;
        }
        return false;
    }
    
    bool isErrorValue(LIR::Reg reg) const;
    
    inline ObjHeader* header_if_type(RegisterValue value, uint32_t type_id) const {
        if (!IS_PTR(value)) return nullptr;
        auto* header = static_cast<ObjHeader*>(UNBOX_PTR(value));
        return header && header->type_id == type_id ? header : nullptr;
    }

    FrameInstancePtr createFrameInstance(const std::string& frame_type);
    void setFrameField(FrameInstancePtr frame, size_t index, const RegisterValue& value);
    RegisterValue getFrameField(FrameInstancePtr frame, size_t index) const;
};

} // namespace Register
} // namespace VM
} // namespace Backend
} // namespace LM

#endif // REGISTER_H
