#include "capability_mapper.hh"
#include "vendor/fyra/include/target/capabilities/Capabilities.h"
#include <iostream>

namespace LM {
namespace Backend {
namespace Fyra {

std::optional<CapabilityDescriptor> CapabilityMapper::map(LIR::LIR_Op op) {
    switch (op) {
        // Memory Operations
        case LIR::LIR_Op::MemoryAlloc:
            return CapabilityDescriptor{"memory.alloc", 1, 1, true, true};
        case LIR::LIR_Op::MemoryFree:
            return CapabilityDescriptor{"memory.free", 1, 1, false, false};
        case LIR::LIR_Op::MemoryResize:
            return CapabilityDescriptor{"memory.resize", 2, 2, true, true};
        case LIR::LIR_Op::MemoryCopy:
            return CapabilityDescriptor{"memory.copy", 3, 3, false, false};
        case LIR::LIR_Op::MemoryFill:
            return CapabilityDescriptor{"memory.fill", 3, 3, false, false};
        case LIR::LIR_Op::MemoryCompare:
            return CapabilityDescriptor{"memory.compare", 3, 3, true, false};
        
        // Dynamic Linking Operations -> lymarrt C ABI runtime functions
        case LIR::LIR_Op::LibraryLoad:
            return CapabilityDescriptor{"lymarrt_library_open", 1, 1, true, true};
        case LIR::LIR_Op::LibraryUnload:
            return CapabilityDescriptor{"lymarrt_library_close", 1, 1, false, false};
        case LIR::LIR_Op::LibrarySymbol:
            return CapabilityDescriptor{"lymarrt_symbol_lookup", 2, 2, true, true};
        
        default:
            return std::nullopt;
    }
}

} // namespace Fyra
} // namespace Backend
} // namespace LM
