#ifndef LIR_FUNCTIONS_HH
#define LIR_FUNCTIONS_HH

#include <string>
#include <vector>
#include <unordered_map>
#include <functional>
#include <memory>
#include <optional>
#include "lir.hh"
#include "../backend/value.hh"
#include "../backend/types.hh"

namespace LM {
namespace LIR {

// LIR-specific parameter and signature types (independent from backend)
struct LIRParameter {
    std::string name;
    Type type;
};

struct LIRFunctionSignature {
    std::string name;
    std::vector<LIRParameter> parameters;
    std::optional<Type> returnType;
};

// Helper function to convert TypeTag to LIR::Type
Type typeTagToLIRType(TypeTag tag);

// Forward declarations
class LIRFunction;
class LIRFunctionManager;

// Type alias for LIR function body implementations
// These are specifically designed for LIR register-based operations
using LIRFunctionBody = std::function<ValuePtr(const std::vector<ValuePtr>&)>;

// LIR-specific function class
// Optimized for register-based LIR operations and JIT compilation
class LIRFunction {
private:
    std::string name_;
    std::vector<LIRParameter> parameters_;
    std::optional<Type> returnType_;
    LIRFunctionBody body_;
    LIRFunctionSignature signature_;
    
    // Store the LIR instructions for this function
    std::vector<LIR::LIR_Inst> instructions_;

public:
    LIRFunction(const std::string& name, 
                const std::vector<LIRParameter>& params,
                std::optional<Type> returnType,
                LIRFunctionBody body);
    
    // Function interface
    ValuePtr execute(const std::vector<ValuePtr>& args);
    bool isNative() const;
    const LIRFunctionSignature& getSignature() const;
    
    // LIR-specific accessors
    const std::string& getName() const { return name_; }
    const std::vector<LIRParameter>& getParameters() const { return parameters_; }
    const std::optional<Type>& getReturnType() const { return returnType_; }
    bool hasBody() const { return static_cast<bool>(body_); }
    
    // LIR instruction access
    const std::vector<LIR::LIR_Inst>& getInstructions() const { return instructions_; }
    void setInstructions(const std::vector<LIR::LIR_Inst>& instructions) { instructions_ = instructions; }

    Memory::FunctionEffects memory_effects_;
    Memory::SemanticEffects inferred_effects_;
    std::vector<Memory::Identity> ownership_parameters_, ownership_captures_;
    std::unordered_map<Reg, Memory::NodeOwnership> ownership_provenance_;
    uint32_t register_count_ = 0;
    std::unordered_map<Reg, TypePtr> register_language_types_;
    std::unordered_map<Reg, Type> register_types_;

    const std::unordered_map<Reg, TypePtr>& getRegisterLanguageTypes() const { return register_language_types_; }
    void setRegisterLanguageTypes(const std::unordered_map<Reg, TypePtr>& m) { register_language_types_ = m; }

    const std::unordered_map<Reg, Type>& getRegisterTypes() const { return register_types_; }
    void setRegisterTypes(const std::unordered_map<Reg, Type>& m) { register_types_ = m; }
};

// Manager for LIR-specific functions
// Completely separate from the backend bytecode system
class LIRFunctionManager {
private:
    static LIRFunctionManager* instance;
    std::unordered_map<std::string, std::shared_ptr<LIRFunction>> functions_;
    bool initialized_ = false;

public:
    static LIRFunctionManager& getInstance();
    
    // Initialization
    void initialize();
    
    // Function registration
    void registerFunction(std::shared_ptr<LIRFunction> function);
    
    // Function lookup
    std::shared_ptr<LIRFunction> getFunction(const std::string& name);
    bool hasFunction(const std::string& name) const;
    size_t getFunctionIndex(const std::string& name) const;
    
    // Function creation helpers
    std::shared_ptr<LIRFunction> createFunction(
        const std::string& name,
        const std::vector<LIRParameter>& params,
        std::optional<Type> returnType,
        LIRFunctionBody body);
    
    std::shared_ptr<LIRFunction> createArithmeticFunction(
        const std::string& name,
        const std::vector<TypeTag>& paramTypes,
        TypeTag returnType,
        std::function<ValuePtr(const std::vector<ValuePtr>&)> impl);
    
    // Utility methods
    std::vector<std::string> getFunctionNames() const;
};

// BuiltinUtils namespace for accessing builtin LIR functions
namespace BuiltinUtils {
    void initializeBuiltins();
    bool isBuiltinFunction(const std::string& name);
    ValuePtr callBuiltinFunction(const std::string& name, const std::vector<ValuePtr>& args);
    std::vector<std::string> getBuiltinFunctionNames();
}

// Utility functions for LIR function integration
namespace FunctionUtils {

// Call any LIR function (builtin or user-defined) by name
ValuePtr callFunction(const std::string& name, const std::vector<ValuePtr>& args);

// Check if a function exists (builtin or user-defined)
bool isFunction(const std::string& name);

// Initialize LIR function system
void initializeFunctions();

// Get all available function names (builtin + user-defined)
std::vector<std::string> getAllFunctionNames();

// Helper functions for creating common operation functions
std::shared_ptr<LIRFunction> createBinaryOpFunction(
    const std::string& name,
    TypeTag paramType,
    TypeTag returnType,
    std::function<ValuePtr(ValuePtr, ValuePtr)> operation);

std::shared_ptr<LIRFunction> createUnaryOpFunction(
    const std::string& name,
    TypeTag paramType,
    TypeTag returnType,
    std::function<ValuePtr(ValuePtr)> operation);

} // namespace LIRFunctionUtils

} // namespace LIR
} // namespace LM

#endif // LIR_FUNCTIONS_HH
