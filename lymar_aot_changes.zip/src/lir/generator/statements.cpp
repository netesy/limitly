#include "../generator.hh"
#include "../../memory/reference_flags.hh"
#include "../functions.hh"
#include "../intrinsic_registry.hh"
#include "../../backend/vm/constant_utils.hh"
#include "../../frontend/module_manager.hh"
#include "../function_registry.hh"
#include "../builtin_functions.hh"
#include "../../frontend/ast.hh"
#include "../../frontend/scanner.hh"
#include <algorithm>
#include <functional>
#include <map>
#include <limits>

using namespace LM::LIR;

namespace LM {
namespace LIR {

namespace {
bool is_variable_alias_expr(LM::Frontend::AST::Expression* expr) {
    if (!expr) return false;
    if (dynamic_cast<LM::Frontend::AST::VariableExpr*>(expr)) return true;
    if (auto grouping = dynamic_cast<LM::Frontend::AST::GroupingExpr*>(expr)) {
        return is_variable_alias_expr(grouping->expression.get());
    }
    return false;
}

bool resolve_match_variant_info(TypeSystem* type_system,
                                TypePtr match_type,
                                const std::string& pattern_type_name,
                                int64_t& out_tag,
                                size_t& out_arity) {
    TypePtr enum_type = match_type;
    std::string variant_name = pattern_type_name;

    // 1. Try to find variant directly in the provided match_type
    if (enum_type && (enum_type->tag == TypeTag::Enum || enum_type->tag == TypeTag::UserDefined || enum_type->tag == TypeTag::Frame)) {
        if (auto* enum_info = std::get_if<EnumType>(&enum_type->extra)) {
            // Try unqualified name
            std::string unqualified = variant_name;
            if (unqualified.find('.') != std::string::npos) unqualified = unqualified.substr(unqualified.find('.') + 1);
            
            auto it = std::find(enum_info->values.begin(), enum_info->values.end(), unqualified);
            if (it != enum_info->values.end()) {
                out_tag = static_cast<int64_t>(std::distance(enum_info->values.begin(), it));
                auto arity_it = enum_info->variantTypes.find(*it);
                out_arity = (arity_it != enum_info->variantTypes.end()) ? arity_it->second.size() : 0;
                return true;
            }
        }
    }

    // 2. Try to resolve via qualified name (EnumName.Variant)
    auto dot_pos = pattern_type_name.find('.');
    if (dot_pos != std::string::npos) {
        std::string enum_name = pattern_type_name.substr(0, dot_pos);
        variant_name = pattern_type_name.substr(dot_pos + 1);
        if (type_system) {
            auto found = type_system->getType(enum_name);
            if (found && (found->tag == TypeTag::Enum || found->tag == TypeTag::UserDefined || found->tag == TypeTag::Frame)) {
                if (auto* enum_info = std::get_if<EnumType>(&found->extra)) {
                    auto it = std::find(enum_info->values.begin(), enum_info->values.end(), variant_name);
                    if (it != enum_info->values.end()) {
                        out_tag = static_cast<int64_t>(std::distance(enum_info->values.begin(), it));
                        auto arity_it = enum_info->variantTypes.find(*it);
                        out_arity = (arity_it != enum_info->variantTypes.end()) ? arity_it->second.size() : 0;
                        return true;
                    }
                }
            }
        }
    }

    return false;
}

void bind_all_vars(Generator* gen, std::shared_ptr<LM::Frontend::AST::Expression> pattern, Reg val_reg) {
    if (!pattern) return;
    if (auto facts = gen->ownership_facts()) {
        auto found = facts->nodes.find(pattern->memory_info.semantic_id);
        if (found != facts->nodes.end() && !found->second.event.empty()) {
            LIR_Inst event(LIR_Op::Nop, Type::Void, UINT32_MAX, UINT32_MAX, UINT32_MAX);
            event.ownership = found->second.event; gen->emit_instruction(event);
        }
    }
    if (auto var = std::dynamic_pointer_cast<LM::Frontend::AST::VariableExpr>(pattern)) {
        if (var->name != "_") gen->bind_variable(var->name, val_reg);
    } else if (auto val_p = std::dynamic_pointer_cast<LM::Frontend::AST::ValPatternExpr>(pattern)) {
        Reg payload = gen->allocate_register();
        gen->emit_instruction(LIR_Inst(LIR_Op::Unwrap, Type::Ptr, payload, val_reg));
        gen->bind_variable(val_p->variableName, payload);
    } else if (auto err_p = std::dynamic_pointer_cast<LM::Frontend::AST::ErrPatternExpr>(pattern)) {
        Reg payload = gen->allocate_register();
        gen->emit_instruction(LIR_Inst(LIR_Op::GetPayload, Type::Ptr, payload, val_reg));
        gen->bind_variable(err_p->variableName, payload);
    } else if (auto err_t_p = std::dynamic_pointer_cast<LM::Frontend::AST::ErrorTypePatternExpr>(pattern)) {
         Reg payload = gen->allocate_register();
         gen->emit_instruction(LIR_Inst(LIR_Op::GetPayload, Type::Ptr, payload, val_reg));
         for (size_t i = 0; i < err_t_p->parameterNames.size(); ++i) {
                Reg idx_reg = gen->allocate_register();
                gen->emit_instruction(LIR_Inst(LIR_Op::LoadConst, Type::I64, idx_reg, make_i64((int64_t)i)));
                Reg elem = gen->allocate_register();
                gen->emit_instruction(LIR_Inst(LIR_Op::TupleGet, Type::Ptr, elem, payload, idx_reg));
                gen->bind_variable(err_t_p->parameterNames[i], elem);
         }
    } else if (auto list_p = std::dynamic_pointer_cast<LM::Frontend::AST::ListPatternExpr>(pattern)) {
        for (size_t i = 0; i < list_p->elements.size(); ++i) {
            Reg idx_reg = gen->allocate_register();
            gen->emit_instruction(LIR_Inst(LIR_Op::LoadConst, Type::I64, idx_reg, make_i64(i)));
            Reg elem = gen->allocate_register();
            gen->emit_instruction(LIR_Inst(LIR_Op::ListIndex, Type::Ptr, elem, val_reg, idx_reg));
            bind_all_vars(gen, list_p->elements[i], elem);
        }
        if (list_p->restElement.has_value() && list_p->restElement.value() != "_") {
            Reg rest_list = gen->allocate_register();
            gen->emit_instruction(LIR_Inst(LIR_Op::ListCreate, Type::Ptr, rest_list, 0, 0));
            Reg len_reg = gen->allocate_register();
            gen->emit_instruction(LIR_Inst(LIR_Op::ListLen, Type::I64, len_reg, val_reg));
            LIR_BasicBlock* loop_cond = gen->create_basic_block("rest_slice_cond");
            LIR_BasicBlock* loop_body = gen->create_basic_block("rest_slice_body");
            LIR_BasicBlock* loop_exit = gen->create_basic_block("rest_slice_exit");
            Reg cur_idx = gen->allocate_register();
            gen->emit_instruction(LIR_Inst(LIR_Op::LoadConst, Type::I64, cur_idx, make_i64(list_p->elements.size())));
            gen->emit_instruction(LIR_Inst(LIR_Op::Jump, 0, 0, 0, loop_cond->id));
            gen->add_block_edge(gen->get_current_block(), loop_cond);
            gen->set_current_block(loop_cond);
            Reg cmp = gen->allocate_register();
            gen->emit_instruction(LIR_Inst(LIR_Op::CmpLT, Type::Bool, cmp, cur_idx, len_reg));
            gen->emit_instruction(LIR_Inst(LIR_Op::JumpIfFalse, 0, cmp, 0, loop_exit->id));
            gen->add_block_edge(loop_cond, loop_body);
            gen->add_block_edge(loop_cond, loop_exit);
            gen->set_current_block(loop_body);
            Reg elem = gen->allocate_register();
            gen->emit_instruction(LIR_Inst(LIR_Op::ListIndex, Type::Ptr, elem, val_reg, cur_idx));
            Reg dummy_res = gen->allocate_register();
            gen->emit_instruction(LIR_Inst(LIR_Op::ListAppend, Type::Void, dummy_res, rest_list, elem));
            Reg next_idx = gen->allocate_register();
            Reg one_reg = gen->allocate_register();
            gen->emit_instruction(LIR_Inst(LIR_Op::LoadConst, Type::I64, one_reg, make_i64(1)));
            gen->emit_instruction(LIR_Inst(LIR_Op::Add, Type::I64, next_idx, cur_idx, one_reg));
            gen->emit_instruction(LIR_Inst(LIR_Op::Mov, Type::I64, cur_idx, next_idx, 0));
            gen->emit_instruction(LIR_Inst(LIR_Op::Jump, 0, 0, 0, loop_cond->id));
            gen->add_block_edge(loop_body, loop_cond);
            gen->set_current_block(loop_exit);
            gen->bind_variable(list_p->restElement.value(), rest_list);
        }
    } else if (auto tuple_p = std::dynamic_pointer_cast<LM::Frontend::AST::TuplePatternExpr>(pattern)) {
        for (size_t i = 0; i < tuple_p->elements.size(); ++i) {
            Reg idx_reg = gen->allocate_register();
            gen->emit_instruction(LIR_Inst(LIR_Op::LoadConst, Type::I64, idx_reg, make_i64(i)));
            Reg elem = gen->allocate_register();
            gen->emit_instruction(LIR_Inst(LIR_Op::TupleGet, Type::Ptr, elem, val_reg, idx_reg));
            bind_all_vars(gen, tuple_p->elements[i], elem);
        }
    } else if (auto dict_p = std::dynamic_pointer_cast<LM::Frontend::AST::DictPatternExpr>(pattern)) {
        for (const auto& field : dict_p->fields) {
            Reg key_reg = gen->allocate_register();
            gen->emit_instruction(LIR_Inst(LIR_Op::LoadConst, Type::Ptr, key_reg, BOX_PTR(lm_str_from_cstr(field.key.c_str()))));
            Reg elem = gen->allocate_register();
            gen->emit_instruction(LIR_Inst(LIR_Op::DictGet, Type::Ptr, elem, val_reg, key_reg));
            bind_all_vars(gen, field.pattern, elem);
        }
        if (dict_p->restBinding.has_value() && dict_p->restBinding.value() != "_") {
            gen->bind_variable(dict_p->restBinding.value(), val_reg);
        }
    } else if (auto binding = std::dynamic_pointer_cast<LM::Frontend::AST::BindingPatternExpr>(pattern)) {
        if (binding->typeName == "val") {
             if (!binding->patterns.empty()) {
                Reg payload = gen->allocate_register();
                gen->emit_instruction(LIR_Inst(LIR_Op::Unwrap, Type::Ptr, payload, val_reg));
                bind_all_vars(gen, binding->patterns[0], payload);
            }
            return;
        }
        if (binding->typeName == "err") {
             if (!binding->patterns.empty()) {
                Reg payload = gen->allocate_register();
                gen->emit_instruction(LIR_Inst(LIR_Op::GetPayload, Type::Ptr, payload, val_reg));
                bind_all_vars(gen, binding->patterns[0], payload);
            }
            return;
        }
        int64_t tag = 0; size_t arity = 0;
        TypePtr m_type = binding->inferred_type;
        bool resolved = resolve_match_variant_info(gen->get_type_system().get(), m_type, binding->typeName, tag, arity);
        if (!resolved && m_type && (m_type->tag == TypeTag::Enum || m_type->tag == TypeTag::UserDefined)) {
            if (auto* et = std::get_if<EnumType>(&m_type->extra)) {
                resolved = resolve_match_variant_info(gen->get_type_system().get(), m_type, et->name + "." + binding->typeName, tag, arity);
            }
        }
        if (!resolved) {
            if (binding->patterns.empty() && binding->typeName != "_") {
                gen->bind_variable(binding->typeName, val_reg);
                return;
            }
            return; // Don't try to extract payload if not resolved
        }
        if (binding->patterns.empty()) return;

        Reg payload = gen->allocate_register();
        gen->emit_instruction(LIR_Inst(LIR_Op::GetPayload, Type::Ptr, payload, val_reg));
        if (binding->patterns.size() == 1) {
            bind_all_vars(gen, binding->patterns[0], payload);
        } else {
            for (size_t i = 0; i < binding->patterns.size(); ++i) {
                Reg idx_reg = gen->allocate_register();
                gen->emit_instruction(LIR_Inst(LIR_Op::LoadConst, Type::I64, idx_reg, make_i64(i)));
                Reg elem = gen->allocate_register();
                gen->emit_instruction(LIR_Inst(LIR_Op::TupleGet, Type::Ptr, elem, payload, idx_reg));
                bind_all_vars(gen, binding->patterns[i], elem);
            }
        }
    }
}
}

void Generator::emit_stmt(LM::Frontend::AST::Statement& stmt) {
    emit_stmt_impl(stmt);
    if (ownership_facts_ && current_function_) {
        auto found = ownership_facts_->nodes.find(stmt.memory_info.semantic_id);
        if (found != ownership_facts_->nodes.end()) {
            const auto& fact = found->second;
            emit_ownership_event(fact.event);
            if (auto variable = dynamic_cast<LM::Frontend::AST::VarDeclaration*>(&stmt)) {
                auto value = resolve_variable(variable->name);
                current_function_->ownership_provenance[value] = fact;
                // Unknown nested/opaque alias provenance needs a live reference
                // capability. Proven local transfers do not allocate handles.
                const bool initially_nil = !variable->initializer || (variable->initializer->inferred_type && variable->initializer->inferred_type->tag == TypeTag::Nil);
                if ((fact.managed || initially_nil) && (fact.unknown_origin || ownership_facts_->reference_bindings.count(fact.binding)) && value != UINT32_MAX) {
                    auto handle = allocate_register();
                    auto permission = Memory::ReferenceNullable | (ownership_facts_->writable_bindings.count(fact.binding) ? Memory::ReferenceWritable : 0);
                    emit_instruction(LIR_Inst(LIR_Op::RefCreate, Type::U64, handle, value, UINT32_MAX, permission));
                    checked_references_[fact.binding] = handle;
                }
            }
        }
        // End a proven nonescaping block-local lease at its last source use.
        // Objects retain their normal region ownership/destruction. Keep a
        // nullable zero in the handle register for later reassignment cleanup.
        if (!dynamic_cast<LM::Frontend::AST::ReturnStatement*>(&stmt) &&
            !dynamic_cast<LM::Frontend::AST::BreakStatement*>(&stmt) &&
            !dynamic_cast<LM::Frontend::AST::ContinueStatement*>(&stmt)) {
            auto ends = ownership_facts_->borrow_ends.find(stmt.memory_info.semantic_id);
            if (ends != ownership_facts_->borrow_ends.end()) for (auto binding : ends->second) {
                auto handle = checked_references_.find(binding);
                if (handle == checked_references_.end()) continue;
                emit_instruction(LIR_Inst(LIR_Op::RefRelease, Type::Void, UINT32_MAX, handle->second, UINT32_MAX, Memory::ReferenceNullable));
                emit_instruction(LIR_Inst(LIR_Op::LoadConst, Type::U64, handle->second, make_u64(0)));
            }
        }
    }
}

void Generator::emit_stmt_impl(LM::Frontend::AST::Statement& stmt) {
   // Unified region management: emit RegionEnter based on memory_info
   emit_region_enter_from_memory_info(stmt);
    
    if (auto expr_stmt = dynamic_cast<LM::Frontend::AST::ExprStatement*>(&stmt)) {
       // std::cout << "[DEBUG] Emitting ExprStatement" << std::endl;
        emit_expr_stmt(*expr_stmt);
    } else if (auto var_stmt = dynamic_cast<LM::Frontend::AST::VarDeclaration*>(&stmt)) {
        emit_var_stmt(*var_stmt);
    } else if (auto dest_stmt = dynamic_cast<LM::Frontend::AST::DestructuringDeclaration*>(&stmt)) { 
        emit_destructuring_var_stmt(*dest_stmt);
    } else if (auto block_stmt = dynamic_cast<LM::Frontend::AST::BlockStatement*>(&stmt)) {
        emit_block_stmt(*block_stmt);
    } else if (auto if_stmt = dynamic_cast<LM::Frontend::AST::IfStatement*>(&stmt)) {
        emit_if_stmt(*if_stmt);
    } else if (auto while_stmt = dynamic_cast<LM::Frontend::AST::WhileStatement*>(&stmt)) {
        emit_while_stmt(*while_stmt);
    } else if (auto for_stmt = dynamic_cast<LM::Frontend::AST::ForStatement*>(&stmt)) {
        emit_for_stmt(*for_stmt);
    } else if (auto iter_stmt = dynamic_cast<LM::Frontend::AST::IterStatement*>(&stmt)) {
        emit_iter_stmt(*iter_stmt);
    } else if (auto break_stmt = dynamic_cast<LM::Frontend::AST::BreakStatement*>(&stmt)) {
        emit_break_stmt(*break_stmt);
    } else if (auto continue_stmt = dynamic_cast<LM::Frontend::AST::ContinueStatement*>(&stmt)) {
        emit_continue_stmt(*continue_stmt);
    } else if (auto return_stmt = dynamic_cast<LM::Frontend::AST::ReturnStatement*>(&stmt)) {
        emit_return_stmt(*return_stmt);
    } else if (auto func_stmt = dynamic_cast<LM::Frontend::AST::FunctionDeclaration*>(&stmt)) {
        emit_func_stmt(*func_stmt);
    } else if (auto import_stmt = dynamic_cast<LM::Frontend::AST::ImportStatement*>(&stmt)) {
        emit_import_stmt(*import_stmt);
    } else if (auto match_stmt = dynamic_cast<LM::Frontend::AST::MatchStatement*>(&stmt)) {
        emit_match_stmt(*match_stmt);
    } else if (auto contract_stmt = dynamic_cast<LM::Frontend::AST::ContractStatement*>(&stmt)) {
        emit_contract_stmt(*contract_stmt);
    } else if (auto staged_stmt = dynamic_cast<LM::Frontend::AST::StagedStatement*>(&stmt)) {
        emit_staged_stmt(*staged_stmt);
    } else if (auto staged_block = dynamic_cast<LM::Frontend::AST::StagedBlockStatement*>(&stmt)) {
        emit_staged_block(*staged_block);
    } else if (auto parallel_stmt = dynamic_cast<LM::Frontend::AST::ParallelStatement*>(&stmt)) {
        emit_parallel_stmt(*parallel_stmt);
    } else if (auto concurrent_stmt = dynamic_cast<LM::Frontend::AST::ConcurrentStatement*>(&stmt)) {
       // std::cout << "[DEBUG] Emitting ConcurrentStatement" << std::endl;
        emit_concurrent_stmt(*concurrent_stmt);
    } else if (auto task_stmt = dynamic_cast<LM::Frontend::AST::TaskStatement*>(&stmt)) {
        emit_task_stmt(*task_stmt);
    } else if (auto worker_stmt = dynamic_cast<LM::Frontend::AST::WorkerStatement*>(&stmt)) {
        emit_worker_stmt(*worker_stmt);
    } else if (auto unsafe_stmt = dynamic_cast<LM::Frontend::AST::UnsafeStatement*>(&stmt)) {
        emit_unsafe_stmt(*unsafe_stmt);
    } else if (auto trait_stmt = dynamic_cast<LM::Frontend::AST::TraitDeclaration*>(&stmt)) {
        emit_trait_stmt(*trait_stmt);
    } else if (auto frame_stmt = dynamic_cast<LM::Frontend::AST::FrameDeclaration*>(&stmt)) {
        emit_frame_stmt(*frame_stmt);
    } else if (auto mixin_stmt = dynamic_cast<LM::Frontend::AST::MixinDeclaration*>(&stmt)) {
        // Mixin declarations are flattened at compile time
    } else if (auto embed_stmt = dynamic_cast<LM::Frontend::AST::EmbedStatement*>(&stmt)) {
        // Embed statements are promoted at compile time
    } else if (auto module_stmt = dynamic_cast<LM::Frontend::AST::ModuleDeclaration*>(&stmt)) {
        emit_module_stmt(*module_stmt);
    } else if (auto type_decl = dynamic_cast<LM::Frontend::AST::TypeDeclaration*>(&stmt)) {
        // Type aliases don't generate code
    } else if (auto enum_decl = dynamic_cast<LM::Frontend::AST::EnumDeclaration*>(&stmt)) {
        // Enums don't generate code yet
    } else {
        report_error("Unsupported statement type in LIR generator");
    }
    
    // Unified region management: emit RegionExit based on memory_info
    emit_region_exit_from_memory_info(stmt);
}


void Generator::emit_expr_stmt(LM::Frontend::AST::ExprStatement& stmt) {
    emit_expr(*stmt.expression);
}





void Generator::emit_var_stmt(LM::Frontend::AST::VarDeclaration& stmt) {
    if (stmt.type && stmt.type.value()->typeName == "atomic") {
        Reg initial = stmt.initializer ? emit_expr(*stmt.initializer) : allocate_register();
        if (!stmt.initializer) emit_instruction(LIR_Inst(LIR_Op::LoadConst, Type::I64, initial, make_i64(0)));
        Reg cell = allocate_register();
        LIR_Inst create(LIR_Op::NewFrame, Type::Ptr, cell, 0, 0, 1);
        create.type_name = "__atomic_scalar";
        emit_instruction(create);
        emit_instruction(LIR_Inst(LIR_Op::FrameSetFieldAtomic, Type::Void, cell, 0, initial));
        set_register_abi_type(cell, Type::Ptr);
        if (current_function_ && current_function_->name == current_module_ + ".__init__") {
            LIR_Inst store(LIR_Op::StoreGlobal, Type::Void, 0, cell, 0);
            store.func_name = current_module_ + "." + stmt.name;
            emit_instruction(store);
        } else bind_variable(stmt.name, cell);
        return;
    }

    // Determine the declared type first, before processing the initializer
    TypePtr declared_type = nullptr;
    if (stmt.type.has_value()) {
        auto type_annotation = *stmt.type.value();
        if (type_annotation.typeName == "u32") {
            declared_type = std::make_shared<::Type>(::TypeTag::UInt32);
        } else if (type_annotation.typeName == "u16") {
            declared_type = std::make_shared<::Type>(::TypeTag::UInt16);
        } else if (type_annotation.typeName == "u8") {
            declared_type = std::make_shared<::Type>(::TypeTag::UInt8);
        } else if (type_annotation.typeName == "u64") {
            declared_type = std::make_shared<::Type>(::TypeTag::UInt64);
        } else if (type_annotation.typeName == "u128") {
            declared_type = std::make_shared<::Type>(::TypeTag::UInt128);
        } else if (type_annotation.typeName == "int") {
            declared_type = std::make_shared<::Type>(::TypeTag::Int64);
        } else if (type_annotation.typeName == "i64") {
            declared_type = std::make_shared<::Type>(::TypeTag::Int64);
        } else if (type_annotation.typeName == "i32") {
            declared_type = std::make_shared<::Type>(::TypeTag::Int32);
        } else if (type_annotation.typeName == "i16") {
            declared_type = std::make_shared<::Type>(::TypeTag::Int16);
        } else if (type_annotation.typeName == "i8") {
            declared_type = std::make_shared<::Type>(::TypeTag::Int8);
        } else if (type_annotation.typeName == "i128") {
            declared_type = std::make_shared<::Type>(::TypeTag::Int128);
        } else if (type_annotation.typeName == "f64") {
            declared_type = std::make_shared<::Type>(::TypeTag::Float64);
        } else if (type_annotation.typeName == "f32") {
            declared_type = std::make_shared<::Type>(::TypeTag::Float32);
        } else if (type_annotation.typeName == "bool") {
            declared_type = std::make_shared<::Type>(::TypeTag::Bool);
        } else if (type_annotation.typeName == "d2") {
            declared_type = std::make_shared<::Type>(::TypeTag::Decimal2);
        } else if (type_annotation.typeName == "d4") {
            declared_type = std::make_shared<::Type>(::TypeTag::Decimal4);
        } else if (type_annotation.typeName == "d6") {
            declared_type = std::make_shared<::Type>(::TypeTag::Decimal6);
        } else if (type_annotation.typeName == "decimal") {
            declared_type = std::make_shared<::Type>(::TypeTag::Decimal2);
        } else if (type_annotation.typeName == "string") {
            declared_type = std::make_shared<::Type>(::TypeTag::String);
        } else if (type_annotation.typeName == "any") {
            declared_type = std::make_shared<::Type>(::TypeTag::Any);
        }
    }

    // Check if this is a module-level variable (global)
    // Treat as global if: we're not inside a function (or inside __init__ function)
    if (current_function_ == nullptr || (current_function_ && current_function_->name == current_module_ + ".__init__")) {
        std::string qualified_name = current_module_ + "." + stmt.name;
        Reg val_reg = 0;
        if (stmt.initializer) {
            if (auto literal = dynamic_cast<LM::Frontend::AST::LiteralExpr*>(stmt.initializer.get())) {
                val_reg = emit_literal_expr(*literal, declared_type);
            } else {
                val_reg = emit_expr(*stmt.initializer);
            }
        } else {
            val_reg = allocate_register();
            Backend::Value nil_val = VAL_NIL;
            emit_instruction(LIR_Inst(LIR_Op::LoadConst, Type::Void, val_reg, nil_val));
        }
        bind_variable(stmt.name, val_reg);
        if (declared_type) {
            set_register_language_type(val_reg, declared_type);
            set_register_abi_type(val_reg, language_type_to_abi_type(declared_type));
        }
        LIR_Inst store_inst(LIR_Op::StoreGlobal, Type::Void, 0, val_reg, 0);
        store_inst.func_name = qualified_name;
        emit_instruction(store_inst);
        return;
    }

    Reg value_reg;
    
    if (stmt.initializer) {
        Reg value = 0;
        if (auto literal = dynamic_cast<LM::Frontend::AST::LiteralExpr*>(stmt.initializer.get())) {
            value = emit_literal_expr(*literal, declared_type);
        } else {
            value = emit_expr(*stmt.initializer);
        }

        bool is_literal = (dynamic_cast<LM::Frontend::AST::LiteralExpr*>(stmt.initializer.get()) != nullptr);
        bool is_immutable = stmt.isConst;
        bool is_var_alias = is_variable_alias_expr(stmt.initializer.get());

        if (is_literal || (is_immutable && !is_var_alias)) {
            value_reg = value;
        } else {
            value_reg = allocate_register();
            Type abi_type = language_type_to_abi_type(stmt.inferred_type);
            emit_instruction(LIR_Inst(LIR_Op::Mov, abi_type, value_reg, value, 0));
        }
        
        if (declared_type) {
            set_register_type(value_reg, declared_type);
        } else {
            set_register_type(value_reg, stmt.initializer->inferred_type);
        }
    } else {
        // Initialize with nil
        value_reg = allocate_register();
        auto nil_type = std::make_shared<::Type>(::TypeTag::Nil);
        Backend::Value nil_val = VAL_NIL;
        Type abi_type = language_type_to_abi_type(stmt.inferred_type);
        emit_instruction(LIR_Inst(LIR_Op::LoadConst, abi_type, value_reg, nil_val));
        set_register_type(value_reg, nil_type);
    }
   // std::cout << "[DEBUG] Binding variable: " << stmt.name << " to register " << value_reg << std::endl;
    bind_variable(stmt.name, value_reg);
   // std::cout << "[DEBUG] emit_var_stmt completed for: " << stmt.name << std::endl;
}
void Generator::emit_destructuring_var_stmt(LM::Frontend::AST::DestructuringDeclaration& stmt) {
    Reg init_reg = emit_expr(*stmt.initializer);
    TypePtr init_type = stmt.initializer ? stmt.initializer->inferred_type : nullptr;
    
    if (!init_type) {
        init_type = get_register_language_type(init_reg);
    }

    if (init_type && init_type->tag == ::TypeTag::Tuple) {
        auto* tuple_type = std::get_if<TupleType>(&init_type->extra);
        if (tuple_type) {
            for (size_t i = 0; i < std::min(stmt.names.size(), tuple_type->elementTypes.size()); ++i) {
                Reg val_reg = allocate_register();
                Reg index_reg = allocate_register();
                auto int_type = std::make_shared<::Type>(::TypeTag::Int64);
                Backend::Value index_val = make_i64(i);
                emit_instruction(LIR_Inst(LIR_Op::LoadConst, Type::I64, index_reg, index_val));
                set_register_type(index_reg, int_type);
                
                Type abi_type = language_type_to_abi_type(tuple_type->elementTypes[i]);
                emit_instruction(LIR_Inst(LIR_Op::TupleGet, abi_type, val_reg, init_reg, index_reg));
                set_register_language_type(val_reg, tuple_type->elementTypes[i]);
                bind_variable(stmt.names[i], val_reg);
            }
        }
    } else if (init_type && (init_type->tag == ::TypeTag::List || init_type->tag == ::TypeTag::Any)) {
        TypePtr elem_type = (init_type->tag == ::TypeTag::List) ? 
            std::get<ListType>(init_type->extra).elementType : 
            std::make_shared<::Type>(::TypeTag::Any);

        for (size_t i = 0; i < stmt.names.size(); ++i) {
            Reg val_reg = allocate_register();
            Reg index_reg = allocate_register();
            auto int_type = std::make_shared<::Type>(::TypeTag::Int64);
            Backend::Value index_val = make_i64(i);
            emit_instruction(LIR_Inst(LIR_Op::LoadConst, Type::I64, index_reg, index_val));
            set_register_type(index_reg, int_type);
            
            Type abi_type = language_type_to_abi_type(elem_type);
            // Use ListIndex as the generic indexer for List/Any
            emit_instruction(LIR_Inst(LIR_Op::ListIndex, abi_type, val_reg, init_reg, index_reg));
            set_register_language_type(val_reg, elem_type);
            bind_variable(stmt.names[i], val_reg);
        }
    } else {
        // Fallback: Bind to nil if type is unknown or unsupported
        for (const auto& name : stmt.names) {
            Reg val_reg = allocate_register();
            Backend::Value nil_val = VAL_NIL;
            emit_instruction(LIR_Inst(LIR_Op::LoadConst, Type::Void, val_reg, nil_val));
            bind_variable(name, val_reg);
        }
    }
}


void Generator::emit_block_stmt(LM::Frontend::AST::BlockStatement& stmt) {
    enter_scope();
    for (const auto& block_stmt : stmt.statements) {
        if (m_is_terminated) break;
        emit_stmt(*block_stmt);
    }
    exit_scope();
}


void Generator::emit_if_stmt(LM::Frontend::AST::IfStatement& stmt) {
    bool prev_in_control_flow = cfg_context_.in_control_flow;
    cfg_context_.in_control_flow = true;
    
    if (cfg_context_.building_cfg) {
        // CFG mode: create basic blocks
        emit_if_stmt_cfg(stmt);
    } else {
        // Linear mode: use conditional jumps
        emit_if_stmt_linear(stmt);
    }
    
    cfg_context_.in_control_flow = prev_in_control_flow;
}


void Generator::emit_if_stmt_cfg(LM::Frontend::AST::IfStatement& stmt) {
    // CFG mode: create basic blocks
    LIR_BasicBlock* then_block = create_basic_block("if_then");
    LIR_BasicBlock* else_block = stmt.elseBranch ? create_basic_block("if_else") : nullptr;
    LIR_BasicBlock* end_block = create_basic_block("if_end");
    
    // Emit condition check in current block
    Reg condition = emit_expr(*stmt.condition);
    Reg condition_bool = condition;
    
    // Conditional jump: if false, go to else (or end if no else)
    uint32_t false_target = else_block ? else_block->id : end_block->id;
    emit_instruction(LIR_Inst(LIR_Op::JumpIfFalse, 0, condition_bool, 0, false_target));
    
    // Set up edges from current block
    add_block_edge(get_current_block(), then_block);
    if (else_block) {
        add_block_edge(get_current_block(), else_block);
    } else {
        add_block_edge(get_current_block(), end_block);
    }
    
    // === Then Block ===
    set_current_block(then_block);
    
    // Emit then branch
    if (stmt.thenBranch) {
        emit_stmt(*stmt.thenBranch);
    }
    
    // Jump to end after then branch (only if no terminator already exists)
    if (get_current_block() && !get_current_block()->has_terminator()) {
        emit_instruction(LIR_Inst(LIR_Op::Jump, 0, 0, 0, end_block->id));
        add_block_edge(get_current_block(), end_block);  // Add CFG edge from CURRENT block (which might have changed)
    }
    
    // === Else Block (if present) ===
    if (else_block) {
        set_current_block(else_block);
        
        // Emit else branch
        if (stmt.elseBranch) {
            emit_stmt(*stmt.elseBranch);
        }
        
        // Jump to end after else branch (only if no terminator already exists)
        if (get_current_block() && !get_current_block()->has_terminator()) {
            emit_instruction(LIR_Inst(LIR_Op::Jump, 0, 0, 0, end_block->id));
            add_block_edge(get_current_block(), end_block);  // Add CFG edge
        }
    } else {
        // No else block, add edge from condition block to end block
        // (This was missing in some cases where JumpIfFalse target was end_block)
    }
    
    // === End Block: continuation ===
    set_current_block(end_block);
    
    // Don't mark end_block as terminated - it's a continuation point for subsequent statements
    // Only mark as terminated if it has explicit terminator instructions
    if (end_block && end_block->has_terminator()) {
        end_block->terminated = true;
    }
}



void Generator::emit_if_stmt_linear(LM::Frontend::AST::IfStatement& stmt) {
    Reg condition = emit_expr(*stmt.condition);
    Reg condition_bool = condition;
    
    // Reserve space for jump instructions
    size_t false_jump_pc = current_function_->instructions.size();
    emit_instruction(LIR_Inst(LIR_Op::JumpIfFalse, 0, condition_bool, 0)); // Placeholder target
    
    // Emit then branch
    emit_stmt(*stmt.thenBranch);
    bool then_terminated = m_is_terminated;
    
    if (stmt.elseBranch) {
        // Reserve space for jump to end
        size_t end_jump_pc = 0;
        if (!then_terminated) {
            end_jump_pc = current_function_->instructions.size();
            emit_instruction(LIR_Inst(LIR_Op::Jump, 0)); // Placeholder target
        }
        
        // Update false jump to point to else branch
        size_t else_start_pc = current_function_->instructions.size();
        current_function_->instructions[false_jump_pc].imm = else_start_pc;
        
        m_is_terminated = false;

        // Emit else branch
        emit_stmt(*stmt.elseBranch);
        bool else_terminated = m_is_terminated;
        
        // Update end jump to point after else branch
        size_t end_pc = current_function_->instructions.size();
        if (!then_terminated) {
            current_function_->instructions[end_jump_pc].imm = end_pc;
        }

        m_is_terminated = then_terminated && else_terminated;
    } else {
        // No else branch - the false jump should skip the then branch
        size_t end_pc = current_function_->instructions.size();
        current_function_->instructions[false_jump_pc].imm = end_pc;

        m_is_terminated = false;
    }
}


void Generator::emit_while_stmt(LM::Frontend::AST::WhileStatement& stmt) {
    bool prev_in_control_flow = cfg_context_.in_control_flow;
    cfg_context_.in_control_flow = true;
    
    if (cfg_context_.building_cfg) {
        // CFG mode: create basic blocks
        emit_while_stmt_cfg(stmt);
    } else {
        // Linear mode: use loop instructions
        emit_while_stmt_linear(stmt);
    }
    
    cfg_context_.in_control_flow = prev_in_control_flow;
}


void Generator::emit_while_stmt_cfg(LM::Frontend::AST::WhileStatement& stmt) {
    // CFG mode: create basic blocks for while loop
    enter_scope();
    enter_loop();
    
    LIR_BasicBlock* header_block = create_basic_block("while_header");
    LIR_BasicBlock* body_block = create_basic_block("while_body");
    LIR_BasicBlock* end_block = create_basic_block("while_end");
    
    // Set loop labels for break/continue
    set_loop_labels(header_block->id, end_block->id, header_block->id);
    
    // Connect current block to header block
    add_block_edge(get_current_block(), header_block);
    emit_instruction(LIR_Inst(LIR_Op::Jump, 0, 0, 0, header_block->id));
    
    // Emit condition check in header block
    set_current_block(header_block);
    
    // Emit loop condition
    Reg condition = emit_expr(*stmt.condition);
    Reg condition_bool = condition;
    
    // Conditional jump: if false, exit loop
    emit_instruction(LIR_Inst(LIR_Op::JumpIfFalse, 0, condition_bool, 0, end_block->id));
    
    // Set up edges from header block
    add_block_edge(get_current_block(), body_block);  // Continue if true
    add_block_edge(get_current_block(), end_block);   // Exit if false
    
    // === Body Block ===
    set_current_block(body_block);
    
    // Emit loop body
    if (stmt.body) {
        emit_stmt(*stmt.body);
    }
    
    // Jump back to header to continue loop
    if (get_current_block() && !get_current_block()->has_terminator()) {
        emit_instruction(LIR_Inst(LIR_Op::Jump, 0, 0, 0, header_block->id));
        add_block_edge(get_current_block(), header_block);
    }
    
    // === End Block: continuation ===
    set_current_block(end_block);
    
    exit_loop();
    exit_scope();
    
    // Don't mark end_block as terminated - it's a continuation point for subsequent statements
    // Only mark as terminated if it has explicit terminator instructions
    if (end_block && end_block->has_terminator()) {
        end_block->terminated = true;
    }
}


void Generator::emit_while_stmt_linear(LM::Frontend::AST::WhileStatement& stmt) {
    enter_scope();
    enter_loop();

    Imm cond_label = (Imm)current_function_->instructions.size();
    // In linear mode, continue should jump to condition re-evaluation.
    set_loop_labels(static_cast<uint32_t>(cond_label), INVALID_LOOP_LABEL, static_cast<uint32_t>(cond_label));
    Reg cond_reg = emit_expr(*stmt.condition);
    
    size_t jump_to_patch = current_function_->instructions.size();
    emit_instruction(LIR_Inst(LIR_Op::JumpIfFalse, Type::Void, 0, cond_reg, 0, 0));

    if (stmt.body) emit_stmt(*stmt.body);

    emit_instruction(LIR_Inst(LIR_Op::Jump, Type::Void, 0, 0, 0, cond_label));

    Imm end_label = (Imm)current_function_->instructions.size();
    // Patch break target once loop end is known.
    set_loop_labels(static_cast<uint32_t>(cond_label), static_cast<uint32_t>(end_label), static_cast<uint32_t>(cond_label));
    current_function_->instructions[jump_to_patch].imm = end_label;

    exit_loop();
    exit_scope();
}


void Generator::emit_for_stmt(LM::Frontend::AST::ForStatement& stmt) {
    bool prev_in_control_flow = cfg_context_.in_control_flow;
    cfg_context_.in_control_flow = true;
    
    if (cfg_context_.building_cfg) {
        // CFG mode: create basic blocks
        emit_for_stmt_cfg(stmt);
    } else {
        // Linear mode: use loop instructions
        emit_for_stmt_linear(stmt);
    }
    
    cfg_context_.in_control_flow = prev_in_control_flow;
}


void Generator::emit_for_stmt_cfg(LM::Frontend::AST::ForStatement& stmt) {
    // CFG mode: create basic blocks for for loop
    enter_scope();
    enter_loop();
    
    LIR_BasicBlock* init_block = create_basic_block("for_init");
    LIR_BasicBlock* header_block = create_basic_block("for_header");
    LIR_BasicBlock* body_block = create_basic_block("for_body");
    LIR_BasicBlock* increment_block = create_basic_block("for_increment");
    LIR_BasicBlock* end_block = create_basic_block("for_end");
    
    // Set loop labels for break/continue
    set_loop_labels(header_block->id, end_block->id, increment_block->id);
    
    // Connect current block to init block
    add_block_edge(get_current_block(), init_block);
    emit_instruction(LIR_Inst(LIR_Op::Jump, 0, 0, 0, init_block->id));
    
    // === Init Block (executed only once) ===
    set_current_block(init_block);
    
    if (stmt.initializer) {
        emit_stmt(*stmt.initializer);
    }
    
    // Jump to header after initialization
    emit_instruction(LIR_Inst(LIR_Op::Jump, 0, 0, 0, header_block->id));
    add_block_edge(init_block, header_block);
    
    // === Header Block (executed each iteration) ===
    set_current_block(header_block);
    
    // Emit condition check
    Reg condition = allocate_register();
    if (stmt.condition) {
        condition = emit_expr(*stmt.condition);
    } else {
        // No condition - always true
        auto bool_type = std::make_shared<::Type>(::TypeTag::Bool);
        Backend::Value true_val = VAL_TRUE;
        emit_instruction(LIR_Inst(LIR_Op::LoadConst, LIR::Type::Bool, condition, true_val));
        set_register_type(condition, bool_type);
    }
    
    // Conditional jump: if false, exit loop
    emit_instruction(LIR_Inst(LIR_Op::JumpIfFalse, 0, condition, 0, end_block->id));
    
    // Set up edges from header block
    add_block_edge(get_current_block(), body_block);  // Continue if true
    add_block_edge(get_current_block(), end_block);   // Exit if false
    
    // === Body Block ===
    set_current_block(body_block);
    
    // Emit loop body
    if (stmt.body) {
        emit_stmt(*stmt.body);
    }
    
    // Jump to increment block
    if (get_current_block() && !get_current_block()->has_terminator()) {
        emit_instruction(LIR_Inst(LIR_Op::Jump, 0, 0, 0, increment_block->id));
        add_block_edge(get_current_block(), increment_block);
    }
    
    // === Increment Block ===
    set_current_block(increment_block);
    
    // Emit increment - for loop increment is typically an assignment expression
    if (stmt.increment) {
        // Create an expression statement from increment expression
        LM::Frontend::AST::ExprStatement expr_stmt;
        expr_stmt.expression = stmt.increment;
        emit_stmt(expr_stmt);
    }
    
    // Jump back to header to continue loop
    if (get_current_block() && !get_current_block()->has_terminator()) {
        emit_instruction(LIR_Inst(LIR_Op::Jump, 0, 0, 0, header_block->id));
        add_block_edge(increment_block, header_block);
    }
    
    // === End Block: continuation ===
    set_current_block(end_block);
    
    exit_loop();
    exit_scope();
    
    // Don't mark end_block as terminated - it's a continuation point for subsequent statements
    // Only mark as terminated if it has explicit terminator instructions
    if (end_block && end_block->has_terminator()) {
        end_block->terminated = true;
    }
}


void Generator::emit_for_stmt_linear(LM::Frontend::AST::ForStatement& stmt) {
    enter_scope();
    enter_loop();
    if (stmt.initializer) emit_stmt(*stmt.initializer);
    
    Imm cond_label = (Imm)current_function_->instructions.size();
    Imm increment_label = cond_label;
    Reg cond_reg = 0;
    size_t jump_to_patch = 0;
    bool has_cond = false;
    
    if (stmt.condition) {
        cond_reg = emit_expr(*stmt.condition);
        jump_to_patch = current_function_->instructions.size();
        emit_instruction(LIR_Inst(LIR_Op::JumpIfFalse, Type::Void, 0, cond_reg, 0, 0));
        has_cond = true;
    }
    
    if (stmt.body) emit_stmt(*stmt.body);
    increment_label = static_cast<Imm>(current_function_->instructions.size());
    set_loop_labels(static_cast<uint32_t>(cond_label), INVALID_LOOP_LABEL, static_cast<uint32_t>(increment_label));
    if (stmt.increment) emit_expr(*stmt.increment);

    emit_instruction(LIR_Inst(LIR_Op::Jump, Type::Void, 0, 0, 0, cond_label));

    Imm end_label = (Imm)current_function_->instructions.size();
    set_loop_labels(static_cast<uint32_t>(cond_label), static_cast<uint32_t>(end_label), static_cast<uint32_t>(increment_label));
    if (has_cond) {
        current_function_->instructions[jump_to_patch].imm = end_label;
    }
    exit_loop();
    exit_scope();
}


void Generator::emit_return_stmt(LM::Frontend::AST::ReturnStatement& stmt) {
    if (else_context_.in_else_block) {
        // Inside an else block - store the value in the result register instead of returning
        if (stmt.value) {
            Reg value = emit_expr(*stmt.value);
            // Move the value to the result register
            emit_instruction(LIR_Inst(LIR_Op::Mov, Type::Ptr, else_context_.result_register, value, 0));
        } else {
            // No value - store a default value (0)
            auto nil_type = std::make_shared<::Type>(::TypeTag::Nil);
            emit_instruction(LIR_Inst(LIR_Op::LoadConst, Type::Void, else_context_.result_register,
                                      VAL_NIL));
        }
        // Don't emit a return instruction - let the else block continue
    } else {
        // Normal return statement
        if (stmt.value) {
            Reg value = emit_expr(*stmt.value);
            
            LIR_Inst ret_inst(LIR_Op::Return);
            ret_inst.a = value;
            emit_instruction(ret_inst);
        } else {
            emit_instruction(LIR_Inst(LIR_Op::Return, Type::Void, 0, UINT32_MAX, 0));
        }
        m_is_terminated = true;
    }
}


void Generator::emit_func_stmt(LM::Frontend::AST::FunctionDeclaration& stmt) {
   // std::cout << "[DEBUG] LIR Generator: Processing function declaration '" << stmt.name << "'" << std::endl;
    
    // Collect parameter registers
    std::vector<Reg> param_regs;
    for (size_t i = 0; i < stmt.params.size(); ++i) {
        param_regs.push_back(static_cast<Reg>(i));
    }
    
    // Determine return register (if function has return type)
    Reg return_reg = 0;
    if (stmt.returnType.has_value()) {
        return_reg = static_cast<Reg>(stmt.params.size()); // Return register comes after parameters
    }
    
    // Emit function definition using new format: fn r2, add(r0, r1) {
    emit_instruction(LIR_Inst(LIR_Op::FuncDef, stmt.name, param_regs, return_reg));
    
    // Generate function body (this will be handled by the separate function generation pass)
}


void Generator::emit_import_stmt(LM::Frontend::AST::ImportStatement& stmt) {
    // Smart import resolution - just update alias map, no LIR emission
    std::string alias = stmt.alias.value_or(stmt.modulePath);
    import_aliases_[alias] = stmt.modulePath;
    
    // Ensure the imported module is initialized by calling its __init__ function
    // This is needed because module globals are stored in the VM's globals_ map
    // and need to be initialized before they can be accessed
    std::string init_func_name = stmt.modulePath + ".__init__";
    if (current_function_ && (LIRFunctionManager::getInstance().hasFunction(init_func_name) || function_table_.count(init_func_name))) {
        std::vector<Reg> empty_args;
        Reg dummy_res = allocate_register();
        emit_instruction(LIR_Inst(LIR_Op::Call, dummy_res, init_func_name, empty_args));
    }
    
   // std::cout << "[DEBUG] Import registered: " << alias << " -> " << stmt.modulePath << std::endl;
}


void Generator::emit_contract_stmt(LM::Frontend::AST::ContractStatement& stmt) {
    if (!stmt.condition) return;
    if (stmt.verification_state == LM::Frontend::AST::ContractVerificationState::StaticallyProven) {
        // Statically proven contract — elide runtime check instruction entirely
        return;
    }
    long long val_int = 0;
    double val_double = 0.0;
    bool is_int = false;
    if (LM::Frontend::evaluate_const_expr(stmt.condition, val_int, val_double, is_int)) {
        bool cond_true = is_int ? (val_int != 0) : (val_double != 0.0);
        if (cond_true) {
            // Statically verified contract — no runtime check needed!
            return;
        }
    }
    Reg cond_reg = emit_expr(*stmt.condition);
    Reg msg_reg = stmt.message ? emit_expr(*stmt.message) : 0;

    LIR_Inst inst(LIR_Op::CallBuiltin, Type::Void, 0, 0, 0);
    inst.func_name = "assert";
    inst.call_args.push_back(cond_reg);
    if (msg_reg != 0) {
        inst.call_args.push_back(msg_reg);
    }
    emit_instruction(inst);
}


void Generator::emit_staged_stmt(LM::Frontend::AST::StagedStatement& stmt) {
    if (stmt.declaration) {
        emit_stmt(*stmt.declaration);
    } else if (stmt.block) {
        emit_stmt(*stmt.block);
    } else if (stmt.expression) {
        emit_expr(*stmt.expression);
    }
}

void Generator::emit_staged_block(LM::Frontend::AST::StagedBlockStatement& stmt) {
    if (stmt.body) {
        emit_stmt(*stmt.body);
    }
}


void Generator::emit_iter_stmt(LM::Frontend::AST::IterStatement& stmt) {
    auto range_expr = dynamic_cast<LM::Frontend::AST::RangeExpr*>(stmt.iterable.get());
    auto var_expr = dynamic_cast<LM::Frontend::AST::VariableExpr*>(stmt.iterable.get());
    auto list_expr = dynamic_cast<LM::Frontend::AST::ListExpr*>(stmt.iterable.get());
    auto dict_expr = dynamic_cast<LM::Frontend::AST::DictExpr*>(stmt.iterable.get());
    auto tuple_expr = dynamic_cast<LM::Frontend::AST::TupleExpr*>(stmt.iterable.get());
    
    if (range_expr) {
        // Handle range iteration (existing logic)
        if (stmt.loopVars.size() != 1) {
            report_error("iter statement currently supports only one loop variable");
            return;
        }
        const std::string& loop_var_name = stmt.loopVars[0];

        LIR_BasicBlock* header_block = create_basic_block("iter_header");
        LIR_BasicBlock* body_block = create_basic_block("iter_body");
        LIR_BasicBlock* increment_block = create_basic_block("iter_increment");
        LIR_BasicBlock* exit_block = create_basic_block("iter_exit");

        enter_scope();
        enter_loop();
        set_loop_labels(header_block->id, exit_block->id, increment_block->id);

        Reg loop_var_reg = allocate_register();
        bind_variable(loop_var_name, loop_var_reg);

        Reg start_reg = emit_expr(*range_expr->start);
        emit_instruction(LIR_Inst(LIR_Op::Mov, loop_var_reg, start_reg, 0));
        set_register_type(loop_var_reg, get_register_type(start_reg));

        emit_instruction(LIR_Inst(LIR_Op::Jump, 0, 0, 0, header_block->id));
        add_block_edge(get_current_block(), header_block);

        set_current_block(header_block);
        Reg end_reg = emit_expr(*range_expr->end);
        Reg cmp_reg = allocate_register();
        emit_instruction(LIR_Inst(LIR_Op::CmpLT, cmp_reg, loop_var_reg, end_reg));
        set_register_type(cmp_reg, std::make_shared<::Type>(::TypeTag::Bool));
        emit_instruction(LIR_Inst(LIR_Op::JumpIfFalse, 0, cmp_reg, 0, exit_block->id));
        add_block_edge(header_block, body_block);
        add_block_edge(header_block, exit_block);

        set_current_block(body_block);
        if (stmt.body) {
            emit_stmt(*stmt.body);
        }
        emit_instruction(LIR_Inst(LIR_Op::Jump, 0, 0, 0, increment_block->id));
        add_block_edge(get_current_block(), increment_block);

        set_current_block(increment_block);
        Reg step_reg;
        if (range_expr->step) {
            step_reg = emit_expr(*range_expr->step);
        } else {
            step_reg = allocate_register();
            auto int_type = std::make_shared<::Type>(::TypeTag::Int64);
            Backend::Value one_val = make_i64(1);
            emit_instruction(LIR_Inst(LIR_Op::LoadConst, Type::I64, step_reg, one_val));
            set_register_type(step_reg, int_type);
        }
        Reg new_val_reg = allocate_register();
        emit_instruction(LIR_Inst(LIR_Op::Add, new_val_reg, loop_var_reg, step_reg));
        emit_instruction(LIR_Inst(LIR_Op::Mov, loop_var_reg, new_val_reg, 0));
        emit_instruction(LIR_Inst(LIR_Op::Jump, 0, 0, 0, header_block->id));
        add_block_edge(increment_block, header_block);

        set_current_block(exit_block);
        exit_loop();
        exit_scope();
        
    } else if (list_expr) {
        emit_list_iter_stmt(stmt, *list_expr);
        
    } else if (dict_expr) {
        emit_dict_iter_stmt(stmt, *dict_expr);
        
    } else if (tuple_expr) {
        emit_tuple_iter_stmt(stmt, *tuple_expr);
        
    } else if (var_expr) {
        // Handle variable-based iteration (could be list, dict, tuple, or channel)
        // Note: We allow multiple loop variables for dictionary iteration

        // Get the variable and check its type
        Reg iterable_reg = resolve_variable(var_expr->name);
        if (iterable_reg == UINT32_MAX) {
            report_error("Undefined variable: " + var_expr->name);
            return;
        }

        // Get the type of the iterable variable
        TypePtr iterable_type = get_register_type(iterable_reg);
        if (!iterable_type) {
            iterable_type = get_register_language_type(iterable_reg);
        }
        if (!iterable_type && var_expr->inferred_type) {
            iterable_type = var_expr->inferred_type;
        }
        if (!iterable_type) {
            report_error("Cannot determine type of variable: " + var_expr->name);
            return;
        }

        // Check if it's a list, dict, tuple, or channel
        if (iterable_type->tag == TypeTag::List) {
            emit_list_var_iter_stmt(stmt, iterable_reg);
            
        } else if (iterable_type->tag == TypeTag::String) {
            emit_string_var_iter_stmt(stmt, iterable_reg);
            
        } else if (iterable_type->tag == TypeTag::Dict) {
            emit_dict_var_iter_stmt(stmt, iterable_reg);
            
        } else if (iterable_type->tag == TypeTag::Tuple) {
            // Get tuple size from type system
            auto* tuple_type_ptr = std::get_if<TupleType>(&iterable_type->extra);
            if (tuple_type_ptr) {
                int64_t tuple_len = static_cast<int64_t>(tuple_type_ptr->elementTypes.size());
                emit_tuple_var_iter_stmt(stmt, iterable_reg, tuple_len);
            } else {
                emit_tuple_var_iter_stmt(stmt, iterable_reg, 0);
            }
            
        } else {
            // Handle channel iteration - requires exactly one loop variable
            if (stmt.loopVars.size() != 1) {
                report_error("channel iteration requires exactly one loop variable");
                return;
            }
            const std::string& loop_var_name = stmt.loopVars[0];
            
            // Handle channel iteration (existing logic)
            LIR_BasicBlock* header_block = create_basic_block("channel_iter_header");
            LIR_BasicBlock* body_block = create_basic_block("channel_iter_body");
            LIR_BasicBlock* exit_block = create_basic_block("channel_iter_exit");

            enter_scope();
            enter_loop();
            set_loop_labels(header_block->id, exit_block->id, 0);

            // Bind loop variable
            Reg loop_var_reg = allocate_register();
            bind_variable(loop_var_name, loop_var_reg);

            // Jump to header
            emit_instruction(LIR_Inst(LIR_Op::Jump, 0, 0, 0, header_block->id));
            add_block_edge(get_current_block(), header_block);

            set_current_block(header_block);
            // Non-blocking channel poll
            Reg poll_reg = allocate_register();
            emit_instruction(LIR_Inst(LIR_Op::ChannelPoll, poll_reg, iterable_reg, 0));
            set_register_type(poll_reg, std::make_shared<::Type>(::TypeTag::Any));
            
            // Create nil constant for comparison
            Reg nil_reg = allocate_register();
            auto nil_type = std::make_shared<::Type>(::TypeTag::Nil);
            Backend::Value nil_val = VAL_NIL;
            emit_instruction(LIR_Inst(LIR_Op::LoadConst, Type::Void, nil_reg, nil_val));
            set_register_type(nil_reg, nil_type);
            
            // Compare poll result with nil
            Reg is_nil_reg = allocate_register();
            emit_instruction(LIR_Inst(LIR_Op::CmpEQ, is_nil_reg, poll_reg, nil_reg));
            set_register_type(is_nil_reg, std::make_shared<::Type>(::TypeTag::Bool));
            
            // Jump to exit if poll result is nil (channel empty/closed)
            emit_instruction(LIR_Inst(LIR_Op::JumpIf, 0, is_nil_reg, 0, exit_block->id));
            add_block_edge(header_block, body_block);
            add_block_edge(header_block, exit_block);

            set_current_block(body_block);
            // Use the polled value
            emit_instruction(LIR_Inst(LIR_Op::Mov, loop_var_reg, poll_reg, 0));
            set_register_type(loop_var_reg, std::make_shared<::Type>(::TypeTag::Any));
            
            // Execute loop body
            if (stmt.body) {
                emit_stmt(*stmt.body);
            }
            
            // Jump back to header
            emit_instruction(LIR_Inst(LIR_Op::Jump, 0, 0, 0, header_block->id));
            add_block_edge(get_current_block(), header_block);

            set_current_block(exit_block);
            exit_loop();
            exit_scope();
        }
        
    } else {
        report_error("iter statement supports range expressions, lists, dicts, tuples, and channel variables");
    }
}


void Generator::emit_dict_iter_stmt(LM::Frontend::AST::IterStatement& stmt, LM::Frontend::AST::DictExpr& dict_expr) {
    // Handle dict iteration (simplified - iterate over keys)
    if (stmt.loopVars.size() != 1) {
        report_error("dict iteration currently supports only one loop variable");
        return;
    }
    const std::string& loop_var_name = stmt.loopVars[0];

    LIR_BasicBlock* header_block = create_basic_block("dict_iter_header");
    LIR_BasicBlock* body_block = create_basic_block("dict_iter_body");
    LIR_BasicBlock* exit_block = create_basic_block("dict_iter_exit");

    enter_scope();
    enter_loop();
    set_loop_labels(header_block->id, exit_block->id, 0);

    // Create the dict
    Reg dict_reg = emit_dict_expr(dict_expr);
    
    // Bind loop variable
    Reg loop_var_reg = allocate_register();
    bind_variable(loop_var_name, loop_var_reg);

    // Initialize index to 0
    Reg index_reg = allocate_register();
    auto int_type = std::make_shared<::Type>(::TypeTag::Int64);
    Backend::Value zero_val = make_i64(0);
    emit_instruction(LIR_Inst(LIR_Op::LoadConst, Type::I64, index_reg, zero_val));
    set_register_type(index_reg, int_type);

    // Jump to header
    emit_instruction(LIR_Inst(LIR_Op::Jump, 0, 0, 0, header_block->id));
    add_block_edge(get_current_block(), header_block);

    set_current_block(header_block);
    
    // Get dict size using entry count from AST
    Reg size_reg = allocate_register();
    auto size_type = std::make_shared<::Type>(::TypeTag::Int64);
    Backend::Value size_val = make_i64(dict_expr.entries.size());
    emit_instruction(LIR_Inst(LIR_Op::LoadConst, Type::I64, size_reg, size_val));
    set_register_type(size_reg, size_type);
    
    // Compare index with size
    Reg cmp_reg = allocate_register();
    emit_instruction(LIR_Inst(LIR_Op::CmpLT, cmp_reg, index_reg, size_reg));
    set_register_type(cmp_reg, std::make_shared<::Type>(::TypeTag::Bool));
    
    // Jump to exit if index >= size
    emit_instruction(LIR_Inst(LIR_Op::JumpIfFalse, 0, cmp_reg, 0, exit_block->id));
    add_block_edge(header_block, body_block);
    add_block_edge(header_block, exit_block);

    set_current_block(body_block);
    
    // For a more realistic implementation, we need to extract keys from the dict at runtime
    // For now, we'll use a simplified approach that creates keys based on the index
    // In a full implementation, this would involve proper dict key extraction methods
    
    // Extract key from dict at current index
    Reg key_reg = allocate_register();
    auto key_type = std::make_shared<::Type>(::TypeTag::String);
    LIR_Inst call_inst(LIR_Op::DictItems, Type::Ptr, key_reg, 0, 0);
    call_inst.call_args = {dict_reg, index_reg};
    emit_instruction(call_inst);
    set_register_type(key_reg, key_type);
    
    // Move key to loop variable
    emit_instruction(LIR_Inst(LIR_Op::Mov, loop_var_reg, key_reg, 0));
    set_register_type(loop_var_reg, key_type);
    
    // Execute loop body
    if (stmt.body) {
        emit_stmt(*stmt.body);
    }
    
    // Increment index
    Reg one_reg = allocate_register();
    Backend::Value one_val = make_i64(1);
    emit_instruction(LIR_Inst(LIR_Op::LoadConst, Type::I64, one_reg, one_val));
    set_register_type(one_reg, int_type);
    
    Reg new_index_reg = allocate_register();
    emit_instruction(LIR_Inst(LIR_Op::Add, new_index_reg, index_reg, one_reg));
    emit_instruction(LIR_Inst(LIR_Op::Mov, index_reg, new_index_reg, 0));
    
    // Jump back to header
    emit_instruction(LIR_Inst(LIR_Op::Jump, 0, 0, 0, header_block->id));
    add_block_edge(get_current_block(), header_block);

    set_current_block(exit_block);
    exit_loop();
    exit_scope();
}


void Generator::emit_list_iter_stmt(LM::Frontend::AST::IterStatement& stmt, LM::Frontend::AST::ListExpr& list_expr) {
    // Handle list iteration
    if (stmt.loopVars.size() != 1) {
        report_error("list iteration currently supports only one loop variable");
        return;
    }
    const std::string& loop_var_name = stmt.loopVars[0];

    LIR_BasicBlock* header_block = create_basic_block("list_iter_header");
    LIR_BasicBlock* body_block = create_basic_block("list_iter_body");
    LIR_BasicBlock* exit_block = create_basic_block("list_iter_exit");

    enter_scope();
    enter_loop();
    set_loop_labels(header_block->id, exit_block->id, 0);

    // Create the list
    Reg list_reg = emit_list_expr(list_expr);
    
    // Bind loop variable
    Reg loop_var_reg = allocate_register();
    bind_variable(loop_var_name, loop_var_reg);

    // Initialize index to 0
    Reg index_reg = allocate_register();
    auto int_type = std::make_shared<::Type>(::TypeTag::Int64);
    Backend::Value zero_val = make_i64(0);
    emit_instruction(LIR_Inst(LIR_Op::LoadConst, Type::I64, index_reg, zero_val));
    set_register_type(index_reg, int_type);

    // Jump to header
    emit_instruction(LIR_Inst(LIR_Op::Jump, 0, 0, 0, header_block->id));
    add_block_edge(get_current_block(), header_block);

    set_current_block(header_block);
    
    // Get list length using element count from AST
    Reg len_reg = allocate_register();
    auto len_type = std::make_shared<::Type>(::TypeTag::Int64);
    Backend::Value len_val = make_i64(list_expr.elements.size());
    emit_instruction(LIR_Inst(LIR_Op::LoadConst, Type::I64, len_reg, len_val));
    set_register_type(len_reg, len_type);
    
    // Compare index with length
    Reg cmp_reg = allocate_register();
    emit_instruction(LIR_Inst(LIR_Op::CmpLT, cmp_reg, index_reg, len_reg));
    set_register_type(cmp_reg, std::make_shared<::Type>(::TypeTag::Bool));
    
    // Jump to exit if index >= length
    emit_instruction(LIR_Inst(LIR_Op::JumpIfFalse, 0, cmp_reg, 0, exit_block->id));
    add_block_edge(header_block, body_block);
    add_block_edge(header_block, exit_block);

    set_current_block(body_block);
    
    // Get element at current index
    Reg elem_reg = allocate_register();
    emit_instruction(LIR_Inst(LIR_Op::ListIndex, Type::Ptr, elem_reg, list_reg, index_reg));
    set_register_type(elem_reg, std::make_shared<::Type>(::TypeTag::Any));
    
    // Move element to loop variable
    emit_instruction(LIR_Inst(LIR_Op::Mov, loop_var_reg, elem_reg, 0));
    set_register_type(loop_var_reg, std::make_shared<::Type>(::TypeTag::Any));
    
    // Execute loop body
    if (stmt.body) {
        emit_stmt(*stmt.body);
    }
    
    // Increment index
    Reg one_reg = allocate_register();
    Backend::Value one_val = make_i64(1);
    emit_instruction(LIR_Inst(LIR_Op::LoadConst, Type::I64, one_reg, one_val));
    set_register_type(one_reg, int_type);
    
    Reg new_index_reg = allocate_register();
    emit_instruction(LIR_Inst(LIR_Op::Add, new_index_reg, index_reg, one_reg));
    emit_instruction(LIR_Inst(LIR_Op::Mov, index_reg, new_index_reg, 0));
    
    // Jump back to header
    emit_instruction(LIR_Inst(LIR_Op::Jump, 0, 0, 0, header_block->id));
    add_block_edge(get_current_block(), header_block);

    set_current_block(exit_block);
    exit_loop();
    exit_scope();
}


void Generator::emit_tuple_iter_stmt(LM::Frontend::AST::IterStatement& stmt, LM::Frontend::AST::TupleExpr& tuple_expr) {
    // Handle tuple iteration (similar to list)
    if (stmt.loopVars.size() != 1) {
        report_error("tuple iteration currently supports only one loop variable");
        return;
    }
    const std::string& loop_var_name = stmt.loopVars[0];

    LIR_BasicBlock* header_block = create_basic_block("tuple_iter_header");
    LIR_BasicBlock* body_block = create_basic_block("tuple_iter_body");
    LIR_BasicBlock* exit_block = create_basic_block("tuple_iter_exit");

    enter_scope();
    enter_loop();
    set_loop_labels(header_block->id, exit_block->id, 0);

    // Create the tuple
    Reg tuple_reg = emit_tuple_expr(tuple_expr);
    
    // Bind loop variable
    Reg loop_var_reg = allocate_register();
    bind_variable(loop_var_name, loop_var_reg);

    // Initialize index to 0
    Reg index_reg = allocate_register();
    auto int_type = std::make_shared<::Type>(::TypeTag::Int64);
    Backend::Value zero_val = make_i64(0);
    emit_instruction(LIR_Inst(LIR_Op::LoadConst, Type::I64, index_reg, zero_val));
    set_register_type(index_reg, int_type);

    // Jump to header
    emit_instruction(LIR_Inst(LIR_Op::Jump, 0, 0, 0, header_block->id));
    add_block_edge(get_current_block(), header_block);

    set_current_block(header_block);
    
    // Get tuple size from type system instead of parameter
    Reg len_reg = allocate_register();
    auto len_type = std::make_shared<::Type>(::TypeTag::Int64);
    
    // Extract tuple size from register type
    int64_t tuple_len = tuple_expr.elements.size(); // Default fallback
    
    Backend::Value len_val = make_i64(tuple_len);
    emit_instruction(LIR_Inst(LIR_Op::LoadConst, Type::I64, len_reg, len_val));
    set_register_type(len_reg, len_type);
    
    // Compare index with length
    Reg cmp_reg = allocate_register();
    emit_instruction(LIR_Inst(LIR_Op::CmpLT, cmp_reg, index_reg, len_reg));
    set_register_type(cmp_reg, std::make_shared<::Type>(::TypeTag::Bool));
    
    // Jump to exit if index >= length
    emit_instruction(LIR_Inst(LIR_Op::JumpIfFalse, 0, cmp_reg, 0, exit_block->id));
    add_block_edge(header_block, body_block);
    add_block_edge(header_block, exit_block);

    set_current_block(body_block);
    
    // Get element at current index (tuples use list_index internally)
    Reg elem_reg = allocate_register();
    emit_instruction(LIR_Inst(LIR_Op::TupleGet, Type::Ptr, elem_reg, tuple_reg, index_reg));
    set_register_type(elem_reg, std::make_shared<::Type>(::TypeTag::Any));
    
    // Move element to loop variable
    emit_instruction(LIR_Inst(LIR_Op::Mov, loop_var_reg, elem_reg, 0));
    set_register_type(loop_var_reg, std::make_shared<::Type>(::TypeTag::Any));
    
    // Execute loop body
    if (stmt.body) {
        emit_stmt(*stmt.body);
    }
    
    // Increment index
    Reg one_reg = allocate_register();
    Backend::Value one_val = make_i64(1);
    emit_instruction(LIR_Inst(LIR_Op::LoadConst, Type::I64, one_reg, one_val));
    set_register_type(one_reg, int_type);
    
    Reg new_index_reg = allocate_register();
    emit_instruction(LIR_Inst(LIR_Op::Add, new_index_reg, index_reg, one_reg));
    emit_instruction(LIR_Inst(LIR_Op::Mov, index_reg, new_index_reg, 0));
    
    // Jump back to header
    emit_instruction(LIR_Inst(LIR_Op::Jump, 0, 0, 0, header_block->id));
    add_block_edge(get_current_block(), header_block);

    set_current_block(exit_block);
    exit_loop();
    exit_scope();
}


void Generator::emit_dict_var_iter_stmt(LM::Frontend::AST::IterStatement& stmt, Reg dict_reg) {
    // Convert dict to list of (key, value) tuples using DictItems operation.
    // The runtime does the heavy lifting (walking the hash table).
    LIR::Reg items_reg = allocate_register();
    emit_instruction(LIR_Inst(LIR_Op::DictItems, Type::Ptr, items_reg, dict_reg));

    if (stmt.loopVars.size() == 2) {
        // Destructuring form: iter (k, v in dict) { ... }
        // Iterate the items list and unpack each tuple into k and v.
        const std::string& key_var = stmt.loopVars[0];
        const std::string& val_var = stmt.loopVars[1];

        LIR_BasicBlock* header_block = create_basic_block("dict_var_iter_header");
        LIR_BasicBlock* body_block = create_basic_block("dict_var_iter_body");
        LIR_BasicBlock* exit_block = create_basic_block("dict_var_iter_exit");

        enter_scope();
        enter_loop();
        set_loop_labels(header_block->id, exit_block->id, 0);

        Reg key_reg = allocate_register();
        Reg val_reg = allocate_register();
        bind_variable(key_var, key_reg);
        bind_variable(val_var, val_reg);

        // index = 0
        Reg index_reg = allocate_register();
        auto int_type = std::make_shared<::Type>(::TypeTag::Int64);
        emit_instruction(LIR_Inst(LIR_Op::LoadConst, Type::I64, index_reg, make_i64(0)));
        set_register_type(index_reg, int_type);

        emit_instruction(LIR_Inst(LIR_Op::Jump, 0, 0, 0, header_block->id));
        add_block_edge(get_current_block(), header_block);

        set_current_block(header_block);
        Reg len_reg = allocate_register();
        emit_instruction(LIR_Inst(LIR_Op::ListLen, Type::I64, len_reg, items_reg));
        set_register_type(len_reg, int_type);

        Reg cmp_reg = allocate_register();
        emit_instruction(LIR_Inst(LIR_Op::CmpLT, cmp_reg, index_reg, len_reg));
        set_register_type(cmp_reg, std::make_shared<::Type>(::TypeTag::Bool));

        emit_instruction(LIR_Inst(LIR_Op::JumpIfFalse, 0, cmp_reg, 0, exit_block->id));
        add_block_edge(header_block, body_block);
        add_block_edge(header_block, exit_block);

        set_current_block(body_block);
        // Get the (k, v) tuple at index
        Reg tuple_reg = allocate_register();
        emit_instruction(LIR_Inst(LIR_Op::ListIndex, Type::Ptr, tuple_reg, items_reg, index_reg));
        set_register_type(tuple_reg, std::make_shared<::Type>(::TypeTag::Any));

        // Unpack: tuple[0] = key, tuple[1] = value
        Reg idx0 = allocate_register();
        emit_instruction(LIR_Inst(LIR_Op::LoadConst, Type::I64, idx0, make_i64(0)));
        set_register_type(idx0, int_type);
        emit_instruction(LIR_Inst(LIR_Op::TupleGet, Type::Ptr, key_reg, tuple_reg, idx0));
        set_register_type(key_reg, std::make_shared<::Type>(::TypeTag::Any));

        Reg idx1 = allocate_register();
        emit_instruction(LIR_Inst(LIR_Op::LoadConst, Type::I64, idx1, make_i64(1)));
        set_register_type(idx1, int_type);
        emit_instruction(LIR_Inst(LIR_Op::TupleGet, Type::Ptr, val_reg, tuple_reg, idx1));
        set_register_type(val_reg, std::make_shared<::Type>(::TypeTag::Any));

        // Body
        if (stmt.body) {
            emit_stmt(*stmt.body);
        }

        // index++
        Reg one_reg = allocate_register();
        emit_instruction(LIR_Inst(LIR_Op::LoadConst, Type::I64, one_reg, make_i64(1)));
        set_register_type(one_reg, int_type);
        Reg next_reg = allocate_register();
        emit_instruction(LIR_Inst(LIR_Op::Add, Type::I64, next_reg, index_reg, one_reg));
        set_register_type(next_reg, int_type);
        emit_instruction(LIR_Inst(LIR_Op::Mov, index_reg, next_reg, 0));

        emit_instruction(LIR_Inst(LIR_Op::Jump, 0, 0, 0, header_block->id));
        add_block_edge(get_current_block(), header_block);

        set_current_block(exit_block);
        exit_loop();
        exit_scope();
    } else {
        // Single loop variable: iterate items list, each item is a (k, v) tuple.
        emit_list_var_iter_stmt(stmt, items_reg);
    }
}


void Generator::emit_list_var_iter_stmt(LM::Frontend::AST::IterStatement& stmt, Reg list_reg) {
    // Handle list iteration for variables
    if (stmt.loopVars.size() != 1) {
        report_error("list iteration currently supports only one loop variable");
        return;
    }
    const std::string& loop_var_name = stmt.loopVars[0];

    // Check if this is actually a tuple
    TypePtr iterable_type = get_register_type(list_reg);
    bool is_tuple = iterable_type && iterable_type->tag == TypeTag::Tuple;

    LIR_BasicBlock* header_block = create_basic_block("list_var_iter_header");
    LIR_BasicBlock* body_block = create_basic_block("list_var_iter_body");
    LIR_BasicBlock* exit_block = create_basic_block("list_var_iter_exit");

    enter_scope();
    enter_loop();
    set_loop_labels(header_block->id, exit_block->id, 0);

    // Bind loop variable
    Reg loop_var_reg = allocate_register();
    bind_variable(loop_var_name, loop_var_reg);

    // Initialize index to 0
    Reg index_reg = allocate_register();
    auto int_type = std::make_shared<::Type>(::TypeTag::Int64);
    Backend::Value zero_val = make_i64(0);
    emit_instruction(LIR_Inst(LIR_Op::LoadConst, Type::I64, index_reg, zero_val));
    set_register_type(index_reg, int_type);

    // Jump to header
    emit_instruction(LIR_Inst(LIR_Op::Jump, 0, 0, 0, header_block->id));
    add_block_edge(get_current_block(), header_block);

    set_current_block(header_block);
    
    // Get the actual list length using ListLen operation
    Reg len_reg = allocate_register();
    auto len_type = std::make_shared<::Type>(::TypeTag::Int64);
    emit_instruction(LIR_Inst(LIR_Op::ListLen, Type::I64, len_reg, list_reg));
    set_register_type(len_reg, len_type);
    
    // Compare index with length
    Reg cmp_reg = allocate_register();
    emit_instruction(LIR_Inst(LIR_Op::CmpLT, cmp_reg, index_reg, len_reg));
    set_register_type(cmp_reg, std::make_shared<::Type>(::TypeTag::Bool));
    
    // Jump to exit if index >= length
    emit_instruction(LIR_Inst(LIR_Op::JumpIfFalse, 0, cmp_reg, 0, exit_block->id));
    add_block_edge(header_block, body_block);
    add_block_edge(header_block, exit_block);

    set_current_block(body_block);
    
    // Get element at current index
    Reg elem_reg = allocate_register();
    if (is_tuple) {
        emit_instruction(LIR_Inst(LIR_Op::TupleGet, Type::Ptr, elem_reg, list_reg, index_reg));
    } else {
        emit_instruction(LIR_Inst(LIR_Op::ListIndex, Type::Ptr, elem_reg, list_reg, index_reg));
    }
    set_register_type(elem_reg, std::make_shared<::Type>(::TypeTag::Any));
    
    // Move element to loop variable
    emit_instruction(LIR_Inst(LIR_Op::Mov, loop_var_reg, elem_reg, 0));
    set_register_type(loop_var_reg, std::make_shared<::Type>(::TypeTag::Any));
    
    // Execute loop body
    if (stmt.body) {
        emit_stmt(*stmt.body);
    }
    
    // Increment index
    Reg one_reg = allocate_register();
    Backend::Value one_val = make_i64(1);
    emit_instruction(LIR_Inst(LIR_Op::LoadConst, Type::I64, one_reg, one_val));
    set_register_type(one_reg, int_type);
    
    Reg new_index_reg = allocate_register();
    emit_instruction(LIR_Inst(LIR_Op::Add, new_index_reg, index_reg, one_reg));
    emit_instruction(LIR_Inst(LIR_Op::Mov, index_reg, new_index_reg, 0));
    
    // Jump back to header
    emit_instruction(LIR_Inst(LIR_Op::Jump, 0, 0, 0, header_block->id));
    add_block_edge(get_current_block(), header_block);

    set_current_block(exit_block);
    exit_loop();
    exit_scope();
}

void Generator::emit_string_var_iter_stmt(LM::Frontend::AST::IterStatement& stmt, Reg str_reg) {
    if (stmt.loopVars.size() != 1) {
        report_error("string iteration supports exactly one loop variable");
        return;
    }
    const std::string& loop_var_name = stmt.loopVars[0];

    Reg offset_reg = allocate_register();
    auto int_type = std::make_shared<::Type>(::TypeTag::Int64);
    Backend::Value zero_val = make_i64(0);
    emit_instruction(LIR_Inst(LIR_Op::LoadConst, Type::I64, offset_reg, zero_val));
    set_register_type(offset_reg, int_type);

    Reg len_reg = allocate_register();
    emit_instruction(LIR_Inst(LIR_Op::CallBuiltin, len_reg, "_builtin_string_byte_len", {str_reg}));
    set_register_type(len_reg, int_type);

    LIR_BasicBlock* header_block = create_basic_block("string_iter_header");
    LIR_BasicBlock* body_block = create_basic_block("string_iter_body");
    LIR_BasicBlock* exit_block = create_basic_block("string_iter_exit");

    enter_scope();
    enter_loop();
    set_loop_labels(header_block->id, exit_block->id, 0);

    Reg loop_var_reg = allocate_register();
    set_register_type(loop_var_reg, int_type);
    bind_variable(loop_var_name, loop_var_reg);

    // Jump to header
    emit_instruction(LIR_Inst(LIR_Op::Jump, 0, 0, 0, header_block->id));
    add_block_edge(get_current_block(), header_block);

    // Header block: check offset < len
    set_current_block(header_block);
    Reg cmp_reg = allocate_register();
    set_register_type(cmp_reg, std::make_shared<::Type>(::TypeTag::Bool));
    emit_instruction(LIR_Inst(LIR_Op::CmpLT, cmp_reg, offset_reg, len_reg));

    emit_instruction(LIR_Inst(LIR_Op::JumpIfFalse, 0, cmp_reg, 0, exit_block->id));
    add_block_edge(header_block, body_block);
    add_block_edge(header_block, exit_block);

    // Body block: decode next codepoint
    set_current_block(body_block);
    Reg res_reg = allocate_register();
    emit_instruction(LIR_Inst(LIR_Op::CallBuiltin, res_reg, "_builtin_string_decode_next", {str_reg, offset_reg}));
    
    // cp = res >> 8
    Reg shift_const = allocate_register();
    emit_instruction(LIR_Inst(LIR_Op::LoadConst, Type::I64, shift_const, make_i64(8)));
    emit_instruction(LIR_Inst(LIR_Op::Shr, loop_var_reg, res_reg, shift_const));

    // consumed = res & 0xFF
    Reg consumed_reg = allocate_register();
    Reg mask_const = allocate_register();
    emit_instruction(LIR_Inst(LIR_Op::LoadConst, Type::I64, mask_const, make_i64(0xFF)));
    emit_instruction(LIR_Inst(LIR_Op::And, consumed_reg, res_reg, mask_const));

    // offset = offset + consumed
    Reg next_offset = allocate_register();
    set_register_type(next_offset, int_type);
    emit_instruction(LIR_Inst(LIR_Op::Add, next_offset, offset_reg, consumed_reg));
    emit_instruction(LIR_Inst(LIR_Op::Mov, offset_reg, next_offset, 0));

    // Execute loop body statements
    if (stmt.body) {
        emit_stmt(*stmt.body);
    }

    emit_instruction(LIR_Inst(LIR_Op::Jump, 0, 0, 0, header_block->id));
    add_block_edge(get_current_block(), header_block);

    // Exit block
    set_current_block(exit_block);
    exit_loop();
    exit_scope();
}


void Generator::emit_tuple_var_iter_stmt(LM::Frontend::AST::IterStatement& stmt, Reg tuple_reg, int64_t tuple_len) {
    // Handle tuple iteration for variables (similar to list)
    if (stmt.loopVars.size() != 1) {
        report_error("tuple iteration currently supports only one loop variable");
        return;
    }
    const std::string& loop_var_name = stmt.loopVars[0];

    LIR_BasicBlock* header_block = create_basic_block("tuple_var_iter_header");
    LIR_BasicBlock* body_block = create_basic_block("tuple_var_iter_body");
    LIR_BasicBlock* exit_block = create_basic_block("tuple_var_iter_exit");

    enter_scope();
    enter_loop();
    set_loop_labels(header_block->id, exit_block->id, 0);

    // Bind loop variable
    Reg loop_var_reg = allocate_register();
    bind_variable(loop_var_name, loop_var_reg);

    // Initialize index to 0
    Reg index_reg = allocate_register();
    auto int_type = std::make_shared<::Type>(::TypeTag::Int64);
    Backend::Value zero_val = make_i64(0);
    emit_instruction(LIR_Inst(LIR_Op::LoadConst, Type::I64, index_reg, zero_val));
    set_register_type(index_reg, int_type);

    // Jump to header
    emit_instruction(LIR_Inst(LIR_Op::Jump, 0, 0, 0, header_block->id));
    add_block_edge(get_current_block(), header_block);

    set_current_block(header_block);
    
    Reg len_reg = allocate_register();
    auto len_type = std::make_shared<::Type>(::TypeTag::Int64);
    if (tuple_len > 0) {
        Backend::Value len_val = make_i64(tuple_len);
        emit_instruction(LIR_Inst(LIR_Op::LoadConst, Type::I64, len_reg, len_val));
    } else {
        // If tuple_len is 0, we can use TupleLen op if available, or assume it is known at runtime
        emit_instruction(LIR_Inst(LIR_Op::LoadConst, Type::I64, len_reg, make_i64(0)));
    }
    set_register_type(len_reg, len_type);
    
    // Compare index with length
    Reg cmp_reg = allocate_register();
    emit_instruction(LIR_Inst(LIR_Op::CmpLT, cmp_reg, index_reg, len_reg));
    set_register_type(cmp_reg, std::make_shared<::Type>(::TypeTag::Bool));
    
    // Jump to exit if index >= length
    emit_instruction(LIR_Inst(LIR_Op::JumpIfFalse, 0, cmp_reg, 0, exit_block->id));
    add_block_edge(header_block, body_block);
    add_block_edge(header_block, exit_block);

    set_current_block(body_block);
    
    // Get element at current index (tuples use list_index internally)
    Reg elem_reg = allocate_register();
    emit_instruction(LIR_Inst(LIR_Op::TupleGet, Type::Ptr, elem_reg, tuple_reg, index_reg));
    set_register_type(elem_reg, std::make_shared<::Type>(::TypeTag::Any));
    
    // Move element to loop variable
    emit_instruction(LIR_Inst(LIR_Op::Mov, loop_var_reg, elem_reg, 0));
    set_register_type(loop_var_reg, std::make_shared<::Type>(::TypeTag::Any));
    
    // Execute loop body
    if (stmt.body) {
        emit_stmt(*stmt.body);
    }
    
    // Increment index
    Reg one_reg = allocate_register();
    Backend::Value one_val = make_i64(1);
    emit_instruction(LIR_Inst(LIR_Op::LoadConst, Type::I64, one_reg, one_val));
    set_register_type(one_reg, int_type);
    
    Reg new_index_reg = allocate_register();
    emit_instruction(LIR_Inst(LIR_Op::Add, new_index_reg, index_reg, one_reg));
    emit_instruction(LIR_Inst(LIR_Op::Mov, index_reg, new_index_reg, 0));
    
    // Jump back to header
    emit_instruction(LIR_Inst(LIR_Op::Jump, 0, 0, 0, header_block->id));
    add_block_edge(get_current_block(), header_block);

    set_current_block(exit_block);
    exit_loop();
    exit_scope();
}


void Generator::emit_break_stmt(LM::Frontend::AST::BreakStatement& stmt) {
    uint32_t break_label = get_break_label();
    if (break_label != INVALID_LOOP_LABEL) {
        if (!loop_stack_.empty()) {
            size_t depth = loop_stack_.back().region_depth;
            uint32_t parent = depth ? generator_region_stack_[depth - 1] : 0;
            for (size_t i = 0; i < depth && i < scope_stack_.size(); ++i)
                for (const auto& [name, reg] : scope_stack_[i].vars)
                    emit_instruction(LIR_Inst(LIR_Op::RegionMove, Type::Void, 0, reg, 0, parent));
            for (size_t i = generator_region_stack_.size(); i > depth; --i)
                emit_instruction(LIR_Inst(LIR_Op::RegionExit, Type::Void, 0, 0, 0, generator_region_stack_[i - 1]));
        }
        emit_instruction(LIR_Inst(LIR_Op::Jump, 0, 0, 0, break_label));
        // Add edge to break target block
        LIR_BasicBlock* break_target = current_function_->cfg->get_block(break_label);
        if (break_target) {
            add_block_edge(get_current_block(), break_target);
        }
        // Mark current block as terminated to prevent further instruction generation
        if (get_current_block()) {
            get_current_block()->terminated = true;
        }
    }
}


void Generator::emit_continue_stmt(LM::Frontend::AST::ContinueStatement& stmt) {
    uint32_t continue_label = get_continue_label();
    if (continue_label != INVALID_LOOP_LABEL) {
        if (!loop_stack_.empty()) {
            size_t depth = loop_stack_.back().region_depth;
            uint32_t parent = depth ? generator_region_stack_[depth - 1] : 0;
            for (size_t i = 0; i < depth && i < scope_stack_.size(); ++i)
                for (const auto& [name, reg] : scope_stack_[i].vars)
                    emit_instruction(LIR_Inst(LIR_Op::RegionMove, Type::Void, 0, reg, 0, parent));
            for (size_t i = generator_region_stack_.size(); i > depth; --i)
                emit_instruction(LIR_Inst(LIR_Op::RegionExit, Type::Void, 0, 0, 0, generator_region_stack_[i - 1]));
        }
        emit_instruction(LIR_Inst(LIR_Op::Jump, 0, 0, 0, continue_label));
        // Add edge to continue target block
        LIR_BasicBlock* continue_target = current_function_->cfg->get_block(continue_label);
        if (continue_target) {
            add_block_edge(get_current_block(), continue_target);
        }
        // Mark current block as terminated to prevent further instruction generation
        if (get_current_block()) {
            get_current_block()->terminated = true;
        }
    }
}


void Generator::emit_unsafe_stmt(LM::Frontend::AST::UnsafeStatement& stmt) {
    if (stmt.body) {
        emit_stmt(*stmt.body);
    }
}



void Generator::emit_match_stmt(LM::Frontend::AST::MatchStatement& stmt) {
    if (!stmt.value) return;
    
    bool prev_in_control_flow = cfg_context_.in_control_flow;
    cfg_context_.in_control_flow = true;
    
    Reg value_reg = emit_expr(*stmt.value);
    
    if (cfg_context_.building_cfg) {
        LIR_BasicBlock* match_exit = create_basic_block("match_exit");
        
        // Create blocks in execution order: pattern0, body0, pattern1, body1, ...
        std::vector<LIR_BasicBlock*> pattern_blocks;
        std::vector<LIR_BasicBlock*> body_blocks;
        
        for (size_t i = 0; i < stmt.cases.size(); ++i) {
            pattern_blocks.push_back(create_basic_block("match_pattern_" + std::to_string(i)));
            body_blocks.push_back(create_basic_block("match_body_" + std::to_string(i)));
        }

        // Jump to first pattern block
        if (get_current_block() && !get_current_block()->has_terminator()) {
            emit_instruction(LIR_Inst(LIR_Op::Jump, 0, 0, 0, pattern_blocks[0]->id));
            add_block_edge(get_current_block(), pattern_blocks[0]);
        }

        // Generate pattern matching and body for each case
        for (size_t i = 0; i < stmt.cases.size(); ++i) {
            const auto& match_case = stmt.cases[i];
            LIR_BasicBlock* pattern_block = pattern_blocks[i];
            LIR_BasicBlock* body_block = body_blocks[i];
            LIR_BasicBlock* next_pattern = (i + 1 < stmt.cases.size()) ? pattern_blocks[i + 1] : match_exit;

            auto* failed = create_basic_block("match_failed_" + std::to_string(i));
            set_current_block(pattern_block);
            enter_scope();
            uint32_t case_region = generator_region_stack_.back();

            // 1. Pattern Matching Logic
            emit_pattern_match(match_case.pattern, value_reg, failed, 0);

            // 2. Guard Logic
            if (match_case.guard) {
                if (get_current_block() && !get_current_block()->has_terminator()) {
                    Reg guard_res = emit_expr(*match_case.guard);
                    emit_instruction(LIR_Inst(LIR_Op::JumpIfFalse, 0, guard_res, 0, failed->id));
                    add_block_edge(get_current_block(), body_block);  // Fall-through if guard true (add first)
                    add_block_edge(get_current_block(), failed);  // Jump if false (add second)
                }
            } else {
                if (get_current_block() && !get_current_block()->has_terminator()) {
                    emit_instruction(LIR_Inst(LIR_Op::Jump, 0, 0, 0, body_block->id));
                    add_block_edge(get_current_block(), body_block);
                }
            }

            // 3. Body Logic
            set_current_block(body_block);
            bind_all_vars(this, match_case.pattern, value_reg);
            if (match_case.body) {
                emit_stmt(*match_case.body);
            }
            
            exit_scope();
            if (get_current_block() && !get_current_block()->has_terminator()) {
                emit_instruction(LIR_Inst(LIR_Op::Jump, 0, 0, 0, match_exit->id));
                add_block_edge(get_current_block(), match_exit);
            }
            
            set_current_block(failed);
            uint32_t parent = generator_region_stack_.empty() ? 0 : generator_region_stack_.back();
            for (const auto& scope : scope_stack_)
                for (const auto& [name, reg] : scope.vars)
                    emit_instruction(LIR_Inst(LIR_Op::RegionMove, Type::Void, 0, reg, 0, parent));
            emit_instruction(LIR_Inst(LIR_Op::RegionExit, Type::Void, 0, 0, 0, case_region));
            emit_instruction(LIR_Inst(LIR_Op::Jump, 0, 0, 0, next_pattern->id));
            add_block_edge(get_current_block(), next_pattern);
        }

        set_current_block(match_exit);
    } else {
        // Non-CFG (linear) mode: use labels
        uint32_t exit_label = generate_label();
        
        std::vector<uint32_t> pattern_labels;
        std::vector<uint32_t> body_labels;
        
        for (size_t i = 0; i < stmt.cases.size(); ++i) {
            pattern_labels.push_back(generate_label());
            body_labels.push_back(generate_label());
        }
        
        // Jump to first pattern label
        emit_label_jump(LIR_Op::Jump, 0, pattern_labels[0]);
        
        for (size_t i = 0; i < stmt.cases.size(); ++i) {
            const auto& match_case = stmt.cases[i];
            uint32_t pattern_label = pattern_labels[i];
            uint32_t body_label = body_labels[i];
            uint32_t next_pattern_label = (i + 1 < stmt.cases.size()) ? pattern_labels[i + 1] : exit_label;
            
            uint32_t failed_label = generate_label();
            place_label(pattern_label);
            enter_scope();
            uint32_t case_region = generator_region_stack_.back();
            
            // 1. Pattern Matching Logic
            emit_pattern_match(match_case.pattern, value_reg, nullptr, failed_label);
            
            // 2. Guard Logic
            if (match_case.guard) {
                Reg guard_res = emit_expr(*match_case.guard);
                emit_label_jump(LIR_Op::JumpIfFalse, guard_res, failed_label);
            }
            
            // Fall-through (or jump) to body
            emit_label_jump(LIR_Op::Jump, 0, body_label);
            
            // 3. Body Logic
            place_label(body_label);
            bind_all_vars(this, match_case.pattern, value_reg);
            if (match_case.body) {
                emit_stmt(*match_case.body);
            }
            
            exit_scope();
            emit_label_jump(LIR_Op::Jump, 0, exit_label);
            place_label(failed_label);
            uint32_t parent = generator_region_stack_.empty() ? 0 : generator_region_stack_.back();
            for (const auto& scope : scope_stack_)
                for (const auto& [name, reg] : scope.vars)
                    emit_instruction(LIR_Inst(LIR_Op::RegionMove, Type::Void, 0, reg, 0, parent));
            emit_instruction(LIR_Inst(LIR_Op::RegionExit, Type::Void, 0, 0, 0, case_region));
            emit_label_jump(LIR_Op::Jump, 0, next_pattern_label);
        }
        
        place_label(exit_label);
    }
    
    cfg_context_.in_control_flow = prev_in_control_flow;
}

void Generator::emit_pattern_match_jump(LIR_Op op, Reg cond_reg, LIR_BasicBlock* failure_target, uint32_t failure_label) {
    if (cfg_context_.building_cfg) {
        emit_instruction(LIR_Inst(op, 0, cond_reg, 0, failure_target->id));
        add_block_edge(get_current_block(), failure_target);
    } else {
        emit_label_jump(op, cond_reg, failure_label);
    }
}

void Generator::emit_pattern_match(std::shared_ptr<LM::Frontend::AST::Expression> pattern, Reg val_reg, LIR_BasicBlock* failure_target, uint32_t failure_label) {
    auto i64_type = std::make_shared<::Type>(::TypeTag::Int64);

    if (auto literal = dynamic_cast<LM::Frontend::AST::LiteralExpr*>(pattern.get())) {
        if (std::holds_alternative<std::nullptr_t>(literal->value)) {
            // Wildcard _ or nil pattern that matches anything - do nothing
        } else {
            Reg literal_reg = emit_expr(*literal);
            Reg cmp = allocate_register();
            emit_instruction(LIR_Inst(LIR_Op::CmpEQ, LIR::Type::Bool, cmp, val_reg, literal_reg));
            set_register_type(cmp, std::make_shared<::Type>(::TypeTag::Bool));
            emit_pattern_match_jump(LIR_Op::JumpIfFalse, cmp, failure_target, failure_label);
        }
    } else if (auto var_expr = dynamic_cast<LM::Frontend::AST::VariableExpr*>(pattern.get())) {
        if (var_expr->name != "_") {
            bind_variable(var_expr->name, val_reg);
        }
    } else if (auto val_p = dynamic_cast<LM::Frontend::AST::ValPatternExpr*>(pattern.get())) {
         Reg is_err = allocate_register();
         emit_instruction(LIR_Inst(LIR_Op::IsError, Type::Bool, is_err, val_reg));
         emit_pattern_match_jump(LIR_Op::JumpIf, is_err, failure_target, failure_label);
    } else if (auto err_p = dynamic_cast<LM::Frontend::AST::ErrPatternExpr*>(pattern.get())) {
         Reg is_err = allocate_register();
         emit_instruction(LIR_Inst(LIR_Op::IsError, Type::Bool, is_err, val_reg));
         emit_pattern_match_jump(LIR_Op::JumpIfFalse, is_err, failure_target, failure_label);
    } else if (auto err_t_p = dynamic_cast<LM::Frontend::AST::ErrorTypePatternExpr*>(pattern.get())) {
         Reg is_err = allocate_register();
         emit_instruction(LIR_Inst(LIR_Op::IsError, Type::Bool, is_err, val_reg));
         emit_pattern_match_jump(LIR_Op::JumpIfFalse, is_err, failure_target, failure_label);
    } else if (auto binding = dynamic_cast<LM::Frontend::AST::BindingPatternExpr*>(pattern.get())) {
        if (binding->typeName == "val") {
             Reg is_err = allocate_register();
             emit_instruction(LIR_Inst(LIR_Op::IsError, Type::Bool, is_err, val_reg));
             emit_pattern_match_jump(LIR_Op::JumpIf, is_err, failure_target, failure_label);
             if (!binding->patterns.empty()) {
                 Reg payload = allocate_register();
                 emit_instruction(LIR_Inst(LIR_Op::Unwrap, Type::Ptr, payload, val_reg));
                 emit_pattern_match(binding->patterns[0], payload, failure_target, failure_label);
             }
        } else if (binding->typeName == "err") {
             Reg is_err = allocate_register();
             emit_instruction(LIR_Inst(LIR_Op::IsError, Type::Bool, is_err, val_reg));
             emit_pattern_match_jump(LIR_Op::JumpIfFalse, is_err, failure_target, failure_label);
             if (!binding->patterns.empty()) {
                 Reg payload = allocate_register();
                 emit_instruction(LIR_Inst(LIR_Op::GetPayload, Type::Ptr, payload, val_reg));
                 emit_pattern_match(binding->patterns[0], payload, failure_target, failure_label);
             }
        } else {
            int64_t tag = 0; size_t arity = 0;
            TypePtr m_type = pattern->inferred_type;
            
            bool resolved = resolve_match_variant_info(type_system_.get(), m_type, binding->typeName, tag, arity);
            if (!resolved && m_type && (m_type->tag == TypeTag::Enum || m_type->tag == TypeTag::UserDefined)) {
                if (auto* et = std::get_if<EnumType>(&m_type->extra)) {
                    resolved = resolve_match_variant_info(type_system_.get(), m_type, et->name + "." + binding->typeName, tag, arity);
                }
            }

            if (resolved) {
                Reg tag_reg = allocate_register();
                emit_instruction(LIR_Inst(LIR_Op::GetTag, Type::I64, tag_reg, val_reg));
                Reg expected = allocate_register();
                emit_instruction(LIR_Inst(LIR_Op::LoadConst, Type::I64, expected, make_i64(tag)));
                Reg cmp = allocate_register();
                emit_instruction(LIR_Inst(LIR_Op::CmpEQ, LIR::Type::Bool, cmp, tag_reg, expected));
                set_register_type(cmp, std::make_shared<::Type>(::TypeTag::Bool));

                emit_pattern_match_jump(LIR_Op::JumpIfFalse, cmp, failure_target, failure_label);
                
                if (!binding->patterns.empty()) {
                    Reg payload = allocate_register();
                    emit_instruction(LIR_Inst(LIR_Op::GetPayload, Type::Ptr, payload, val_reg));
                    // For single-element variants, payload is the value directly (optimization)
                    // For multi-element variants, payload is a tuple
                    if (binding->patterns.size() == 1) {
                        emit_pattern_match(binding->patterns[0], payload, failure_target, failure_label);
                    } else {
                        for (size_t v_idx = 0; v_idx < binding->patterns.size(); ++v_idx) {
                            Reg idx_reg = allocate_register();
                            emit_instruction(LIR_Inst(LIR_Op::LoadConst, Type::I64, idx_reg, make_i64(v_idx)));
                            Reg elem = allocate_register();
                            emit_instruction(LIR_Inst(LIR_Op::TupleGet, Type::Ptr, elem, payload, idx_reg));
                            emit_pattern_match(binding->patterns[v_idx], elem, failure_target, failure_label);
                        }
                    }
                }
            } else {
                // If it is qualified, it MUST be a resolved variant to match.
                // If it is not qualified and has no patterns, it could be a variable binding.
                if (binding->typeName.find('.') == std::string::npos && binding->patterns.empty() && binding->typeName != "_") {
                    bind_variable(binding->typeName, val_reg);
                } else {
                    if (cfg_context_.building_cfg) {
                        emit_instruction(LIR_Inst(LIR_Op::Jump, 0, 0, 0, failure_target->id));
                        if (get_current_block()) add_block_edge(get_current_block(), failure_target);
                    } else {
                        emit_instruction(LIR_Inst(LIR_Op::Jump, Type::Void, 0, 0, 0, failure_label));
                    }
                }
            }
        }
    } else if (auto list_p = dynamic_cast<LM::Frontend::AST::ListPatternExpr*>(pattern.get())) {
        Reg len_reg = allocate_register();
        emit_instruction(LIR_Inst(LIR_Op::ListLen, Type::I64, len_reg, val_reg));
        Reg expected_len = allocate_register();
        emit_instruction(LIR_Inst(LIR_Op::LoadConst, Type::I64, expected_len, make_i64(list_p->elements.size())));
        
        Reg cmp = allocate_register();
        if (list_p->restElement.has_value()) {
            emit_instruction(LIR_Inst(LIR_Op::CmpGE, LIR::Type::Bool, cmp, len_reg, expected_len));
        } else {
            emit_instruction(LIR_Inst(LIR_Op::CmpEQ, LIR::Type::Bool, cmp, len_reg, expected_len));
        }
        set_register_type(cmp, std::make_shared<::Type>(::TypeTag::Bool));
        emit_pattern_match_jump(LIR_Op::JumpIfFalse, cmp, failure_target, failure_label);

        for (size_t i = 0; i < list_p->elements.size(); ++i) {
            Reg idx_reg = allocate_register();
            emit_instruction(LIR_Inst(LIR_Op::LoadConst, Type::I64, idx_reg, make_i64(i)));
            Reg elem = allocate_register();
            emit_instruction(LIR_Inst(LIR_Op::ListIndex, Type::Ptr, elem, val_reg, idx_reg));
            emit_pattern_match(list_p->elements[i], elem, failure_target, failure_label);
        }
    } else if (auto tuple_p = dynamic_cast<LM::Frontend::AST::TuplePatternExpr*>(pattern.get())) {
        Reg len_reg = allocate_register();
        emit_instruction(LIR_Inst(LIR_Op::TupleLen, Type::I64, len_reg, val_reg));
        Reg expected_len = allocate_register();
        emit_instruction(LIR_Inst(LIR_Op::LoadConst, Type::I64, expected_len, make_i64(tuple_p->elements.size())));
        
        Reg cmp = allocate_register();
        emit_instruction(LIR_Inst(LIR_Op::CmpEQ, LIR::Type::Bool, cmp, len_reg, expected_len));
        set_register_type(cmp, std::make_shared<::Type>(::TypeTag::Bool));
        emit_pattern_match_jump(LIR_Op::JumpIfFalse, cmp, failure_target, failure_label);

        for (size_t i = 0; i < tuple_p->elements.size(); ++i) {
            Reg idx_reg = allocate_register();
            emit_instruction(LIR_Inst(LIR_Op::LoadConst, Type::I64, idx_reg, make_i64(i)));
            Reg elem = allocate_register();
            emit_instruction(LIR_Inst(LIR_Op::TupleGet, Type::Ptr, elem, val_reg, idx_reg));
            emit_pattern_match(tuple_p->elements[i], elem, failure_target, failure_label);
        }
    } else if (auto dict_p = dynamic_cast<LM::Frontend::AST::DictPatternExpr*>(pattern.get())) {
        if (!dict_p->restBinding.has_value()) {
            Reg len_reg = allocate_register();
            emit_instruction(LIR_Inst(LIR_Op::DictLen, Type::I64, len_reg, val_reg));
            Reg expected_len = allocate_register();
            emit_instruction(LIR_Inst(LIR_Op::LoadConst, Type::I64, expected_len, make_i64(dict_p->fields.size())));
            
            Reg cmp = allocate_register();
            emit_instruction(LIR_Inst(LIR_Op::CmpEQ, LIR::Type::Bool, cmp, len_reg, expected_len));
            set_register_type(cmp, std::make_shared<::Type>(::TypeTag::Bool));
            emit_pattern_match_jump(LIR_Op::JumpIfFalse, cmp, failure_target, failure_label);
        }

        for (const auto& field : dict_p->fields) {
            Reg key_reg = allocate_register();
            auto str_type = std::make_shared<::Type>(::TypeTag::String);
            emit_instruction(LIR_Inst(LIR_Op::LoadConst, Type::Ptr, key_reg, BOX_PTR(lm_str_from_cstr(field.key.c_str()))));
            
            Reg exists = allocate_register();
            emit_instruction(LIR_Inst(LIR_Op::DictHas, LIR::Type::Bool, exists, val_reg, key_reg));
            emit_pattern_match_jump(LIR_Op::JumpIfFalse, exists, failure_target, failure_label);

            Reg elem = allocate_register();
            emit_instruction(LIR_Inst(LIR_Op::DictGet, Type::Ptr, elem, val_reg, key_reg));
            emit_pattern_match(field.pattern, elem, failure_target, failure_label);
        }
    }
}


} // namespace LIR
} // namespace LM
