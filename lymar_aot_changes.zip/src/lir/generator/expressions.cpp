#include "../generator.hh"
#include "../../memory/reference_flags.hh"
#include "../functions.hh"
#include "../intrinsic_registry.hh"
#include "../../backend/vm/constant_utils.hh"
#include "../../frontend/module_manager.hh"
#include "../function_registry.hh"
#include "../builtin_functions.hh"
#include "../../frontend/ast.hh"
#include "../../frontend/scanner.hh"
#include <algorithm>
#include <map>
#include <limits>

using namespace LM::LIR;

namespace LM {
namespace LIR {

namespace {
bool resolve_enum_variant_info(TypeSystem* type_system,
                               TypePtr enum_type_hint,
                               const std::string& variant_ref,
                               int64_t& out_tag,
                               size_t& out_arity) {
    TypePtr enum_type = enum_type_hint;
    std::string variant_name = variant_ref;

    // 1. Try directly in enum_type_hint
    if (enum_type && (enum_type->tag == TypeTag::Enum || enum_type->tag == TypeTag::UserDefined || enum_type->tag == TypeTag::Frame)) {
        if (auto* enum_info = std::get_if<EnumType>(&enum_type->extra)) {
            // Try as is (qualified or not)
            auto it = std::find(enum_info->values.begin(), enum_info->values.end(), variant_name);
            
            // Try unqualified
            if (it == enum_info->values.end()) {
                std::string unqualified = variant_name;
                if (unqualified.find('.') != std::string::npos) unqualified = unqualified.substr(unqualified.find('.') + 1);
                it = std::find(enum_info->values.begin(), enum_info->values.end(), unqualified);
            }
            
            if (it != enum_info->values.end()) {
                out_tag = static_cast<int64_t>(std::distance(enum_info->values.begin(), it));
                auto arity_it = enum_info->variantTypes.find(*it);
                out_arity = (arity_it != enum_info->variantTypes.end()) ? arity_it->second.size() : 0;
                return true;
            }
        }
    }

    // 2. Try via qualified name
    auto dot_pos = variant_ref.find('.');
    if (dot_pos != std::string::npos) {
        std::string enum_name = variant_ref.substr(0, dot_pos);
        variant_name = variant_ref.substr(dot_pos + 1);
        if (type_system) {
            auto found = type_system->getType(enum_name);
            if (found && (found->tag == TypeTag::Enum || found->tag == TypeTag::UserDefined || found->tag == TypeTag::Frame)) {
                if (auto* enum_info = std::get_if<EnumType>(&found->extra)) {
                    auto it = std::find(enum_info->values.begin(), enum_info->values.end(), variant_name);
                    if (it != enum_info->values.end()) {
                        out_tag = static_cast<int64_t>(std::distance(enum_info->values.begin(), it));
                        auto arity_it = enum_info->variantTypes.find(*it);
                        out_arity = (arity_it != enum_info->variantTypes.end()) ? arity_it->second.size() : 0;
                        return true;
                    }
                }
            }
        }
    }

    return false;
}

std::string get_expr_qualified_path(const LM::Frontend::AST::Expression* e) {
    if (!e) return "";
    if (auto var = dynamic_cast<const LM::Frontend::AST::VariableExpr*>(e)) {
        return var->name;
    }
    if (auto mem = dynamic_cast<const LM::Frontend::AST::MemberExpr*>(e)) {
        std::string base = get_expr_qualified_path(mem->object.get());
        if (!base.empty()) {
            return base + "." + mem->name;
        }
    }
    return "";
}
}

Reg Generator::emit_expr(LM::Frontend::AST::Expression& expr) {
    auto result = emit_expr_impl(expr);
    if (ownership_facts_ && current_function_) {
        auto found = ownership_facts_->nodes.find(expr.memory_info.semantic_id);
        if (found != ownership_facts_->nodes.end()) {
            const auto& fact = found->second;
            current_function_->ownership_provenance[result] = fact;
            auto annotate_call = [&](std::vector<LIR_Inst>& instructions) {
                for (auto it = instructions.rbegin(); it != instructions.rend(); ++it) {
                    if (it->dst == result && (it->op == LIR_Op::Call || it->op == LIR_Op::CallIndirect || it->op == LIR_Op::CallBuiltin)) {
                        if (fact.arguments.size() == it->call_args.size()) it->call_arg_ownership = fact.arguments;
                        break;
                    }
                }
            };
            if (dynamic_cast<LM::Frontend::AST::CallExpr*>(&expr)) {
                if (cfg_context_.building_cfg && cfg_context_.current_block) annotate_call(cfg_context_.current_block->instructions);
                else annotate_call(current_function_->instructions);
            }
            emit_ownership_event(fact.event);
            if (auto assignment = dynamic_cast<LM::Frontend::AST::AssignExpr*>(&expr);
                assignment && !assignment->object && !assignment->member && !assignment->index) {
                auto old = checked_references_.find(fact.binding);
                const auto existing_handle = old == checked_references_.end() ? UINT32_MAX : old->second;
                if (old != checked_references_.end()) {
                    emit_instruction(LIR_Inst(LIR_Op::RefRelease, Type::Void, UINT32_MAX, old->second, UINT32_MAX, Memory::ReferenceNullable));
                    checked_references_.erase(old);
                }
                const bool assigned_nil = assignment->value && assignment->value->inferred_type && assignment->value->inferred_type->tag == TypeTag::Nil;
                if ((fact.managed && fact.unknown_origin) || (existing_handle != UINT32_MAX && (fact.managed || assigned_nil))) {
                    auto handle = existing_handle == UINT32_MAX ? allocate_register() : existing_handle;
                    auto permission = Memory::ReferenceNullable | (ownership_facts_->writable_bindings.count(fact.binding) ? Memory::ReferenceWritable : 0);
                    emit_instruction(LIR_Inst(LIR_Op::RefCreate, Type::U64, handle, result, UINT32_MAX, permission));
                    uint32_t target_region = 0;
                    for (size_t scope = scope_stack_.size(); scope > 0; --scope) {
                        if (scope_stack_[scope - 1].vars.count(assignment->name)) {
                            if (scope <= generator_region_stack_.size()) target_region = generator_region_stack_[scope - 1];
                            break;
                        }
                    }
                    if (!generator_region_stack_.empty() && generator_region_stack_.back() != target_region) {
                        emit_instruction(LIR_Inst(LIR_Op::RegionMove, Type::Void, UINT32_MAX, result, UINT32_MAX, target_region));
                        auto promoted_handle = allocate_register();
                        emit_instruction(LIR_Inst(LIR_Op::RefMove, Type::U64, promoted_handle, handle, UINT32_MAX, target_region | Memory::ReferenceMoveNullable));
                        emit_instruction(LIR_Inst(LIR_Op::Mov, Type::U64, handle, promoted_handle, UINT32_MAX));
                    }
                    checked_references_[fact.binding] = handle;
                }
            }
            if (auto variable = dynamic_cast<LM::Frontend::AST::VariableExpr*>(&expr)) {
                auto checked = checked_references_.find(fact.binding);
                if (checked != checked_references_.end()) {
                    auto resolved = allocate_register();
                    emit_instruction(LIR_Inst(LIR_Op::RefResolve, Type::Ptr, resolved, checked->second, UINT32_MAX, Memory::ReferenceNullable));
                    return resolved;
                }
            }
        }
    }
    return result;
}

Reg Generator::emit_expr_impl(LM::Frontend::AST::Expression& expr) {
    if (auto literal = dynamic_cast<LM::Frontend::AST::LiteralExpr*>(&expr)) {
        return emit_literal_expr(*literal, nullptr);
    } else if (auto variable = dynamic_cast<LM::Frontend::AST::VariableExpr*>(&expr)) {
        return emit_variable_expr(*variable);
    } else if (auto interpolated = dynamic_cast<LM::Frontend::AST::InterpolatedStringExpr*>(&expr)) {
        return emit_interpolated_string_expr(*interpolated);
    } else if (auto binary = dynamic_cast<LM::Frontend::AST::BinaryExpr*>(&expr)) {
        return emit_binary_expr(*binary);
    } else if (auto unary = dynamic_cast<LM::Frontend::AST::UnaryExpr*>(&expr)) {
        return emit_unary_expr(*unary);
    } else if (auto assign = dynamic_cast<LM::Frontend::AST::AssignExpr*>(&expr)) {
        return emit_assign_expr(*assign);
    } else if (auto call = dynamic_cast<LM::Frontend::AST::CallExpr*>(&expr)) {
        return emit_call_expr(*call);
    } else if (auto closure_call = dynamic_cast<LM::Frontend::AST::CallClosureExpr*>(&expr)) {
        return emit_call_closure_expr(*closure_call);
    } else if (auto list = dynamic_cast<LM::Frontend::AST::ListExpr*>(&expr)) {
        return emit_list_expr(*list);
    } else if (auto grouping = dynamic_cast<LM::Frontend::AST::GroupingExpr*>(&expr)) {
        return emit_grouping_expr(*grouping);
    } else if (auto index = dynamic_cast<LM::Frontend::AST::IndexExpr*>(&expr)) {
        return emit_index_expr(*index);
    } else if (auto member = dynamic_cast<LM::Frontend::AST::MemberExpr*>(&expr)) {
        return emit_member_expr(*member);
    } else if (auto tuple = dynamic_cast<LM::Frontend::AST::TupleExpr*>(&expr)) {
        return emit_tuple_expr(*tuple);
    } else if (auto dict = dynamic_cast<LM::Frontend::AST::DictExpr*>(&expr)) {
        return emit_dict_expr(*dict);
    } else if (auto range = dynamic_cast<LM::Frontend::AST::RangeExpr*>(&expr)) {
        return emit_range_expr(*range);
    } else if (auto lambda = dynamic_cast<LM::Frontend::AST::LambdaExpr*>(&expr)) {
        return emit_lambda_expr(*lambda);
    } else if (auto error_construct = dynamic_cast<LM::Frontend::AST::ErrorConstructExpr*>(&expr)) {
        return emit_error_construct_expr(*error_construct);
    } else if (auto ok_construct = dynamic_cast<LM::Frontend::AST::OkConstructExpr*>(&expr)) {
        return emit_ok_construct_expr(*ok_construct);
    } else if (auto fallible = dynamic_cast<LM::Frontend::AST::FallibleExpr*>(&expr)) {
        return emit_fallible_expr(*fallible);
    } else if (auto cast = dynamic_cast<LM::Frontend::AST::CastExpr*>(&expr)) {
        return emit_cast_expr(*cast);
    } else if (auto frame_inst = dynamic_cast<LM::Frontend::AST::FrameInstantiationExpr*>(&expr)) {
        return emit_frame_instantiation_expr(*frame_inst);
    } else if (auto staged_expr = dynamic_cast<LM::Frontend::AST::StagedExpr*>(&expr)) {
        if (staged_expr->expression) {
            return emit_expr(*staged_expr->expression);
        }
        if (staged_expr->block) {
            Reg last_reg = Reg();
            for (auto& stmt : staged_expr->block->statements) {
                if (auto expr_stmt = dynamic_cast<LM::Frontend::AST::ExprStatement*>(stmt.get())) {
                    if (expr_stmt->expression) {
                        last_reg = emit_expr(*expr_stmt->expression);
                    }
                } else {
                    emit_stmt(*stmt);
                }
            }
            return last_reg;
        }
    } else if (auto hole = dynamic_cast<LM::Frontend::AST::TypedHoleExpr*>(&expr)) {
        Reg dst = allocate_register();
        emit_instruction(LIR_Inst(LIR_Op::LoadConst, Type::I64, dst, make_i64(0)));
        return dst;
    } else if (auto this_expr = dynamic_cast<LM::Frontend::AST::ThisExpr*>(&expr)) {
        return emit_this_expr(*this_expr);
    } else if (auto channel_offer = dynamic_cast<LM::Frontend::AST::ChannelOfferExpr*>(&expr)) {
        return emit_channel_offer_expr(*channel_offer);
    } else if (auto channel_poll = dynamic_cast<LM::Frontend::AST::ChannelPollExpr*>(&expr)) {
        return emit_channel_poll_expr(*channel_poll);
    } else if (auto channel_send = dynamic_cast<LM::Frontend::AST::ChannelSendExpr*>(&expr)) {
        return emit_channel_send_expr(*channel_send);
    } else if (auto channel_recv = dynamic_cast<LM::Frontend::AST::ChannelRecvExpr*>(&expr)) {
        return emit_channel_recv_expr(*channel_recv);
    } else {
        report_error("Unknown expression type");
        return 0;
    }
    return 0;
}


TypePtr Generator::get_promoted_numeric_type(TypePtr left_type, TypePtr right_type) {
    // If either type is null, default to Int64
    if (!left_type || !right_type) {
        return std::make_shared<::Type>(::TypeTag::Int64);
    }
    
    // If either is string, result is string
    if (left_type->tag == ::TypeTag::String || right_type->tag == ::TypeTag::String) {
        return std::make_shared<::Type>(::TypeTag::String);
    }
    
    // If either is float, promote to the larger float type
    bool left_is_float = (left_type->tag == ::TypeTag::Float32 || left_type->tag == ::TypeTag::Float64);
    bool right_is_float = (right_type->tag == ::TypeTag::Float32 || right_type->tag == ::TypeTag::Float64);
    
    if (left_is_float || right_is_float) {
        if (left_type->tag == ::TypeTag::Float64 || right_type->tag == ::TypeTag::Float64) {
            return std::make_shared<::Type>(::TypeTag::Float64);
        }
        return std::make_shared<::Type>(::TypeTag::Float32);
    }
    
    // Both are integers - use the "smaller matches larger" strategy
    int left_rank = get_type_rank(left_type);
    int right_rank = get_type_rank(right_type);
    
    // If ranks are equal, prefer unsigned over signed to preserve unsigned semantics
    if (left_rank == right_rank) {
        bool left_is_unsigned = !is_signed_integer_type(left_type);
        bool right_is_unsigned = !is_signed_integer_type(right_type);
        
        if (left_is_unsigned) return left_type;
        if (right_is_unsigned) return right_type;
        
        // Both signed, return either
        return left_type;
    }
    
    // Return the type with higher rank (larger/more complex type)
    // But if the higher rank type is signed and lower rank is unsigned, 
    // and they're close in rank, prefer unsigned to avoid signed overflow
    TypePtr higher_type = (left_rank > right_rank) ? left_type : right_type;
    TypePtr lower_type = (left_rank > right_rank) ? right_type : left_type;
    
    bool higher_is_unsigned = !is_signed_integer_type(higher_type);
    bool lower_is_unsigned = !is_signed_integer_type(lower_type);
    
    // If lower is unsigned and higher is signed, and ranks are close, use unsigned version of higher
    if (lower_is_unsigned && !higher_is_unsigned && (left_rank - right_rank <= 2 || right_rank - left_rank <= 2)) {
        return get_unsigned_version(higher_type);
    }
    
    return higher_type;
}


int Generator::get_type_rank(TypePtr type) {
    if (!type) return 0;
    
    switch (type->tag) {
        case ::TypeTag::Int8: case ::TypeTag::UInt8: return 1;
        case ::TypeTag::Int16: case ::TypeTag::UInt16: return 2;
        case ::TypeTag::Int32: case ::TypeTag::UInt32: return 3;
        case ::TypeTag::Int: case ::TypeTag::UInt: case ::TypeTag::Int64: case ::TypeTag::UInt64: return 4;
        case ::TypeTag::Int128: case ::TypeTag::UInt128: return 5;
        case ::TypeTag::Float32: return 6;
        case ::TypeTag::Float64: return 7;
        case ::TypeTag::String: return 8;
        case ::TypeTag::Bool: return 0;
        default: return 0;
    }
}


bool Generator::is_signed_integer_type(TypePtr type) {
    if (!type) return false;
    return (type->tag == ::TypeTag::Int || type->tag == ::TypeTag::Int8 || 
            type->tag == ::TypeTag::Int16 || type->tag == ::TypeTag::Int32 || 
            type->tag == ::TypeTag::Int64 || type->tag == ::TypeTag::Int128);
}


bool Generator::is_decimal_type(TypePtr type) {
    return type && (type->tag == ::TypeTag::Decimal2 || type->tag == ::TypeTag::Decimal4 || type->tag == ::TypeTag::Decimal6);
}


int Generator::get_decimal_scale(TypePtr type) {
    if (!type) return 0;
    switch (type->tag) {
        case ::TypeTag::Decimal2: return 2;
        case ::TypeTag::Decimal4: return 4;
        case ::TypeTag::Decimal6: return 6;
        default: return 0;
    }
}


TypePtr Generator::get_wider_integer_type(TypePtr left_type, TypePtr right_type) {
    if (!left_type || !right_type) {
        return std::make_shared<::Type>(::TypeTag::Int64);
    }
    
    // Define type precedence (from narrowest to widest)
    std::map<TypeTag, int> type_rank = {
        {::TypeTag::Int8, 1}, {::TypeTag::UInt8, 1},
        {::TypeTag::Int16, 2}, {::TypeTag::UInt16, 2},
        {::TypeTag::Int32, 3}, {::TypeTag::UInt32, 3},
        {::TypeTag::Int, 4}, {::TypeTag::UInt, 4},
        {::TypeTag::Int64, 5}, {::TypeTag::UInt64, 5},
        {::TypeTag::Int128, 6}, {::TypeTag::UInt128, 6}
    };
    
    int left_rank = type_rank[left_type->tag];
    int right_rank = type_rank[right_type->tag];
    
    if (left_rank >= right_rank) {
        return left_type;
    } else {
        return right_type;
    }
}


TypePtr Generator::get_unsigned_version(TypePtr type) {
    if (!type) return std::make_shared<::Type>(::TypeTag::UInt64);
    
    switch (type->tag) {
        case ::TypeTag::Int8: return std::make_shared<::Type>(::TypeTag::UInt8);
        case ::TypeTag::Int16: return std::make_shared<::Type>(::TypeTag::UInt16);
        case ::TypeTag::Int32: return std::make_shared<::Type>(::TypeTag::UInt32);
        case ::TypeTag::Int: 
        case ::TypeTag::Int64: return std::make_shared<::Type>(::TypeTag::UInt64);
        case ::TypeTag::Int128: return std::make_shared<::Type>(::TypeTag::UInt128);
        case ::TypeTag::UInt8: 
        case ::TypeTag::UInt16: 
        case ::TypeTag::UInt32: 
        case ::TypeTag::UInt: 
        case ::TypeTag::UInt64: 
        case ::TypeTag::UInt128: return type; // Already unsigned
        default: return std::make_shared<::Type>(::TypeTag::UInt64);
    }
}


TypePtr Generator::get_best_integer_type(const std::string& value_str, bool prefer_signed) {
    try {
        // Try to parse as unsigned long long to check the magnitude
        unsigned long long ull_val = std::stoull(value_str);
        
        // Check system support for 128-bit integers
        bool has_int128 = false;
#ifdef __SIZEOF_INT128__
        has_int128 = true;
#endif
        
        if (prefer_signed) {
            // For signed integers, check if it fits in various ranges
            if (ull_val <= static_cast<unsigned long long>(std::numeric_limits<int8_t>::max())) {
                return std::make_shared<::Type>(::TypeTag::Int8);
            } else if (ull_val <= static_cast<unsigned long long>(std::numeric_limits<int16_t>::max())) {
                return std::make_shared<::Type>(::TypeTag::Int16);
            } else if (ull_val <= static_cast<unsigned long long>(std::numeric_limits<int32_t>::max())) {
                return std::make_shared<::Type>(::TypeTag::Int32);
            } else if (ull_val <= static_cast<unsigned long long>(std::numeric_limits<int64_t>::max())) {
                return std::make_shared<::Type>(::TypeTag::Int64);
            } else if (has_int128) {
                return std::make_shared<::Type>(::TypeTag::Int128);
            } else {
                // Fallback to unsigned if too large for signed
                return get_best_integer_type(value_str, false);
            }
        } else {
            // For unsigned integers
            if (ull_val <= static_cast<unsigned long long>(std::numeric_limits<uint8_t>::max())) {
                return std::make_shared<::Type>(::TypeTag::UInt8);
            } else if (ull_val <= static_cast<unsigned long long>(std::numeric_limits<uint16_t>::max())) {
                return std::make_shared<::Type>(::TypeTag::UInt16);
            } else if (ull_val <= static_cast<unsigned long long>(std::numeric_limits<uint32_t>::max())) {
                return std::make_shared<::Type>(::TypeTag::UInt32);
            } else if (ull_val <= static_cast<unsigned long long>(std::numeric_limits<uint64_t>::max())) {
                return std::make_shared<::Type>(::TypeTag::UInt64);
            } else if (has_int128) {
                return std::make_shared<::Type>(::TypeTag::UInt128);
            } else {
                // If no 128-bit support, this is an overflow situation
                return std::make_shared<::Type>(::TypeTag::UInt64);
            }
        }
    } catch (const std::exception&) {
        // If parsing fails, default to Int64
        return std::make_shared<::Type>(::TypeTag::Int64);
    }
}


bool Generator::is_numeric_string(const std::string& str) {
    if (str.empty()) return false;
    
    char first = str[0];
    if (!(std::isdigit(first) || first == '+' || first == '-' || first == '.')) {
        return false;
    }
    
    // Check if all characters are valid for a number
    for (char c : str) {
        if (!std::isdigit(c) && c != '.' && c != '+' && c != '-' && 
            c != 'e' && c != 'E' && c != 'u' && c != 'U' && 
            c != 'l' && c != 'L' && c != 'f' && c != 'F') {
            return false;
        }
    }
    return true;
}


bool Generator::types_match(TypePtr type1, TypePtr type2) {
    if (!type1 || !type2) return false;
    return type1->tag == type2->tag;
}

// Expression handlers

Reg Generator::emit_literal_expr(LM::Frontend::AST::LiteralExpr& expr, TypePtr expected_type) {
    Reg dst = allocate_register();
    
    // CRITICAL FIX: Use AST's inferred type first, then expected type, then default inference
    // For decimals, prioritize explicit expected_type context
    TypePtr target_type = (expected_type && is_decimal_type(expected_type)) ? expected_type : (expr.inferred_type ? expr.inferred_type : expected_type);
    
    // Create ValuePtr based on literal value
    ValuePtr const_val;
    
    if (std::holds_alternative<std::string>(expr.value)) {
        std::string stringValue = std::get<std::string>(expr.value);

        if (target_type && is_decimal_type(target_type)) {
            int scale = get_decimal_scale(target_type);
            const_val = std::make_shared<Value>(target_type, stringValue);
            Type abi_type = Type::I64;
            set_register_language_type(dst, target_type);
            LIR_Inst inst(LIR_Op::LoadConst, abi_type, dst, LM::Backend::VM::compiler_value_to_backend_value(const_val));
            inst.type_name = "d" + std::to_string(scale);
            emit_instruction(inst);
            return dst;
        }
        
        bool isStringLiteral = (expr.literalType == LM::Frontend::TokenType::STRING) ||
                              (expr.inferred_type && expr.inferred_type->tag == ::TypeTag::String);
        
        // Try to determine if this string represents a pure number
        bool isNumeric = false;
        bool isFloat = false;
        
        if (!isStringLiteral && !stringValue.empty()) {
            char first = stringValue[0];
            if (std::isdigit(first) || first == '+' || first == '-' || first == '.') {
                // Check if the ENTIRE string is a valid number
                bool hasInvalidChars = false;
                int dotCount = 0;
                for (char c : stringValue) {
                    if (c == '.') dotCount++;
                    if (!std::isdigit(c) && c != '.' && c != '+' && c != '-' && 
                        c != 'e' && c != 'E' && c != 'u' && c != 'U' && 
                        c != 'l' && c != 'L' && c != 'f' && c != 'F') {
                        hasInvalidChars = true;
                        break;
                    }
                }
                if (dotCount > 1) {
                    hasInvalidChars = true;
                }
                
                if (!hasInvalidChars) {
                    isNumeric = true;
                    // Check if it's a float
                    if (stringValue.find('.') != std::string::npos || 
                        stringValue.find('e') != std::string::npos || 
                        stringValue.find('E') != std::string::npos) {
                        isFloat = true;
                    }
                }
            }
        }
        
        if (isNumeric) {
            if (isFloat) {
                // Create float value
                auto float_type = target_type ? target_type : std::make_shared<::Type>(::TypeTag::Float64);
                try {
                    // For very small or very large numbers, preserve the original string representation
                    // to avoid precision loss during double conversion
                    bool isVerySmallOrLarge = (stringValue.find("e-") != std::string::npos || 
                                             stringValue.find("E-") != std::string::npos ||
                                             stringValue.find("e+") != std::string::npos ||
                                             stringValue.find("E+") != std::string::npos);
                    
                    if (isVerySmallOrLarge) {
                        // Preserve original string representation for scientific notation
                        const_val = std::make_shared<Value>(float_type, stringValue);
                    } else {
                        // For normal numbers, parse and convert
                        long double floatVal = std::stold(stringValue);
                        const_val = std::make_shared<Value>(float_type, floatVal);
                    }
                } catch (const std::exception& e) {
                    // If parsing fails, treat as string
                    auto string_type = std::make_shared<::Type>(::TypeTag::String);
                    const_val = std::make_shared<Value>(string_type, stringValue);
                }
            } else {
                // Create integer value - use target type if provided
                TypePtr int_type = target_type;
                
                if (!int_type) {
                    // Use expected type if available, otherwise infer from the literal value
                    if (expected_type) {
                        int_type = expected_type;
                    } else {
                        // For simple small literals, default to Int64 to avoid type mismatches
                        // This is a conservative approach that works well with mixed operations
                        try {
                            int64_t test_val = std::stoll(stringValue);
                            // If it fits in int64 and is a small number, use Int64
                            if (test_val >= 0 && test_val <= 1000000) {
                                int_type = std::make_shared<::Type>(::TypeTag::Int64);
                            } else {
                                // For larger values, use automatic type selection
                                int_type = get_best_integer_type(stringValue, true);
                            }
                        } catch (const std::exception&) {
                            // If parsing as signed fails, use automatic selection
                            int_type = get_best_integer_type(stringValue, true);
                        }
                    }
                }
                
                try {
                    // Check if it's a negative number
                    if (stringValue[0] == '-') {
                        // Parse as signed integer
                        int64_t intVal = std::stoll(stringValue);
                        const_val = std::make_shared<Value>(int_type, intVal);
                    } else {
                        // Check if the expected type is unsigned
                        bool expectUnsigned = (int_type && 
                                             (int_type->tag == TypeTag::UInt || int_type->tag == TypeTag::UInt8 ||
                                              int_type->tag == TypeTag::UInt16 || int_type->tag == TypeTag::UInt32 ||
                                              int_type->tag == TypeTag::UInt64 || int_type->tag == TypeTag::UInt128));
                        
                        if (expectUnsigned) {
                            // Expected type is unsigned, parse as unsigned
                            uint64_t uintVal = std::stoull(stringValue);
                           // std::cout << "[DEBUG] Parsing unsigned literal '" << stringValue
                           //           << "' as uint64_t: " << uintVal << std::endl;
                            const_val = std::make_shared<Value>(int_type, uintVal);
                           // std::cout << "[DEBUG] Created Value with data: '" << const_val->data 
                           //           << "' and type tag: " << static_cast<int>(const_val->type->tag) << std::endl;
                        } else {
                            // Expected type is signed or no specific expectation
                            uint64_t uintVal = std::stoull(stringValue);
                            
                            // Check if it fits in signed int64 range
                            if (uintVal <= 9223372036854775807ULL) {
                                // Fits in signed range, use as signed
                                int64_t intVal = static_cast<int64_t>(uintVal);
                                const_val = std::make_shared<Value>(int_type, intVal);
                            } else {
                                // Too large for signed, use as unsigned
                                const_val = std::make_shared<Value>(int_type, uintVal);
                            }
                        }
                    }
                } catch (const std::exception& e) {
                    // If parsing fails, treat as string
                    auto string_type = std::make_shared<::Type>(::TypeTag::String);
                    const_val = std::make_shared<Value>(string_type, stringValue);
                }
            }
        } else {
            // String value (already parsed, quotes removed by parser)
            // For quoted string literals from the parser, always treat as string type
            auto string_type = std::make_shared<::Type>(::TypeTag::String);
            const_val = std::make_shared<Value>(string_type, stringValue);
        }
    } else if (std::holds_alternative<bool>(expr.value)) {
        // Create boolean value
        auto bool_type = std::make_shared<::Type>(::TypeTag::Bool);
        bool boolVal = std::get<bool>(expr.value);
        const_val = std::make_shared<Value>(bool_type, boolVal);
    } else if (std::holds_alternative<std::nullptr_t>(expr.value)) {
        // Create nil value
        auto nil_type = std::make_shared<::Type>(::TypeTag::Nil);
        const_val = std::make_shared<Value>(nil_type, std::string("nil"));
    } else {
        // Default to nil
        auto nil_type = std::make_shared<::Type>(::TypeTag::Nil);
        const_val = std::make_shared<Value>(nil_type, "");
    }
    
    // Set type BEFORE emitting so it's available during emit_instruction
    if (const_val) {
        // Use the target type (AST inferred type takes priority)
        TypePtr final_type = target_type ? target_type : const_val->type;
        
        Type abi_type = language_type_to_abi_type(final_type);
        set_register_language_type(dst, final_type);
        set_register_type(dst, final_type);
        
        // Update the const_val type to match the target type
        if (target_type && target_type != const_val->type) {
            const_val->type = target_type;
        }
        
        LIR_Inst inst(LIR_Op::LoadConst, abi_type, dst, LM::Backend::VM::compiler_value_to_backend_value(const_val));
        if (final_type && is_decimal_type(final_type)) {
            inst.type_name = "d" + std::to_string(get_decimal_scale(final_type));
        }
        emit_instruction(inst);
    } else {
        emit_instruction(LIR_Inst(LIR_Op::LoadConst, Type::Void, dst, LM::Backend::VM::compiler_value_to_backend_value(const_val)));
    }
    return dst;
}


bool Generator::is_atomic_binding(const LM::Frontend::AST::Node& node) const {
    if (!ownership_facts_) return false;
    auto found = ownership_facts_->nodes.find(node.memory_info.semantic_id);
    return found != ownership_facts_->nodes.end() && ownership_facts_->atomic_bindings.count(found->second.binding);
}
Reg Generator::atomic_cell(const std::string& name) {
    if (env_register_ != UINT32_MAX) {
        auto capture = std::find(current_lambda_captures_.begin(), current_lambda_captures_.end(), name);
        if (capture != current_lambda_captures_.end()) {
            Reg index = allocate_register(), cell = allocate_register();
            emit_instruction(LIR_Inst(LIR_Op::LoadConst, Type::I64, index, make_i64(1 + std::distance(current_lambda_captures_.begin(), capture))));
            emit_instruction(LIR_Inst(LIR_Op::TupleGet, Type::Ptr, cell, env_register_, index));
            return cell;
        }
    }
    Reg cell = resolve_variable(name);
    if (cell != UINT32_MAX) return cell;
    cell = allocate_register();
    LIR_Inst load(LIR_Op::LoadGlobal, Type::Ptr, cell, 0, 0);
    load.func_name = (!current_module_.empty() && current_module_ != "root") ? current_module_ + "." + name : name;
    emit_instruction(load);
    return cell;
}
Reg Generator::atomic_read(Reg cell) {
    Reg result = allocate_register();
    emit_instruction(LIR_Inst(LIR_Op::FrameGetFieldAtomic, Type::I64, result, cell, 0));
    set_register_language_type(result, std::make_shared<::Type>(::TypeTag::Int64));
    return result;
}
Reg Generator::emit_variable_expr(LM::Frontend::AST::VariableExpr& expr) {
    if (is_atomic_binding(expr)) return atomic_read(atomic_cell(expr.name));
    // Check if this is a captured variable in a lambda
    if (env_register_ != UINT32_MAX) {
        auto it = std::find(current_lambda_captures_.begin(), current_lambda_captures_.end(), expr.name);
        if (it != current_lambda_captures_.end()) {
            size_t index = std::distance(current_lambda_captures_.begin(), it);
            Reg result = allocate_register();
            
            // In Tuple: (lambda_name, capture0, capture1, ...)
            // Captured variables start at index 1
            Reg idx_reg = allocate_register();
            emit_instruction(LIR_Inst(LIR_Op::LoadConst, Type::I64, idx_reg, make_i64(index + 1)));
            
            Type abi_type = Type::I64;
            if (expr.inferred_type) {
                abi_type = language_type_to_abi_type(expr.inferred_type);
            }
            
            emit_instruction(LIR_Inst(LIR_Op::TupleGet, abi_type, result, env_register_, idx_reg));
            
            if (expr.inferred_type) {
                set_register_language_type(result, expr.inferred_type);
            }
            return result;
        }
    }

    // Check regular variable scope
    Reg reg = resolve_variable(expr.name);
    if (reg != UINT32_MAX) return reg;

    // Check if it's a function name used as a value (first-class functions)
    if (function_table_.find(expr.name) != function_table_.end() || 
        LIRFunctionManager::getInstance().hasFunction(expr.name) ||
        BuiltinUtils::isBuiltinFunction(expr.name)) {
        
        Reg func_reg = allocate_register();
        auto func_type = std::make_shared<::Type>(::TypeTag::Function);
        // In our LIR/VM, functions are referred to by name strings
        auto string_type = std::make_shared<::Type>(::TypeTag::String);
        Backend::Value name_val = BOX_PTR(lm_str_from_cstr(expr.name.c_str()));
        emit_instruction(LIR_Inst(LIR_Op::LoadConst, Type::Ptr, func_reg, name_val));
        set_register_language_type(func_reg, func_type);
        set_register_abi_type(func_reg, Type::Ptr);
        return func_reg;
    }

    // First check if this is a module variable access (e.g., "math.pi")
    size_t dot_pos = expr.name.rfind('.');
    if (dot_pos != std::string::npos) {
        std::string module_name = expr.name.substr(0, dot_pos);
        std::string symbol_name = expr.name.substr(dot_pos + 1);
        
        // Check for alias mapping
        auto alias_it = import_aliases_.find(module_name);
        if (alias_it != import_aliases_.end()) {
            module_name = alias_it->second;
        }
        
        // Resolve module symbol
        std::string qualified_name = module_name + "." + symbol_name;
        ModuleSymbolInfo* symbol = resolve_module_symbol(qualified_name);
        if (symbol && symbol->is_variable) {
            if (!can_access_module_symbol(*symbol, current_module_)) {
                report_error("Cannot access private/protected variable: " + qualified_name);
                return 0;
            }
            
            // Load the actual module variable value using LoadGlobal
            Reg result = allocate_register();
            LIR_Inst load_inst(LIR_Op::LoadGlobal, Type::Ptr, result, 0, 0);
            load_inst.func_name = qualified_name;
            emit_instruction(load_inst);
            return result;
        }
    }

    // Check if it's a global module variable accessed directly
    std::string qualified_name = (!current_module_.empty() && current_module_ != "root") ? (current_module_ + "." + expr.name) : expr.name;
    Reg result = allocate_register();
    LIR_Inst load_inst(LIR_Op::LoadGlobal, Type::Ptr, result, 0, 0);
    load_inst.func_name = qualified_name;
    emit_instruction(load_inst);
    if (expr.inferred_type) {
        set_register_language_type(result, expr.inferred_type);
        set_register_abi_type(result, language_type_to_abi_type(expr.inferred_type));
    }
    return result;
    
    // Set the type information for the register if available
    if (expr.inferred_type) {
        set_register_type(reg, expr.inferred_type);
        set_register_language_type(reg, expr.inferred_type);
        set_register_abi_type(reg, language_type_to_abi_type(expr.inferred_type));
    } else {
        // Set a default type if no inference is available
        auto any_type = std::make_shared<::Type>(::TypeTag::Any);
        set_register_type(reg, any_type);
    }
    
    return reg;
}


Reg Generator::emit_interpolated_string_expr(LM::Frontend::AST::InterpolatedStringExpr& expr) {
    auto string_type = std::make_shared<::Type>(::TypeTag::String);

    if (expr.parts.empty()) {
        Reg result = allocate_register();
        Backend::Value result_val = BOX_PTR(lm_str_from_cstr(""));
        emit_instruction(LIR_Inst(LIR_Op::LoadConst, Type::Ptr, result, result_val));
        set_register_language_type(result, string_type);
        return result;
    }

    // Check for constant folding opportunity
    bool all_parts_are_string_literals = true;
    std::string folded_result = "";
    
    for (const auto& part : expr.parts) {
        if (std::holds_alternative<std::string>(part)) {
            folded_result += std::get<std::string>(part);
        } else {
            all_parts_are_string_literals = false;
            break;
        }
    }
    
    // Constant folding: if all parts are string literals, fold them
    if (all_parts_are_string_literals) {
        Reg result = allocate_register();
        Backend::Value result_val = BOX_PTR(lm_str_from_cstr(folded_result.c_str()));
        emit_instruction(LIR_Inst(LIR_Op::LoadConst, Type::Ptr, result, result_val));
        set_register_language_type(result, string_type);
        return result;
    }

    // For complex interpolations, use STR_FORMAT
    // Build format string and collect argument registers
    std::string format_string = "";
    std::vector<Reg> arg_regs;
    arg_regs.reserve(expr.parts.size());
    
    for (const auto& part : expr.parts) {
        if (std::holds_alternative<std::string>(part)) {
            format_string += std::get<std::string>(part);
        } else if (std::holds_alternative<std::shared_ptr<LM::Frontend::AST::Expression>>(part)) {
            format_string += "%s" ; // Use standard format marker
            auto expr_part = std::get<std::shared_ptr<LM::Frontend::AST::Expression>>(part);
            Reg expr_reg = emit_expr(*expr_part);
            arg_regs.push_back(expr_reg);
        }
    }
    
    // Emit STR_FORMAT instruction
    Reg result = allocate_register();
    Reg format_reg = allocate_register();
    Backend::Value format_val = BOX_PTR(lm_str_from_cstr(format_string.c_str()));
    emit_instruction(LIR_Inst(LIR_Op::LoadConst, Type::Ptr, format_reg, format_val));
    
    // Handle multiple arguments by chaining STR_FORMAT calls
    Reg current_result = format_reg;
    for (size_t i = 0; i < arg_regs.size(); i++) {
        Type arg_abi = get_register_abi_type(arg_regs[i]);
        if (i == 0) {
            // First argument: format with first arg
            LIR_Inst inst(LIR_Op::STR_FORMAT, Type::Ptr, result, format_reg, arg_regs[i]);
            inst.type_a = Type::Ptr;
            inst.type_b = arg_abi;
            emit_instruction(inst);
            current_result = result;
        } else {
            // Subsequent arguments: format previous result with next arg
            Reg temp_result = allocate_register();
            LIR_Inst inst(LIR_Op::STR_FORMAT, Type::Ptr, temp_result, current_result, arg_regs[i]);
            inst.type_a = Type::Ptr;
            inst.type_b = arg_abi;
            emit_instruction(inst);
            current_result = temp_result;
            if (i == arg_regs.size() - 1) {
                // Final result is in temp_result, move to result register
                emit_instruction(LIR_Inst(LIR_Op::Mov, result, temp_result, 0));
            }
        }
    }
    
    set_register_language_type(result, string_type);
    return result;
}


Reg Generator::emit_binary_expr(LM::Frontend::AST::BinaryExpr& expr) {
    if (expr.op == LM::Frontend::TokenType::AND || expr.op == LM::Frontend::TokenType::OR) {
        Reg result = allocate_register();
        set_register_language_type(result, std::make_shared<::Type>(::TypeTag::Bool));
        Reg left = emit_expr(*expr.left);
        
        if (cfg_context_.building_cfg) {
            LIR_BasicBlock* right_block = create_basic_block("logic_right");
            LIR_BasicBlock* end_block = create_basic_block("logic_end");
            if (expr.op == LM::Frontend::TokenType::AND) {
                emit_instruction(LIR_Inst(LIR_Op::Mov, Type::Bool, result, left, 0));
                emit_instruction(LIR_Inst(LIR_Op::JumpIfFalse, 0, left, 0, end_block->id));
            } else {
                emit_instruction(LIR_Inst(LIR_Op::Mov, Type::Bool, result, left, 0));
                emit_instruction(LIR_Inst(LIR_Op::JumpIf, 0, left, 0, end_block->id));
            }
            add_block_edge(get_current_block(), right_block);
            add_block_edge(get_current_block(), end_block);
            set_current_block(right_block);
            Reg right = emit_expr(*expr.right);
            emit_instruction(LIR_Inst(LIR_Op::Mov, Type::Bool, result, right, 0));
            if (get_current_block() && !get_current_block()->has_terminator()) {
                emit_instruction(LIR_Inst(LIR_Op::Jump, 0, 0, 0, end_block->id));
                add_block_edge(get_current_block(), end_block);
            }
            set_current_block(end_block);
        } else {
            if (expr.op == LM::Frontend::TokenType::AND) {
                emit_instruction(LIR_Inst(LIR_Op::Mov, Type::Bool, result, left, 0));
                size_t jump_to_patch = current_function_->instructions.size();
                emit_instruction(LIR_Inst(LIR_Op::JumpIfFalse, Type::Void, 0, left, 0, 0));
                Reg right = emit_expr(*expr.right);
                emit_instruction(LIR_Inst(LIR_Op::Mov, Type::Bool, result, right, 0));
                current_function_->instructions[jump_to_patch].imm = current_function_->instructions.size();
            } else {
                emit_instruction(LIR_Inst(LIR_Op::Mov, Type::Bool, result, left, 0));
                size_t jump_to_patch = current_function_->instructions.size();
                emit_instruction(LIR_Inst(LIR_Op::JumpIf, Type::Void, 0, left, 0, 0));
                Reg right = emit_expr(*expr.right);
                emit_instruction(LIR_Inst(LIR_Op::Mov, Type::Bool, result, right, 0));
                current_function_->instructions[jump_to_patch].imm = current_function_->instructions.size();
            }
        }
        return result;
    }

    // Evaluate each operand exactly once, including side-effecting reader calls.
    Reg left = emit_expr(*expr.left);
    Reg right = emit_expr(*expr.right);
    // Handle PLUS operator - check for string concatenation first
    if (expr.op == LM::Frontend::TokenType::PLUS) {
        TypePtr left_type = get_register_type(left);
        TypePtr right_type = get_register_type(right);
        
        // Check if EITHER operand is a string type
        bool left_is_string = (left_type && left_type->tag == ::TypeTag::String);
        bool right_is_string = (right_type && right_type->tag == ::TypeTag::String);
        
        if (left_is_string || right_is_string) {
            // Convert non-string operand to string using ToString
            if (!left_is_string) {
                Reg str_left = allocate_register();
                emit_instruction(LIR_Inst(LIR_Op::ToString, Type::Ptr, str_left, left, 0));
                auto string_type = std::make_shared<::Type>(::TypeTag::String);
                set_register_language_type(str_left, string_type);
                left = str_left;
            }
            if (!right_is_string) {
                Reg str_right = allocate_register();
                emit_instruction(LIR_Inst(LIR_Op::ToString, Type::Ptr, str_right, right, 0));
                auto string_type = std::make_shared<::Type>(::TypeTag::String);
                set_register_language_type(str_right, string_type);
                right = str_right;
            }
            
            // Perform string concatenation
            Reg dst = allocate_register();
            auto string_type = std::make_shared<::Type>(::TypeTag::String);
            set_register_language_type(dst, string_type);
            emit_instruction(LIR_Inst(LIR_Op::STR_CONCAT, Type::Ptr, dst, left, right));
            return dst;
        }
    }
    
    // Handle as arithmetic operation
    Reg dst = allocate_register();
    
    // Map operator to LIR operation
    LIR_Op op;
    if (expr.op == LM::Frontend::TokenType::PLUS) op = LIR_Op::Add;
    else if (expr.op == LM::Frontend::TokenType::MINUS) op = LIR_Op::Sub;
    else if (expr.op == LM::Frontend::TokenType::STAR) op = LIR_Op::Mul;
    else if (expr.op == LM::Frontend::TokenType::SLASH) {
        // Handle division with proper type checking
        TypePtr left_type = get_register_type(left);
        TypePtr right_type = get_register_type(right);
        
        bool left_is_int = left_type && 
            (left_type->tag == ::TypeTag::Int || left_type->tag == ::TypeTag::Int64 ||
             left_type->tag == ::TypeTag::Int32 || left_type->tag == ::TypeTag::Int16 ||
             left_type->tag == ::TypeTag::Int8 || left_type->tag == ::TypeTag::UInt ||
             left_type->tag == ::TypeTag::UInt64 || left_type->tag == ::TypeTag::UInt32 ||
             left_type->tag == ::TypeTag::UInt16 || left_type->tag == ::TypeTag::UInt8);
        
        bool right_is_int = right_type && 
            (right_type->tag == ::TypeTag::Int || right_type->tag == ::TypeTag::Int64 ||
             right_type->tag == ::TypeTag::Int32 || right_type->tag == ::TypeTag::Int16 ||
             right_type->tag == ::TypeTag::Int8 || right_type->tag == ::TypeTag::UInt ||
             right_type->tag == ::TypeTag::UInt64 || right_type->tag == ::TypeTag::UInt32 ||
             right_type->tag == ::TypeTag::UInt16 || right_type->tag == ::TypeTag::UInt8);
        
        if (left_is_int && right_is_int) {
            // INTEGER DIVISION: 284/4 = 71 (no decimal)
            op = LIR_Op::Div;
        } else {
            // FLOAT DIVISION: 10/2.847 = 3.512... (with decimal)
            op = LIR_Op::Div;
            
            // Convert integer operands to float for division
            if (left_is_int) {
                Reg float_left = allocate_register();
                emit_instruction(LIR_Inst(LIR_Op::Cast, Type::F64, float_left, left, 0));
                left = float_left;
            }
            if (right_is_int) {
                Reg float_right = allocate_register();
                emit_instruction(LIR_Inst(LIR_Op::Cast, Type::F64, float_right, right, 0));
                right = float_right;
            }
        }
    }
    else if (expr.op == LM::Frontend::TokenType::MODULUS) op = LIR_Op::Mod;
    else if (expr.op == LM::Frontend::TokenType::POWER) {
        Reg res = allocate_register();
        auto float_type = std::make_shared<::Type>(::TypeTag::Float64);
        Reg f_left = left;
        if (get_register_type(left) && get_register_type(left)->tag != ::TypeTag::Float64) {
            f_left = allocate_register();
            emit_instruction(LIR_Inst(LIR_Op::Cast, Type::F64, f_left, left, 0));
        }
        Reg f_right = right;
        if (get_register_type(right) && get_register_type(right)->tag != ::TypeTag::Float64) {
            f_right = allocate_register();
            emit_instruction(LIR_Inst(LIR_Op::Cast, Type::F64, f_right, right, 0));
        }
        LIR_Inst call_inst(LIR_Op::CallBuiltin, Type::F64, res, 0, 0);
        call_inst.func_name = "pow";
        emit_instruction(call_inst);
        set_register_type(res, float_type);
        return res;
    }
    else if (expr.op == LM::Frontend::TokenType::EQUAL_EQUAL) op = LIR_Op::CmpEQ;
    else if (expr.op == LM::Frontend::TokenType::BANG_EQUAL) op = LIR_Op::CmpNEQ;
    else if (expr.op == LM::Frontend::TokenType::LESS) op = LIR_Op::CmpLT;
    else if (expr.op == LM::Frontend::TokenType::LESS_EQUAL) op = LIR_Op::CmpLE;
    else if (expr.op == LM::Frontend::TokenType::GREATER) op = LIR_Op::CmpGT;
    else if (expr.op == LM::Frontend::TokenType::GREATER_EQUAL) op = LIR_Op::CmpGE;
    else if (expr.op == LM::Frontend::TokenType::AMPERSAND) op = LIR_Op::And;
    else if (expr.op == LM::Frontend::TokenType::PIPE) op = LIR_Op::Or;
    else if (expr.op == LM::Frontend::TokenType::CARET) op = LIR_Op::Xor;
    else if (expr.op == LM::Frontend::TokenType::LESS_LESS) op = LIR_Op::Shl;
    else if (expr.op == LM::Frontend::TokenType::GREATER_GREATER) op = LIR_Op::Shr;
    else {
        report_error("Unknown binary operator");
        return 0;
    }
    
    // Infer result type based on operands and operation
    TypePtr result_type = nullptr;
    TypePtr left_type = get_register_type(left);
    TypePtr right_type = get_register_type(right);
    
    // For arithmetic operations, determine result type
    if (op == LIR_Op::Add || op == LIR_Op::Sub || op == LIR_Op::Mul || op == LIR_Op::Div || op == LIR_Op::Mod) {
        if (is_decimal_type(left_type) || is_decimal_type(right_type)) {
            // Decimal arithmetic
            int left_scale = get_decimal_scale(left_type);
            int right_scale = get_decimal_scale(right_type);
            int max_scale = std::max(left_scale, right_scale);

            // Map common arithmetic to decimal opcodes
            if (op == LIR_Op::Add) op = LIR_Op::DecAdd;
            else if (op == LIR_Op::Sub) op = LIR_Op::DecSub;
            else if (op == LIR_Op::Mul) op = LIR_Op::DecMul;
            else if (op == LIR_Op::Div) op = LIR_Op::DecDiv;
            else if (op == LIR_Op::Mod) op = LIR_Op::DecMod;

            // Handle implicit rescaling
            if (left_scale < max_scale) {
                Reg rescaled_left = allocate_register();
                Type target_abi = Type::I64;
                TypePtr target_type = (max_scale == 4) ? type_system_->getType("d4") : (max_scale == 6 ? type_system_->getType("d6") : type_system_->getType("d2"));
                emit_instruction(LIR_Inst(LIR_Op::DecRescale, target_abi, rescaled_left, left, 0));
                set_register_language_type(rescaled_left, target_type);
                set_register_type(rescaled_left, target_type);
                left = rescaled_left;
                left_type = target_type;
            }
            if (right_scale < max_scale) {
                Reg rescaled_right = allocate_register();
                Type target_abi = Type::I64;
                TypePtr target_type = (max_scale == 4) ? type_system_->getType("d4") : (max_scale == 6 ? type_system_->getType("d6") : type_system_->getType("d2"));
                emit_instruction(LIR_Inst(LIR_Op::DecRescale, target_abi, rescaled_right, right, 0));
                set_register_language_type(rescaled_right, target_type);
                set_register_type(rescaled_right, target_type);
                right = rescaled_right;
                right_type = target_type;
            }

            result_type = left_type; // Both now have max_scale
            set_register_type(dst, result_type);
            emit_instruction(LIR_Inst(op, Type::I64, dst, left, right));
            return dst;
        }

        // If either operand is float, result is float
        if ((left_type && left_type->tag == ::TypeTag::Float64) || 
            (right_type && right_type->tag == ::TypeTag::Float64)) {
            result_type = std::make_shared<::Type>(::TypeTag::Float64);
        } else if ((left_type && left_type->tag == ::TypeTag::Float32) || 
                   (right_type && right_type->tag == ::TypeTag::Float32)) {
            result_type = std::make_shared<::Type>(::TypeTag::Float32);
        } else {
            // For integer operations, preserve signedness and promote to wider type
            result_type = get_promoted_numeric_type(left_type, right_type);
        }
        
        // Check for type mismatches and re-emit if needed
        if (left_type && right_type && result_type) {
            // Implement "smaller matches larger" strategy
            int left_rank = get_type_rank(left_type);
            int right_rank = get_type_rank(right_type);
            
            // Re-emit the smaller/lower rank operand to match the larger one
            if (left_rank < right_rank) {
                if (auto left_literal = dynamic_cast<LM::Frontend::AST::LiteralExpr*>(expr.left.get())) {
                    left = emit_literal_expr(*left_literal, right_type);
                    left_type = right_type;
                }
            } else if (right_rank < left_rank) {
                if (auto right_literal = dynamic_cast<LM::Frontend::AST::LiteralExpr*>(expr.right.get())) {
                    right = emit_literal_expr(*right_literal, left_type);
                    right_type = left_type;
                }
            }
            // If ranks are equal but types differ, prefer signed to avoid unsigned promotion issues
            else if (left_rank == right_rank && !types_match(left_type, right_type)) {
                bool left_is_signed = is_signed_integer_type(left_type);
                bool right_is_signed = is_signed_integer_type(right_type);
                
                if (!left_is_signed && right_is_signed) {
                    auto left_literal = dynamic_cast<LM::Frontend::AST::LiteralExpr*>(expr.left.get());
                    if (left_literal) {
                        left = emit_literal_expr(*left_literal, right_type);
                        left_type = right_type;
                    }
                } else if (left_is_signed && !right_is_signed) {
                    auto right_literal = dynamic_cast<LM::Frontend::AST::LiteralExpr*>(expr.right.get());
                    if (right_literal) {
                        right = emit_literal_expr(*right_literal, left_type);
                        right_type = left_type;
                    }
                }
            }
        }
    } else if (op == LIR_Op::CmpEQ || op == LIR_Op::CmpNEQ || op == LIR_Op::CmpLT || 
               op == LIR_Op::CmpLE || op == LIR_Op::CmpGT || op == LIR_Op::CmpGE) {
        // Comparison operations return bool
        result_type = std::make_shared<::Type>(::TypeTag::Bool);
        
        // For comparisons, ensure operands have compatible types
        // This is important for comparing literals with variables of specific types
        if (left_type && right_type && !types_match(left_type, right_type)) {
            int left_rank = get_type_rank(left_type);
            int right_rank = get_type_rank(right_type);
            
            // Re-emit the smaller/lower rank operand to match the larger one
            if (left_rank < right_rank) {
                if (auto left_literal = dynamic_cast<LM::Frontend::AST::LiteralExpr*>(expr.left.get())) {
                    left = emit_literal_expr(*left_literal, right_type);
                    left_type = right_type;
                }
            } else if (right_rank < left_rank) {
                if (auto right_literal = dynamic_cast<LM::Frontend::AST::LiteralExpr*>(expr.right.get())) {
                    right = emit_literal_expr(*right_literal, left_type);
                    right_type = left_type;
                }
            }
            // If ranks are equal but types differ, prefer unsigned to avoid signed/unsigned issues
            else if (left_rank == right_rank && !types_match(left_type, right_type)) {
                bool left_is_signed = is_signed_integer_type(left_type);
                bool right_is_signed = is_signed_integer_type(right_type);
                
                if (left_is_signed && !right_is_signed) {
                    auto left_literal = dynamic_cast<LM::Frontend::AST::LiteralExpr*>(expr.left.get());
                    if (left_literal) {
                        left = emit_literal_expr(*left_literal, right_type);
                        left_type = right_type;
                    }
                } else if (!left_is_signed && right_is_signed) {
                    auto right_literal = dynamic_cast<LM::Frontend::AST::LiteralExpr*>(expr.right.get());
                    if (right_literal) {
                        right = emit_literal_expr(*right_literal, left_type);
                        right_type = left_type;
                    }
                }
            }
        }
    } else if (op == LIR_Op::And || op == LIR_Op::Or) {
        if (expr.op == LM::Frontend::TokenType::AND || expr.op == LM::Frontend::TokenType::OR) {
            result_type = std::make_shared<::Type>(::TypeTag::Bool);
        } else {
            result_type = get_promoted_numeric_type(left_type, right_type);
        }
    } else if (op == LIR_Op::Xor || op == LIR_Op::Shl || op == LIR_Op::Shr) {
        result_type = get_promoted_numeric_type(left_type, right_type);
    }
    
    // Set type BEFORE emitting so it's available during emit_instruction
    if (result_type) {
        set_register_type(dst, result_type);
        Type abi_type = language_type_to_abi_type(result_type);
        emit_instruction(LIR_Inst(op, abi_type, dst, left, right));
    } else {
        // Fallback for operations without result type
       // std::cout << "[DEBUG] Emitting instruction: op=" << static_cast<int>(op) << " dst=" << dst << " left=" << left << " right=" << right << std::endl;
        emit_instruction(LIR_Inst(op, dst, left, right));
    }
    
    return dst;
}


Reg Generator::emit_unary_expr(LM::Frontend::AST::UnaryExpr& expr) {
    Reg operand = emit_expr(*expr.right);
    Reg dst = allocate_register();
    TypePtr operand_type = get_register_type(operand);
    TypePtr result_type = nullptr;
    
    if (expr.op == LM::Frontend::TokenType::MINUS) {
        // Result type is same as operand type
        result_type = operand_type;
        set_register_type(dst, result_type);
        // Use Neg operation for unary minus (more efficient than Sub from 0)
        emit_instruction(LIR_Inst(LIR_Op::Neg, dst, operand, 0));
    } else if (expr.op == LM::Frontend::TokenType::PLUS) {
        // Result type is same as operand type
        result_type = operand_type;
        set_register_type(dst, result_type);
        // Unary plus - just copy the value (no operation needed)
        emit_instruction(LIR_Inst(LIR_Op::Mov, dst, operand, 0));
    } else if (expr.op == LM::Frontend::TokenType::BANG || expr.op == LM::Frontend::TokenType::NOT) {
        // Result type is bool
        result_type = std::make_shared<::Type>(::TypeTag::Bool);
        set_register_type(dst, result_type);
        // Logical NOT - compare with true and negate (operand != true gives us !operand)
        Reg true_reg = allocate_register();
        auto bool_type = std::make_shared<::Type>(::TypeTag::Bool);
        Backend::Value true_val = VAL_TRUE;
        emit_instruction(LIR_Inst(LIR_Op::LoadConst, Type::Bool, true_reg, true_val));
        set_register_type(true_reg, bool_type);
        emit_instruction(LIR_Inst(LIR_Op::CmpNEQ, dst, operand, true_reg));
    } else if (expr.op == LM::Frontend::TokenType::TILDE) {
        // Result type is int
        auto int_type = std::make_shared<::Type>(::TypeTag::Int);
        result_type = int_type;
        set_register_type(dst, result_type);
        // Bitwise NOT - XOR with all bits set (for 64-bit: -1)
        Reg all_bits = allocate_register();
        Backend::Value neg_one_val = make_i64(-1);
        emit_instruction(LIR_Inst(LIR_Op::LoadConst, Type::I64, all_bits, neg_one_val));
        set_register_type(all_bits, int_type);
        emit_instruction(LIR_Inst(LIR_Op::Xor, dst, operand, all_bits));
    } else if (expr.op == LM::Frontend::TokenType::QUESTION) {
        // Error propagation operator (?)
        // This should check if operand is an error, and if so, return early from the function
        // Pattern: if (is_error(operand)) return operand; else return unwrap(operand);
        
        // Check if operand is an error
        Reg is_error_reg = allocate_register();
        auto bool_type = std::make_shared<::Type>(::TypeTag::Bool);
        set_register_type(is_error_reg, bool_type);
        emit_instruction(LIR_Inst(LIR_Op::IsError, Type::Bool, is_error_reg, operand, 0));
        
        if (cfg_context_.building_cfg) {
            // CFG mode: create blocks for error handling
            LIR_BasicBlock* error_block = create_basic_block("error_propagation");
            LIR_BasicBlock* success_block = create_basic_block("success_unwrap");
            
            // If it's an error, jump to error propagation block
            emit_instruction(LIR_Inst(LIR_Op::JumpIf, Type::Void, 0, is_error_reg, 0, error_block->id));
            
            // Add unconditional jump to success block (fall-through case)
            emit_instruction(LIR_Inst(LIR_Op::Jump, Type::Void, 0, 0, 0, success_block->id));
            
            // Set up CFG edges
            add_block_edge(get_current_block(), error_block);
            add_block_edge(get_current_block(), success_block);
            
            // === Success Block: unwrap the value ===
            set_current_block(success_block);
            
            // Create a register for the unwrapped value
            Reg unwrapped_reg = allocate_register();
            
            // Try to determine the inner type from the Result type
            result_type = operand_type;
            set_register_type(unwrapped_reg, result_type);
            set_register_type(dst, result_type);
            
            // Unwrap the value (this will be the success case)
            emit_instruction(LIR_Inst(LIR_Op::Unwrap, Type::I64, unwrapped_reg, operand, 0));
            
            // Move unwrapped value to destination
            emit_instruction(LIR_Inst(LIR_Op::Mov, Type::I64, dst, unwrapped_reg, 0));
            
            // === Error Block: propagate error by returning ===
            set_current_block(error_block);
            
            // For proper error propagation, return the error value directly
            emit_instruction(LIR_Inst(LIR_Op::Return, Type::Void, operand, 0, 0));
            
            // Mark error block as terminated since it has a return
            error_block->terminated = true;
            
            // Switch back to success block for continuation
            set_current_block(success_block);
            
            // Note: The success block intentionally doesn't have a terminator
            // because it continues with the next statement in the calling context
            
        } else {
            // Linear mode: use labels and jumps
            uint32_t error_label = generate_label();
            uint32_t continue_label = generate_label();
            
            // If it's an error, jump to error propagation
            emit_label_jump(LIR_Op::JumpIf, is_error_reg, error_label);
            
            // Success path: unwrap the value
            Reg unwrapped_reg = allocate_register();
            
            // Try to determine the inner type from the Result type
            result_type = operand_type;
            set_register_type(unwrapped_reg, result_type);
            set_register_type(dst, result_type);
            
            // Unwrap the value (this will be the success case)
            emit_instruction(LIR_Inst(LIR_Op::Unwrap, Type::I64, unwrapped_reg, operand, 0));
            
            // Move unwrapped value to destination
            emit_instruction(LIR_Inst(LIR_Op::Mov, Type::I64, dst, unwrapped_reg, 0));
            
            // Jump to continue execution
            emit_label_jump(LIR_Op::Jump, 0, continue_label);
            
            // Error propagation block
            place_label(error_label);
            
            // For proper error propagation, return the error value directly
            emit_instruction(LIR_Inst(LIR_Op::Return, Type::Void, operand, 0, 0));
            
            // Continue execution label
            place_label(continue_label);
        }
        
       // std::cout << "[DEBUG] Generated error propagation (?) for register " << operand 
      //            << " -> " << dst << std::endl;
    } else {
        report_error("Unknown unary operator");
        return 0;
    }
    
    return dst;
}


Reg Generator::emit_call_expr(LM::Frontend::AST::CallExpr& expr) {
    auto argument_effect = [&](size_t index) {
        if (ownership_facts_) {
            auto fact = ownership_facts_->nodes.find(expr.memory_info.semantic_id);
            if (fact != ownership_facts_->nodes.end() && index < fact->second.arguments.size())
                return fact->second.arguments[index];
        }
        return Memory::Ownership::Unspecified;
    };
    auto emit_argument = [&](LM::Frontend::AST::Expression& argument, size_t index) {
        auto value = emit_expr(argument);
        return argument_effect(index) == Memory::Ownership::WriteBorrow
            ? emit_checked_dereference(argument, value, true, true) : value;
    };
    if (auto var_expr = dynamic_cast<LM::Frontend::AST::VariableExpr*>(expr.callee.get())) {
        std::string func_name = var_expr->name;
        
        // --- 0. Variable / Indirect Call check ---
        bool is_variable = (resolve_variable(func_name) != UINT32_MAX);
        if (!is_variable && env_register_ != UINT32_MAX) {
            if (std::find(current_lambda_captures_.begin(), current_lambda_captures_.end(), func_name) != current_lambda_captures_.end()) {
                is_variable = true;
            }
        }
        if (is_variable) {
            Reg closure_reg = emit_variable_expr(*var_expr);
            std::vector<Reg> arg_regs;
            arg_regs.reserve(expr.arguments.size());
            for (const auto& arg : expr.arguments) arg_regs.push_back(emit_argument(*arg, arg_regs.size()));
            Reg result = allocate_register();
            Type abi_type = Type::Void;
            if (expr.inferred_type) abi_type = language_type_to_abi_type(expr.inferred_type);
            LIR_Inst call_inst(LIR_Op::CallIndirect, abi_type, result, closure_reg, 0);
            call_inst.call_args = arg_regs;
            emit_instruction(call_inst);
            if (expr.inferred_type) {
                set_register_type(result, expr.inferred_type);
                set_register_language_type(result, expr.inferred_type);
            } else {
                set_register_type(result, std::make_shared<::Type>(::TypeTag::Int));
            }
            return result;
        }
        
        // --- 1. Intrinsic lookup ---
        std::string registry_lookup_name = func_name;
        size_t d_pos = func_name.rfind('.');
        if (d_pos != std::string::npos) {
            std::string mod_name = func_name.substr(0, d_pos);
            std::string sym_name = func_name.substr(d_pos + 1);
            auto a_it = import_aliases_.find(mod_name);
            if (a_it != import_aliases_.end()) mod_name = a_it->second;
            registry_lookup_name = mod_name + "." + sym_name;
        }

        if (auto intrinsic = IntrinsicRegistry::getInstance().getIntrinsic(registry_lookup_name)) {
            std::vector<Reg> arg_regs;
            arg_regs.reserve(expr.arguments.size());
            for (const auto& arg : expr.arguments) arg_regs.push_back(emit_argument(*arg, arg_regs.size()));
            Reg result = allocate_register();
            Type abi_res_type = (expr.inferred_type) ? language_type_to_abi_type(expr.inferred_type) : Type::Void;
            if (expr.inferred_type) set_register_language_type(result, expr.inferred_type);
            
            LIR_Inst inst(intrinsic->opcode, abi_res_type, result, 0, 0, 0);
            inst.imm = intrinsic->type_id; 
            inst.func_name = registry_lookup_name;
            if (arg_regs.size() > 0) inst.a = arg_regs[0];
            if (arg_regs.size() > 1) inst.b = arg_regs[1];
            for (size_t k = 0; k < arg_regs.size(); ++k) inst.call_args.push_back(arg_regs[k]);
            emit_instruction(inst);
            return result;
        }

        // --- 2. Builtin Check ---
        std::vector<Reg> arg_regs;
        arg_regs.reserve(expr.arguments.size());
        for (const auto& arg : expr.arguments) arg_regs.push_back(emit_argument(*arg, arg_regs.size()));
        Reg result = allocate_register();
        
        std::string vm_name = func_name;
        LIR_Op op = LIR_Op::Call;
        bool is_builtin = false;
        
        if (func_name == "len" || func_name == "length" || func_name == "_builtin_len" || 
            (func_name.length() >= 4 && func_name.substr(func_name.length()-4) == ".len") ||
            (func_name.length() >= 7 && func_name.substr(func_name.length()-7) == ".length")) {
            op = LIR_Op::CallBuiltin; vm_name = "len"; is_builtin = true;
        } else if (func_name == "print" || func_name == "assert") {
            op = LIR_Op::CallBuiltin; vm_name = func_name; is_builtin = true;
        } else if (func_name.length() >= 9 && func_name.substr(0, 9) == "_builtin_") {
            op = LIR_Op::CallBuiltin;
            if (LIR::BuiltinUtils::isBuiltinFunction(func_name)) {
                vm_name = func_name;
            } else {
                vm_name = func_name.substr(9);
            }
            is_builtin = true;
        }
        
        if (is_builtin) {
            LIR_Inst inst;
            inst.op = op; inst.dst = result; inst.func_name = vm_name; inst.call_args = arg_regs;
            inst.result_type = (expr.inferred_type) ? language_type_to_abi_type(expr.inferred_type) : Type::I64;
            if (expr.inferred_type) set_register_type(result, expr.inferred_type);
            for (size_t i = 0; i < arg_regs.size(); ++i) {
                Type arg_abi = Type::I64;
                if (expr.arguments[i] && expr.arguments[i]->inferred_type) {
                    arg_abi = language_type_to_abi_type(expr.arguments[i]->inferred_type);
                } else if (auto lang_type = get_register_language_type(arg_regs[i])) {
                    arg_abi = language_type_to_abi_type(lang_type);
                } else {
                    arg_abi = get_register_abi_type(arg_regs[i]);
                }
                inst.call_arg_types.push_back(arg_abi);
            }
            emit_instruction(inst);
            return result;
        }

        // --- 3. Frame instantiation ---
        func_name = resolve_qualified_frame_name(func_name);
        auto frame_it = frame_table_.find(func_name);
        if (frame_it != frame_table_.end()) {
            // A type alias (`pub type Foo = sub.Foo;`) shares the underlying FrameInfo, whose
            // `name` is the canonical frame. Construction must run the canonical init().
            const std::string canonical_name = frame_it->second.name.empty() ? func_name : frame_it->second.name;
            LIR_Inst new_inst(LIR_Op::NewFrame, Type::Ptr, result, 0, 0, (uint32_t)frame_it->second.total_field_size);
            new_inst.type_name = canonical_name;
            emit_instruction(new_inst);
            set_register_type(result, expr.inferred_type);
            set_register_language_type(result, expr.inferred_type);
            
            if (!scope_stack_.empty() && frame_it->second.has_deinit) {
                scope_stack_.back().frame_instances.push_back({canonical_name, result});
            }
            
            const auto& frame_decl = frame_it->second.declaration;
            if (frame_decl) {
                for (size_t i = 0; i < frame_decl->fields.size(); ++i) {
                    const auto& field = frame_decl->fields[i];
                    if (field->defaultValue) {
                        Reg field_val_reg = emit_expr(*field->defaultValue);
                        emit_instruction(LIR_Inst(LIR_Op::FrameSetField, Type::Void, result, static_cast<uint32_t>(i), field_val_reg));
                    }
                }
            }
            
            if (frame_it->second.has_init) {
                std::vector<Reg> args;
                args.reserve(arg_regs.size() + 1);
                args.push_back(result);
                for (Reg r : arg_regs) args.push_back(r);

                std::vector<Type> arg_types;
                arg_types.reserve(args.size());
                arg_types.push_back(Type::Ptr);
                for (size_t i = 0; i < arg_regs.size(); ++i) {
                    Type arg_abi = Type::I64;
                    if (i < expr.arguments.size() && expr.arguments[i] && expr.arguments[i]->inferred_type) {
                        arg_abi = language_type_to_abi_type(expr.arguments[i]->inferred_type);
                    } else if (auto lang_type = get_register_language_type(arg_regs[i])) {
                        arg_abi = language_type_to_abi_type(lang_type);
                    } else {
                        arg_abi = get_register_abi_type(arg_regs[i]);
                    }
                    arg_types.push_back(arg_abi);
                }

                Reg dummy = allocate_register();
                emit_instruction(LIR_Inst(LIR_Op::Call, dummy, canonical_name + ".init", args, arg_types));
            } else {
                if (frame_decl) {
                    for (size_t i = 0; i < frame_decl->fields.size(); ++i) {
                        const auto& field = frame_decl->fields[i];
                        for (const auto& [arg_name, arg_expr] : expr.namedArgs) {
                            if (arg_name == field->name) {
                                Reg field_val_reg = emit_expr(*arg_expr);
                                emit_instruction(LIR_Inst(LIR_Op::FrameSetField, Type::Void, result, static_cast<uint32_t>(i), field_val_reg));
                                break;
                            }
                        }
                    }
                }
            }
            return result;
        }

        // --- 4. Normal function call ---
        if (!current_module_.empty() && current_module_ != "root" && func_name.find('.') == std::string::npos) {
            std::string qname = current_module_ + "." + func_name;
            if (function_table_.count(qname) || LIRFunctionManager::getInstance().hasFunction(qname)) vm_name = qname;
        }
        
        LIR_Inst inst(LIR_Op::Call, result, vm_name, arg_regs);
        inst.func_name = vm_name;
        for (size_t i = 0; i < arg_regs.size(); ++i) {
            inst.call_arg_types.push_back(expr.arguments[i] && expr.arguments[i]->inferred_type ? language_type_to_abi_type(expr.arguments[i]->inferred_type) : Type::I64);
        }
        if (expr.inferred_type) {
            inst.result_type = language_type_to_abi_type(expr.inferred_type);
            set_register_type(result, expr.inferred_type);
        }
        emit_instruction(inst);
        return result;
    } 
    
    // Member method call: obj.method()
    else if (auto member_expr = dynamic_cast<LM::Frontend::AST::MemberExpr*>(expr.callee.get())) {
        std::string method_name = member_expr->name;

        // Check if object is a module alias (direct or chained) or variable
        std::string obj_mod_path = get_expr_qualified_path(member_expr->object.get());
        auto alias_it = obj_mod_path.empty() ? import_aliases_.end() : import_aliases_.find(obj_mod_path);
        auto var_obj = dynamic_cast<LM::Frontend::AST::VariableExpr*>(member_expr->object.get());

        if (var_obj || alias_it != import_aliases_.end()) {
            if (var_obj) {
                // First check if this could be an enum variant construction (before module alias check)
            int64_t tag = 0;
            size_t expected_arity = 0;
            std::string qualified_variant = var_obj->name + "." + method_name;
            TypePtr enum_hint = member_expr->object->inferred_type;
            if ((!enum_hint || enum_hint->tag != TypeTag::Enum) && type_system_) {
                enum_hint = type_system_->getType(var_obj->name);
            }

            // Also check the inferred type of the entire member expression
            if (!enum_hint && expr.inferred_type && expr.inferred_type->tag == TypeTag::Enum) {
                enum_hint = expr.inferred_type;
            }

            // If the inferred type is an Enum, try to extract variant info from it
            bool is_enum_variant = false;
            if (enum_hint && enum_hint->tag == TypeTag::Enum) {
                if (auto* enum_info = std::get_if<EnumType>(&enum_hint->extra)) {
                    auto it = std::find(enum_info->values.begin(), enum_info->values.end(), method_name);
                    if (it != enum_info->values.end()) {
                        tag = static_cast<int64_t>(std::distance(enum_info->values.begin(), it));
                        auto arity_it = enum_info->variantTypes.find(*it);
                        expected_arity = (arity_it != enum_info->variantTypes.end()) ? arity_it->second.size() : 0;
                        is_enum_variant = true;
                    }
                }
            }

            // Also try the resolver as a fallback
            if (!is_enum_variant && resolve_enum_variant_info(type_system_.get(), enum_hint, qualified_variant, tag, expected_arity)) {
                is_enum_variant = true;
            }

            // If still not found, try to get the enum type directly from userDefinedTypes
            if (!is_enum_variant && type_system_) {
                TypePtr direct_enum_type = type_system_->getType(var_obj->name);
                if (direct_enum_type && direct_enum_type->tag == TypeTag::Enum) {
                    if (auto* enum_info = std::get_if<EnumType>(&direct_enum_type->extra)) {
                        auto it = std::find(enum_info->values.begin(), enum_info->values.end(), method_name);
                        if (it != enum_info->values.end()) {
                            tag = static_cast<int64_t>(std::distance(enum_info->values.begin(), it));
                            auto arity_it = enum_info->variantTypes.find(*it);
                            expected_arity = (arity_it != enum_info->variantTypes.end()) ? arity_it->second.size() : 0;
                            // If we have arguments but type system says arity 0, use argument count instead
                            if (expected_arity == 0 && !expr.arguments.empty()) {
                                expected_arity = expr.arguments.size();
                            }
                            is_enum_variant = true;
                        }
                    }
                }
            }

            // Fallback: if we have arguments and the variant name exists, treat it as enum variant
            if (!is_enum_variant && !expr.arguments.empty() && type_system_) {
                TypePtr direct_enum_type = type_system_->getType(var_obj->name);
                if (direct_enum_type && direct_enum_type->tag == TypeTag::Enum) {
                    if (auto* enum_info = std::get_if<EnumType>(&direct_enum_type->extra)) {
                        auto it = std::find(enum_info->values.begin(), enum_info->values.end(), method_name);
                        if (it != enum_info->values.end()) {
                            tag = static_cast<int64_t>(std::distance(enum_info->values.begin(), it));
                            expected_arity = expr.arguments.size(); // Use argument count as arity
                            is_enum_variant = true;
                        }
                    }
                }
            }

            if (is_enum_variant) {
                // This is an enum variant construction
                std::vector<Reg> arg_regs;
                arg_regs.reserve(expr.arguments.size());
                for (const auto& arg : expr.arguments) arg_regs.push_back(emit_argument(*arg, arg_regs.size()));
                Reg result = allocate_register();

                if (expected_arity == 0) {
                    // Unit variant
                    LIR_Inst inst(LIR_Op::MakeEnum, Type::Ptr, result, UINT32_MAX, 0, static_cast<uint32_t>(tag));
                    inst.imm = static_cast<uint32_t>(tag);
                    inst.func_name = method_name;
                    emit_instruction(inst);
                } else {
                    // Variant with associated values - create tuple payload
                    Reg payload = allocate_register();
                    // Optimization: for single-element variants, use the value directly as payload
                    if (arg_regs.size() == 1) {
                        payload = arg_regs[0];
                    } else {
                        LIR_Inst tuple_inst(LIR_Op::TupleCreate, Type::Ptr, payload);
                        tuple_inst.imm = static_cast<uint32_t>(arg_regs.size());
                        emit_instruction(tuple_inst);
                        for (size_t i = 0; i < arg_regs.size(); ++i) {
                            Reg idx_reg = allocate_register();
                            emit_instruction(LIR_Inst(LIR_Op::LoadConst, Type::I64, idx_reg, make_i64(static_cast<int64_t>(i))));
                            // TupleSet: dst = tuple, a = index, b = value
                            emit_instruction(LIR_Inst(LIR_Op::TupleSet, Type::Void, payload, idx_reg, arg_regs[i]));
                        }
                    }
                    // Create enum with payload
                    LIR_Inst inst(LIR_Op::MakeEnum, Type::Ptr, result, payload, 0, static_cast<uint32_t>(tag));
                    inst.imm = static_cast<uint32_t>(tag);
                    inst.func_name = method_name;
                    emit_instruction(inst);
                }

                if (expr.inferred_type) {
                    set_register_language_type(result, expr.inferred_type);
                    set_register_abi_type(result, Type::Ptr);
                }
                return result;
            }
            }

            // Then check for module alias
            if (alias_it != import_aliases_.end()) {
                std::string qualified_name = LM::Frontend::ModuleManager::getInstance().canonical_symbol(alias_it->second + "." + method_name);

                // Frame instantiation via module alias check
                auto frame_it = frame_table_.find(qualified_name);
                if (frame_it != frame_table_.end()) {
                    std::vector<Reg> arg_regs;
                    arg_regs.reserve(expr.arguments.size());
                    for (const auto& arg : expr.arguments) arg_regs.push_back(emit_argument(*arg, arg_regs.size()));
                    Reg result = allocate_register();
                    
                    const std::string canonical_name = frame_it->second.name.empty() ? qualified_name : frame_it->second.name;
                    LIR_Inst new_inst(LIR_Op::NewFrame, Type::Ptr, result, 0, 0, (uint32_t)frame_it->second.total_field_size);
                    new_inst.type_name = canonical_name;
                    emit_instruction(new_inst);
                    set_register_type(result, expr.inferred_type);
                    set_register_language_type(result, expr.inferred_type);
                    
                    if (!scope_stack_.empty() && frame_it->second.has_deinit) {
                        scope_stack_.back().frame_instances.push_back({canonical_name, result});
                    }
                    
                    const auto& frame_decl = frame_it->second.declaration;
                    if (frame_decl) {
                        for (size_t i = 0; i < frame_decl->fields.size(); ++i) {
                            const auto& field = frame_decl->fields[i];
                            if (field->defaultValue) {
                                Reg field_val_reg = emit_expr(*field->defaultValue);
                                emit_instruction(LIR_Inst(LIR_Op::FrameSetField, Type::Void, result, static_cast<uint32_t>(i), field_val_reg));
                            }
                        }
                    }
                    
                    if (frame_it->second.has_init) {
                        std::vector<Reg> args;
                        args.reserve(arg_regs.size() + 1);
                        args.push_back(result);
                        for (Reg r : arg_regs) args.push_back(r);
                        Reg dummy = allocate_register();
                        emit_instruction(LIR_Inst(LIR_Op::Call, dummy, canonical_name + ".init", args));
                    } else {
                        if (frame_decl) {
                            for (size_t i = 0; i < frame_decl->fields.size(); ++i) {
                                const auto& field = frame_decl->fields[i];
                                for (const auto& [arg_name, arg_expr] : expr.namedArgs) {
                                    if (arg_name == field->name) {
                                        Reg field_val_reg = emit_expr(*arg_expr);
                                        emit_instruction(LIR_Inst(LIR_Op::FrameSetField, Type::Void, result, static_cast<uint32_t>(i), field_val_reg));
                                        break;
                                    }
                                }
                            }
                        }
                    }
                    return result;
                }

                std::vector<Reg> arg_regs;
                arg_regs.reserve(expr.arguments.size());
                for (const auto& arg : expr.arguments) arg_regs.push_back(emit_argument(*arg, arg_regs.size()));
                Reg result = allocate_register();

                // ── Intrinsic check (mirrors the VariableExpr path at line 1323) ──
                if (auto intrinsic = IntrinsicRegistry::getInstance().getIntrinsic(qualified_name)) {
                    Type abi_res_type = (expr.inferred_type) ? language_type_to_abi_type(expr.inferred_type) : Type::Void;
                    if (expr.inferred_type) set_register_language_type(result, expr.inferred_type);
                    LIR_Inst inst(intrinsic->opcode, abi_res_type, result, 0, 0, 0);
                    inst.imm = intrinsic->type_id;
                    inst.func_name = qualified_name;
                    if (arg_regs.size() > 0) inst.a = arg_regs[0];
                    if (arg_regs.size() > 1) inst.b = arg_regs[1];
                    for (size_t k = 0; k < arg_regs.size(); ++k) inst.call_args.push_back(arg_regs[k]);
                    emit_instruction(inst);
                    return result;
                }

                std::string vm_name = qualified_name;
                LIR_Op op = LIR_Op::Call;
                if (qualified_name == "len" || qualified_name == "length" || qualified_name == "_builtin_len" ||
                    (qualified_name.length() >= 4 && qualified_name.substr(qualified_name.length()-4) == ".len") ||
                    (qualified_name.length() >= 7 && qualified_name.substr(qualified_name.length()-7) == ".length")) {
                    op = LIR_Op::CallBuiltin; vm_name = "len";
                } else if (qualified_name.length() >= 9 && qualified_name.substr(0, 9) == "_builtin_") {
                    op = LIR_Op::CallBuiltin;
                    if (LIR::BuiltinUtils::isBuiltinFunction(qualified_name)) {
                        vm_name = qualified_name;
                    } else {
                        vm_name = qualified_name.substr(9);
                    }
                }

                LIR_Inst inst;
                inst.op = op; inst.dst = result; inst.func_name = vm_name; inst.call_args = arg_regs;
                if (expr.inferred_type) {
                    inst.result_type = language_type_to_abi_type(expr.inferred_type);
                    set_register_type(result, expr.inferred_type);
                    set_register_language_type(result, expr.inferred_type);
                    set_register_abi_type(result, language_type_to_abi_type(expr.inferred_type));
                } else {
                    inst.result_type = Type::I64;
                }
                emit_instruction(inst);
                return result;
            }
        }

        Reg object_reg = emit_checked_dereference(*member_expr->object, emit_expr(*member_expr->object), argument_effect(0) == Memory::Ownership::WriteBorrow);
        std::vector<Reg> arg_regs;
        arg_regs.reserve(expr.arguments.size() + 1);
        arg_regs.push_back(object_reg);
        for (const auto& arg : expr.arguments) arg_regs.push_back(emit_argument(*arg, arg_regs.size()));
        
        Reg result = allocate_register();
        TypePtr object_type = member_expr->object->inferred_type;
        if (!object_type) {
            object_type = get_register_language_type(object_reg);
        }
        if (!object_type) {
            object_type = get_register_type(object_reg);
        }

        // Built-in methods
        if (object_type && (object_type->tag == TypeTag::List || object_type->tag == TypeTag::String)) {
            if (method_name == "append") {
                if (arg_regs.size() > 1) {
                    emit_instruction(LIR_Inst(LIR_Op::ListAppend, Type::Void, result, object_reg, arg_regs[1]));
                }
                return result;
            }
            if (method_name == "len" || method_name == "length") {
                LIR_Inst inst;
                inst.op = LIR_Op::CallBuiltin; inst.dst = result; inst.func_name = "len";
                inst.call_args.push_back(object_reg);
                inst.result_type = Type::I64;
                emit_instruction(inst);
                return result;
            }
        }
        
        if (object_type && object_type->tag == TypeTag::Channel) {
            LIR_Op op = LIR_Op::Call; 
            if (method_name == "send" || method_name == "push") op = LIR_Op::ChannelSend;
            else if (method_name == "recv" || method_name == "pop") op = LIR_Op::ChannelRecv;
            else if (method_name == "close") op = LIR_Op::ChannelClose;
            else if (method_name == "offer") op = LIR_Op::ChannelOffer;
            else if (method_name == "poll") op = LIR_Op::ChannelPoll;
            else if (method_name == "has_data") op = LIR_Op::ChannelHasData;
            
            if (op != LIR_Op::Call) {
                LIR_Inst call_inst;
                call_inst.op = op; 
                call_inst.dst = result;
                call_inst.a = object_reg;
                if (arg_regs.size() > 1) {
                    call_inst.b = arg_regs[1];
                } else {
                    call_inst.b = UINT32_MAX;
                }
                call_inst.call_args = arg_regs;
                call_inst.result_type = (expr.inferred_type ? language_type_to_abi_type(expr.inferred_type) : Type::I64);
                emit_instruction(call_inst);
                return result;
            }
        }

        TypePtr resolved_object_type = resolve_underlying_type(object_type);

        // Devirtualization: If receiver has a concrete frame type, call frame method directly
        if (resolved_object_type && resolved_object_type->tag == TypeTag::Frame) {
            auto ft = std::get_if<FrameType>(&resolved_object_type->extra);
            if (ft) {
                std::string resolved_frame_name = resolve_qualified_frame_name(ft->name);
                std::string concrete_method = find_frame_or_trait_method(resolved_frame_name, method_name);
                if (!concrete_method.empty()) {
                    if (expr.inferred_type) {
                        set_register_language_type(result, expr.inferred_type);
                        set_register_abi_type(result, language_type_to_abi_type(expr.inferred_type));
                    }
                    LIR_Inst inst(LIR_Op::Call, result, concrete_method, arg_regs);
                    inst.func_name = concrete_method;
                    for (size_t i = 0; i < arg_regs.size(); ++i) {
                        Type arg_abi = Type::I64;
                        if (i < expr.arguments.size() + 1) {
                            TypePtr arg_lang = (i == 0) ? object_type : expr.arguments[i - 1]->inferred_type;
                            if (arg_lang) arg_abi = language_type_to_abi_type(arg_lang);
                        }
                        inst.call_arg_types.push_back(arg_abi);
                    }
                    inst.result_type = (expr.inferred_type ? language_type_to_abi_type(expr.inferred_type) : Type::I64);
                    emit_instruction(inst);
                    return result;
                }
            }
        }

        // Trait or TraitObject method call (fallback for existential boxed trait objects)
        if (resolved_object_type && (resolved_object_type->tag == TypeTag::Trait || resolved_object_type->tag == TypeTag::TraitObject)) {
            std::string trait_name;
            if (resolved_object_type->tag == TypeTag::Trait) {
                if (auto tt = std::get_if<TraitType>(&resolved_object_type->extra)) {
                    trait_name = tt->name;
                }
            } else {
                if (auto tot = std::get_if<TraitObjectType>(&resolved_object_type->extra)) {
                    trait_name = tot->traitName;
                }
            }

            if (!trait_name.empty()) {
                if (expr.inferred_type) {
                    set_register_language_type(result, expr.inferred_type);
                    set_register_abi_type(result, language_type_to_abi_type(expr.inferred_type));
                }
                LIR_Inst inst(LIR_Op::TraitCallMethod, result, 0, 0);
                inst.result_type = (expr.inferred_type ? language_type_to_abi_type(expr.inferred_type) : Type::I64);
                inst.func_name = method_name;
                inst.type_name = trait_name;
                inst.call_args = arg_regs;
                emit_instruction(inst);
                return result;
            }
        }

        // Frame method call
        std::string full_name;
        if (resolved_object_type && resolved_object_type->tag == TypeTag::Frame) {
            auto ft = std::get_if<FrameType>(&resolved_object_type->extra);
            if (ft) {
                std::string resolved_frame_name = resolve_qualified_frame_name(ft->name);
                
                // Check if this is a field access (function pointer stored in a field)
                // rather than a method call
                std::string frame_method_name = find_frame_or_trait_method(resolved_frame_name, method_name);
                auto frame_it = frame_table_.find(resolved_frame_name);
                if (frame_method_name.empty() && frame_it != frame_table_.end() && frame_it->second.declaration) {
                    const auto& frame_decl = frame_it->second.declaration;
                    for (size_t i = 0; i < frame_decl->fields.size(); ++i) {
                        const auto& field = frame_decl->fields[i];
                        if (field->name == method_name) {
                            // This is a field, not a method
                            // Get the field value and use CallIndirect
                            Reg field_reg = allocate_register();
                            emit_instruction(LIR_Inst(LIR_Op::FrameGetField, Type::Ptr, field_reg, object_reg, static_cast<uint32_t>(i)));
                            
                            // Now call through the function pointer
                            std::vector<Reg> indirect_args;
                            indirect_args.reserve(expr.arguments.size());
                            for (const auto& arg : expr.arguments) {
                                indirect_args.push_back(emit_argument(*arg, indirect_args.size()));
                            }
                            
                            Type abi_type = Type::Void;
                            if (expr.inferred_type) {
                                abi_type = language_type_to_abi_type(expr.inferred_type);
                                set_register_language_type(result, expr.inferred_type);
                            }
                            
                            LIR_Inst call_inst(LIR_Op::CallIndirect, abi_type, result, field_reg, 0);
                            call_inst.call_args = indirect_args;
                            emit_instruction(call_inst);
                            return result;
                        }
                    }
                }
                
                full_name = find_frame_or_trait_method(resolved_frame_name, method_name);
                if (full_name.empty()) {
                    full_name = resolved_frame_name + "." + method_name;
                }
            }
        }

        if (!full_name.empty()) {
            LIR_Inst inst(LIR_Op::Call, result, full_name, arg_regs);
            inst.func_name = full_name;
            for (size_t i = 0; i < arg_regs.size(); ++i) {
                Type arg_abi = Type::I64;
                if (i > 0 && i - 1 < expr.arguments.size() && expr.arguments[i - 1] && expr.arguments[i - 1]->inferred_type) {
                    arg_abi = language_type_to_abi_type(expr.arguments[i - 1]->inferred_type);
                } else if (auto lang_type = get_register_language_type(arg_regs[i])) {
                    arg_abi = language_type_to_abi_type(lang_type);
                } else {
                    arg_abi = get_register_abi_type(arg_regs[i]);
                }
                inst.call_arg_types.push_back(arg_abi);
            }
            if (expr.inferred_type) {
                inst.result_type = language_type_to_abi_type(expr.inferred_type);
                set_register_type(result, expr.inferred_type);
                set_register_language_type(result, expr.inferred_type);
                set_register_abi_type(result, language_type_to_abi_type(expr.inferred_type));
            }
            emit_instruction(inst);
            return result;
        }

        report_error("Unresolved method: " + method_name);
        return 0;
    }

    // A callable expression (including a returned callable) uses the same
    // evaluated target and ownership events as a callable variable.
    Reg callable = emit_expr(*expr.callee);
    std::vector<Reg> arguments;
    for (const auto& argument : expr.arguments) arguments.push_back(emit_argument(*argument, arguments.size()));
    Reg result = allocate_register();
    Type result_type = expr.inferred_type ? language_type_to_abi_type(expr.inferred_type) : Type::Ptr;
    LIR_Inst call(LIR_Op::CallIndirect, result_type, result, callable, UINT32_MAX);
    call.call_args = arguments;
    emit_instruction(call);
    if (expr.inferred_type) {
        set_register_type(result, expr.inferred_type);
        set_register_language_type(result, expr.inferred_type);
    }
    return result;
}


Reg Generator::emit_assign_expr(LM::Frontend::AST::AssignExpr& expr) {
    Reg value = emit_expr(*expr.value);
    if (!expr.name.empty() && !expr.object && is_atomic_binding(expr)) {
        Reg cell = atomic_cell(expr.name);
        LIR_Op operation;
        if (expr.op == LM::Frontend::TokenType::EQUAL) operation = LIR_Op::FrameSetFieldAtomic;
        else if (expr.op == LM::Frontend::TokenType::PLUS_EQUAL) operation = LIR_Op::FrameFieldAtomicAdd;
        else if (expr.op == LM::Frontend::TokenType::MINUS_EQUAL) operation = LIR_Op::FrameFieldAtomicSub;
        else { report_error("Unsupported atomic compound assignment operator"); return value; }
        emit_instruction(LIR_Inst(operation, Type::Void, cell, 0, value));
        return atomic_read(cell);
    }


    // Ownership transfer: If we assign a frame instance to a field, 
    // it's no longer managed by the current scope.
    if (expr.object && expr.member) {
        // Find if 'value' corresponds to a frame instance in current scope
        Reg source_reg = value;

        // Follow Mov chains to find original allocation
        for (auto it = current_function_->instructions.rbegin(); it != current_function_->instructions.rend(); ++it) {
            if (it->op == LIR_Op::Mov && it->dst == source_reg) {
                source_reg = it->a;
            }
        }

        if (!scope_stack_.empty()) {
            auto& scope = scope_stack_.back();
            for (auto it = scope.frame_instances.begin(); it != scope.frame_instances.end(); ++it) {
                if (it->second == source_reg) {
                    // Transfer ownership to the object field
                    scope.frame_instances.erase(it);
                    // Emit RegionMove to transfer ownership to container's region
                    if (!generator_region_stack_.empty()) {
                        uint32_t target_region = generator_region_stack_.back();
                        emit_instruction(LIR_Inst(LIR_Op::RegionMove, Type::Void, value, target_region, 0));
                    }
                    break;
                }
            }
        }
    }
    
    // For assignments to captured variables inside a closure, write through the
    // closure environment tuple so subsequent reads and calls observe the update.
    if (!expr.name.empty() && env_register_ != UINT32_MAX) {
        auto captured_it = std::find(current_lambda_captures_.begin(), current_lambda_captures_.end(), expr.name);
        if (captured_it != current_lambda_captures_.end()) {
            size_t captured_index = std::distance(current_lambda_captures_.begin(), captured_it);
            Reg idx_reg = allocate_register();
            emit_instruction(LIR_Inst(LIR_Op::LoadConst, Type::I64, idx_reg, make_i64(static_cast<int64_t>(captured_index + 1))));
            emit_instruction(LIR_Inst(LIR_Op::TupleSet, Type::Void, env_register_, idx_reg, value));
            return value;
        }
    }

    // For simple variable assignment
    if (!expr.name.empty()) {
        // Get the existing register for this variable
        Reg dst = resolve_variable(expr.name);
        if (dst == UINT32_MAX) {
            // Variable doesn't exist, allocate a new one
            dst = allocate_register();
            bind_variable(expr.name, dst);
        }
        
        // Handle compound assignment operators
        if (expr.op != LM::Frontend::TokenType::EQUAL) {
            // For compound assignment (+=, -=, *=, /=, %=), we need to:
            // 1. Load current value
            // 2. Perform operation with new value
            // 3. Store result back
            
            // Convert the TypePtr to ABI Type for the instruction
            Type abi_type = language_type_to_abi_type(expr.inferred_type);
            
            // Check if this should be string concatenation instead of arithmetic
            if (expr.op == LM::Frontend::TokenType::PLUS_EQUAL) {
                // Get the type of the left operand (current variable value)
                TypePtr dst_type = get_register_type(dst);
                if (dst_type && dst_type->tag == TypeTag::String) {
                    // String += something -> use string concatenation
                    auto string_type = std::make_shared<::Type>(::TypeTag::String);
                    emit_instruction(LIR_Inst(LIR_Op::STR_CONCAT, Type::Ptr, dst, dst, value));
                    set_register_type(dst, string_type);
                    return dst;
                }
            }
            
            switch (expr.op) {
                case LM::Frontend::TokenType::PLUS_EQUAL:
                    emit_instruction(LIR_Inst(LIR_Op::Add, abi_type, dst, dst, value));
                    break;
                case LM::Frontend::TokenType::MINUS_EQUAL:
                    emit_instruction(LIR_Inst(LIR_Op::Sub, abi_type, dst, dst, value));
                    break;
                case LM::Frontend::TokenType::STAR_EQUAL:
                    emit_instruction(LIR_Inst(LIR_Op::Mul, abi_type, dst, dst, value));
                    break;
                case LM::Frontend::TokenType::SLASH_EQUAL:
                    emit_instruction(LIR_Inst(LIR_Op::Div, abi_type, dst, dst, value));
                    break;
                case LM::Frontend::TokenType::MODULUS_EQUAL:
                    emit_instruction(LIR_Inst(LIR_Op::Mod, abi_type, dst, dst, value));
                    break;
                default:
                    report_error("Unsupported compound assignment operator");
                    return 0;
            }
        } else {
            // Simple assignment - just move the value
            // Set type BEFORE emitting so it's available during emit_instruction
            set_register_type(dst, get_register_type(value));
            
            // Convert the TypePtr to ABI Type for the instruction
            Type abi_type = language_type_to_abi_type(expr.inferred_type);
            
            emit_instruction(LIR_Inst(LIR_Op::Mov, abi_type, dst, value, 0));
        }
        // No need to update binding since we're using the existing register
        return dst;
    } else if (expr.object) {
        // For member or index assignment
        if (expr.member.has_value()) {
            // Field assignment: obj.field = value
            Reg object_reg = emit_checked_dereference(*expr.object, emit_expr(*expr.object), true);
            std::string field_name = expr.member.value();
            
            // Get the type of the object to find the correct frame
            TypePtr object_type = expr.object->inferred_type;
            TypePtr resolved_object_type = resolve_underlying_type(object_type);
            if (resolved_object_type && resolved_object_type->tag == TypeTag::Frame) {
                auto frame_type_info = std::get_if<FrameType>(&resolved_object_type->extra);
                if (frame_type_info) {
                    std::string resolved_name = resolve_qualified_frame_name(frame_type_info->name);
                    auto it = frame_table_.find(resolved_name);
                    if (it != frame_table_.end()) {
                        // Check visibility
                        auto vis_it = it->second.field_visibilities.find(field_name);
                        if (vis_it != it->second.field_visibilities.end()) {
                            if (!is_visible(vis_it->second, resolved_name)) {
                                report_error("Cannot access " + LM::Frontend::AST::visibilityToString(vis_it->second) +
                                           " field '" + field_name + "' of frame '" + resolved_name + "'");
                                return 0;
                            }
                        }

                        auto offset_it = it->second.field_offsets.find(field_name);
                        if (offset_it != it->second.field_offsets.end()) {
                            // Found the field - emit FrameSetField
                            LIR_Op set_op = LIR_Op::FrameSetField;
                            if (is_in_concurrency_context()) {
                                if (expr.op == LM::Frontend::TokenType::EQUAL) {
                                    set_op = LIR_Op::FrameSetFieldAtomic;
                                } else if (expr.op == LM::Frontend::TokenType::PLUS_EQUAL) {
                                    set_op = LIR_Op::FrameFieldAtomicAdd;
                                } else if (expr.op == LM::Frontend::TokenType::MINUS_EQUAL) {
                                    set_op = LIR_Op::FrameFieldAtomicSub;
                                }
                            }

                            emit_instruction(LIR_Inst(set_op, Type::Void, object_reg, static_cast<uint32_t>(offset_it->second), value));
                            return value;
                        }
                    }
                }
            } else {
                // Fallback: search all frames
                for (const auto& [frame_name, frame_info] : frame_table_) {
                    auto offset_it = frame_info.field_offsets.find(field_name);
                    if (offset_it != frame_info.field_offsets.end()) {
                        // Found the field - emit FrameSetField
                        emit_instruction(LIR_Inst(LIR_Op::FrameSetField, Type::Void, object_reg, static_cast<uint32_t>(offset_it->second), value));
                        return value;
                    }
                }
            }
            
            report_error("Unknown field for assignment: " + field_name);
            return 0;
        } else {
            // Index assignment - handle dict/list/tuple element assignment
            Reg object_reg = emit_checked_dereference(*expr.object, emit_expr(*expr.object), true);
            Reg index_reg = emit_expr(*expr.index);
            
            TypePtr object_type = get_register_language_type(object_reg);
            if (!object_type && expr.object && expr.object->inferred_type) {
                object_type = expr.object->inferred_type;
            }

            if (object_type && object_type->tag == ::TypeTag::List) {
                emit_instruction(LIR_Inst(LIR_Op::ListSet, Type::Void, object_reg, index_reg, value));
            } else {
                // Use DictSet operation for dictionary assignment
                Reg result = allocate_register();
                emit_instruction(LIR_Inst(LIR_Op::DictSet, Type::Ptr, object_reg, index_reg, value));
                set_register_type(result, std::make_shared<::Type>(::TypeTag::Nil)); // Void return
            }
            return value;
        }
    } else {
        report_error("Invalid assignment target");
        return 0;
    }
}


Reg Generator::emit_call_closure_expr(LM::Frontend::AST::CallClosureExpr& expr) {
    // Handle closure calls - calling a function stored in a variable
    // This enables first-order functions and closures
    
    // Evaluate the closure expression
    Reg closure_reg = emit_expr(*expr.closure);
    
    // Evaluate all positional arguments
    std::vector<Reg> arg_regs;
    arg_regs.reserve(expr.arguments.size());
    for (const auto& arg : expr.arguments) {
        Reg arg_reg = emit_expr(*arg);
        arg_regs.push_back(arg_reg);
    }
    
    // Handle named arguments
    std::unordered_map<std::string, Reg> named_arg_regs;
    for (const auto& [name, arg] : expr.namedArgs) {
        Reg arg_reg = emit_expr(*arg);
        named_arg_regs[name] = arg_reg;
    }
    
    // Create a result register
    Reg result = allocate_register();
    
    // Emit closure call instruction
    Type abi_type = Type::Void;
    if (expr.inferred_type) {
        abi_type = language_type_to_abi_type(expr.inferred_type);
    }

    LIR_Inst call_inst(LIR_Op::CallIndirect, abi_type, result, closure_reg, 0);
    call_inst.call_args = arg_regs;
    emit_instruction(call_inst);
    
    // Set return type based on inference
    if (expr.inferred_type) {
        set_register_type(result, expr.inferred_type);
    } else {
        set_register_type(result, std::make_shared<::Type>(::TypeTag::Int));
    }
    
    return result;
}


Reg Generator::emit_list_expr(LM::Frontend::AST::ListExpr& expr) {
    // Create a new list using ListCreate operation
    Reg list_reg = allocate_register();
    Type abi_type = language_type_to_abi_type(expr.inferred_type);
    
    // Emit ListCreate instruction
    emit_instruction(LIR_Inst(LIR_Op::ListCreate, abi_type, list_reg, 0, 0));
    set_register_type(list_reg, expr.inferred_type);
    set_register_language_type(list_reg, expr.inferred_type);
    
    // Append elements to the list
    for (const auto& element : expr.elements) {
        Reg element_reg = emit_expr(*element);
        Reg temp = allocate_register();
        emit_instruction(LIR_Inst(LIR_Op::ListAppend, Type::Void, temp, list_reg, element_reg));
    }
    
    return list_reg;
}


Reg Generator::emit_grouping_expr(LM::Frontend::AST::GroupingExpr& expr) {
    return emit_expr(*expr.expression);
}


// Nullable references may be compared or copied, but dereferencing one must
// execute the strict validity obligation. Proven-local objects have no handle.
Reg Generator::emit_checked_dereference(LM::Frontend::AST::Expression& object, Reg value, bool writable, bool nullable) {
    if (!ownership_facts_) return value;
    auto fact = ownership_facts_->nodes.find(object.memory_info.semantic_id);
    if (fact == ownership_facts_->nodes.end()) return value;
    auto handle = checked_references_.find(fact->second.binding);
    if (handle == checked_references_.end()) return value;
    auto resolved = allocate_register();
    emit_instruction(LIR_Inst(LIR_Op::RefResolve, Type::Ptr, resolved, handle->second, UINT32_MAX,
                             (writable ? Memory::ReferenceWritable : 0) | (nullable ? Memory::ReferenceNullable : 0)));
    if (object.inferred_type) set_register_language_type(resolved, object.inferred_type);
    return resolved;
}

Reg Generator::emit_index_expr(LM::Frontend::AST::IndexExpr& expr) {
    // Evaluate the object (list/dict/tuple/string)
    Reg object_reg = emit_checked_dereference(*expr.object, emit_expr(*expr.object));
    
    // Evaluate the index
    Reg index_reg = emit_expr(*expr.index);
    
    // Determine result type
    TypePtr result_type = nullptr;
    if (expr.inferred_type) {
        result_type = expr.inferred_type;
    } else {
        // Default to any type if not inferred
        result_type = std::make_shared<::Type>(::TypeTag::Any);
    }
    
    // Check the object type to use the appropriate operation
    TypePtr object_type = get_register_language_type(object_reg);
    if (!object_type && expr.object && expr.object->inferred_type) {
        object_type = expr.object->inferred_type;
    }
    if (object_type && (object_type->tag == ::TypeTag::Tuple || object_type->tag == ::TypeTag::Frame)) {
        // Use TupleGet for tuples
        Reg result_reg = allocate_register();
        Type abi_type = language_type_to_abi_type(result_type);
        emit_instruction(LIR_Inst(LIR_Op::TupleGet, abi_type, result_reg, object_reg, index_reg));
        set_register_type(result_reg, result_type);
        set_register_language_type(result_reg, result_type);
        return result_reg;
    } else if (object_type && object_type->tag == ::TypeTag::Dict) {
        // Use DictGet for dictionaries
        Reg result_reg = allocate_register();
        Type abi_type = language_type_to_abi_type(result_type);
        emit_instruction(LIR_Inst(LIR_Op::DictGet, abi_type, result_reg, object_reg, index_reg));
        set_register_type(result_reg, result_type);
        set_register_language_type(result_reg, result_type);  // Ensure language type is set
        return result_reg;
    } else if (object_type && object_type->tag == ::TypeTag::String) {
        // Use StringIndex for strings
        Reg result_reg = allocate_register();
        Type abi_type = language_type_to_abi_type(result_type);
        emit_instruction(LIR_Inst(LIR_Op::StringIndex, abi_type, result_reg, object_reg, index_reg));
        set_register_type(result_reg, result_type);
        set_register_language_type(result_reg, result_type);  // Ensure language type is set
        return result_reg;
    } else {
        // Use ListIndex for lists and other types
        Reg result_reg = allocate_register();
        Type abi_type = language_type_to_abi_type(result_type);
        emit_instruction(LIR_Inst(LIR_Op::ListIndex, abi_type, result_reg, object_reg, index_reg));
        set_register_type(result_reg, result_type);
        set_register_language_type(result_reg, result_type);  // Ensure language type is set
        return result_reg;
    }
}


Reg Generator::emit_member_expr(LM::Frontend::AST::MemberExpr& expr) {
    if (!current_function_) {
        report_error("Cannot emit member expression outside of a function context");
        return 0;
    }

    // Enum unit variant access: EnumName.Variant
    if (auto enum_obj = dynamic_cast<LM::Frontend::AST::VariableExpr*>(expr.object.get())) {
        int64_t tag = 0;
        size_t expected_arity = 0;
        std::string qualified_variant = enum_obj->name + "." + expr.name;
        TypePtr enum_hint = expr.object->inferred_type;
        if ((!enum_hint || enum_hint->tag != TypeTag::Enum) && type_system_) {
            enum_hint = type_system_->getType(enum_obj->name);
        }

        if (resolve_enum_variant_info(type_system_.get(), enum_hint, qualified_variant, tag, expected_arity) && expected_arity == 0) {
            Reg result = allocate_register();
            LIR_Inst inst(LIR_Op::MakeEnum, Type::Ptr, result, UINT32_MAX, 0, static_cast<uint32_t>(tag));
            inst.imm = static_cast<uint32_t>(tag);
            inst.func_name = expr.name;
            emit_instruction(inst);
            if (expr.inferred_type) {
                set_register_language_type(result, expr.inferred_type);
                set_register_abi_type(result, Type::Ptr);
            }
            return result;
        }
    }

    // Check if it's a module alias access (e.g. math.version or ui.animation.EASE_OUT)
    std::string obj_mod_path = get_expr_qualified_path(expr.object.get());
    if (!obj_mod_path.empty()) {
        auto alias_it = import_aliases_.find(obj_mod_path);
        if (alias_it != import_aliases_.end()) {
            std::string module_path = alias_it->second;
            std::string qualified_name = module_path + "." + expr.name;

            Reg result = allocate_register();
            LIR_Inst load_inst(LIR_Op::LoadGlobal, Type::Ptr, result, 0, 0);
            load_inst.func_name = qualified_name;
            emit_instruction(load_inst);

            if (expr.inferred_type) {
                set_register_language_type(result, expr.inferred_type);
                set_register_abi_type(result, language_type_to_abi_type(expr.inferred_type));
            } else {
                auto any_type = std::make_shared<::Type>(::TypeTag::Any);
                set_register_language_type(result, any_type);
                set_register_abi_type(result, language_type_to_abi_type(any_type));
            }
            return result;
        }
    }

    if (expr.isSafeAccess) {
        Reg object_reg = emit_expr(*expr.object);
        Reg is_nil_reg = allocate_register();
        Reg is_error_reg = allocate_register();
        Reg is_null_or_err = allocate_register();

        Reg nil_reg = allocate_register();
        auto nil_type = std::make_shared<::Type>(::TypeTag::Nil);
        Backend::Value nil_val = VAL_NIL;
        emit_instruction(LIR_Inst(LIR_Op::LoadConst, Type::Ptr, nil_reg, nil_val));
        set_register_type(nil_reg, nil_type);

        emit_instruction(LIR_Inst(LIR_Op::CmpEQ, LIR::Type::Bool, is_nil_reg, object_reg, nil_reg));
        emit_instruction(LIR_Inst(LIR_Op::IsError, LIR::Type::Bool, is_error_reg, object_reg, 0));
        emit_instruction(LIR_Inst(LIR_Op::Or, LIR::Type::Bool, is_null_or_err, is_nil_reg, is_error_reg));

        if (cfg_context_.building_cfg) {
            LIR_BasicBlock* null_block = create_basic_block("safe_access_null");
            LIR_BasicBlock* valid_block = create_basic_block("safe_access_valid");
            LIR_BasicBlock* merge_block = create_basic_block("safe_access_merge");

            Reg result_reg = allocate_register();

            emit_instruction(LIR_Inst(LIR_Op::JumpIf, Type::Void, 0, is_null_or_err, 0, null_block->id));
            emit_instruction(LIR_Inst(LIR_Op::Jump, Type::Void, 0, 0, 0, valid_block->id));
            add_block_edge(get_current_block(), null_block);
            add_block_edge(get_current_block(), valid_block);

            // Valid path
            set_current_block(valid_block);
            Reg target_obj = object_reg;
            TypePtr obj_type = expr.object->inferred_type;
            if (obj_type && obj_type->tag == ::TypeTag::ErrorUnion) {
                target_obj = allocate_register();
                TypePtr success_type = type_system_->ANY_TYPE;
                if (auto* eu = std::get_if<ErrorUnionType>(&obj_type->extra)) {
                    if (eu->successType) success_type = eu->successType;
                }
                set_register_type(target_obj, success_type);
                emit_instruction(LIR_Inst(LIR_Op::Unwrap, language_type_to_abi_type(success_type), target_obj, object_reg, 0));
            }

            LM::Frontend::AST::MemberExpr non_safe_expr = expr;
            non_safe_expr.isSafeAccess = false;
            Reg member_val = emit_member_access_with_obj(non_safe_expr, target_obj);

            emit_instruction(LIR_Inst(LIR_Op::ConstructOk, Type::Ptr, result_reg, member_val, 0));
            emit_instruction(LIR_Inst(LIR_Op::Jump, Type::Void, 0, 0, 0, merge_block->id));
            add_block_edge(valid_block, merge_block);

            // Null path
            set_current_block(null_block);
            emit_instruction(LIR_Inst(LIR_Op::ConstructError, Type::Ptr, result_reg, UINT32_MAX, 0));
            emit_instruction(LIR_Inst(LIR_Op::Jump, Type::Void, 0, 0, 0, merge_block->id));
            add_block_edge(null_block, merge_block);

            set_current_block(merge_block);
            TypePtr res_type = expr.inferred_type ? expr.inferred_type : std::make_shared<::Type>(::TypeTag::ErrorUnion);
            set_register_type(result_reg, res_type);
            set_register_language_type(result_reg, res_type);
            set_register_abi_type(result_reg, language_type_to_abi_type(res_type));
            return result_reg;
        }
    }

    Reg object_reg = emit_checked_dereference(*expr.object, emit_expr(*expr.object));
    return emit_member_access_with_obj(expr, object_reg);
}

Reg Generator::emit_member_access_with_obj(LM::Frontend::AST::MemberExpr& expr, Reg object_reg) {
    if (!current_function_) {
        report_error("Cannot emit member expression outside of a function context");
        return 0;
    }
    if (auto enum_obj = dynamic_cast<LM::Frontend::AST::VariableExpr*>(expr.object.get())) {
        int64_t tag = 0;
        size_t expected_arity = 0;
        std::string qualified_variant = enum_obj->name + "." + expr.name;
        TypePtr enum_hint = expr.object->inferred_type;
        if ((!enum_hint || enum_hint->tag != TypeTag::Enum) && type_system_) {
            enum_hint = type_system_->getType(enum_obj->name);
        }

        if (resolve_enum_variant_info(type_system_.get(), enum_hint, qualified_variant, tag, expected_arity) && expected_arity == 0) {
            Reg result = allocate_register();
            LIR_Inst inst(LIR_Op::MakeEnum, Type::Ptr, result, UINT32_MAX, 0, static_cast<uint32_t>(tag));
            inst.imm = static_cast<uint32_t>(tag);
            inst.func_name = expr.name;
            emit_instruction(inst);
            if (expr.inferred_type) {
                set_register_language_type(result, expr.inferred_type);
                set_register_abi_type(result, Type::Ptr);
            }
            return result;
        }
    }

    // Check if it's a module alias access (e.g. math.version or ui.animation.EASE_OUT)
    std::string obj_mod_path = get_expr_qualified_path(expr.object.get());
    if (!obj_mod_path.empty()) {
        auto alias_it = import_aliases_.find(obj_mod_path);
        if (alias_it != import_aliases_.end()) {
            std::string module_path = alias_it->second;
            std::string qualified_name = module_path + "." + expr.name;

            Reg result = allocate_register();
            LIR_Inst load_inst(LIR_Op::LoadGlobal, Type::Ptr, result, 0, 0);
            load_inst.func_name = qualified_name;
            emit_instruction(load_inst);

            if (expr.inferred_type) {
                set_register_language_type(result, expr.inferred_type);
                set_register_abi_type(result, language_type_to_abi_type(expr.inferred_type));
            } else {
                auto any_type = std::make_shared<::Type>(::TypeTag::Any);
                set_register_language_type(result, any_type);
                set_register_abi_type(result, language_type_to_abi_type(any_type));
            }
            return result;
        }
    }

    // Check for built-in list methods
    if (expr.name == "append") {
        // Return a special marker for append method
        Reg method_marker = allocate_register();
        auto int_type = std::make_shared<::Type>(::TypeTag::Int);
        emit_instruction(LIR_Inst(LIR_Op::LoadConst, Type::I64, method_marker, 
                                make_i64(1))); // Append marker
        set_register_type(method_marker, int_type);
        return method_marker;
    }
    
    if (expr.name == "len" || expr.name == "length") {
        // Return a special marker for len method
        Reg method_marker = allocate_register();
        auto int_type = std::make_shared<::Type>(::TypeTag::Int);
        emit_instruction(LIR_Inst(LIR_Op::LoadConst, Type::I64, method_marker, 
                                make_i64(2))); // Len marker
        set_register_type(method_marker, int_type);
        return method_marker;
    }
    
    // Check for tuple field access (key, value)
    TypePtr object_lang_type = get_register_language_type(object_reg);
    bool is_tuple = object_lang_type && object_lang_type->tag == ::TypeTag::Tuple;

    if (is_tuple && expr.name == "key") {
        // Access first element of tuple (index 0)
        Reg index_reg = allocate_register();
        auto int_type = std::make_shared<::Type>(::TypeTag::Int64);
        Backend::Value zero_val = make_i64(0);
        emit_instruction(LIR_Inst(LIR_Op::LoadConst, Type::I64, index_reg, zero_val));
        set_register_type(index_reg, int_type);
        
        Reg result_reg = allocate_register();
        emit_instruction(LIR_Inst(LIR_Op::TupleGet, Type::Ptr, result_reg, object_reg, index_reg));
        set_register_type(result_reg, std::make_shared<::Type>(::TypeTag::String));
        return result_reg;
    }
    
    if (is_tuple && expr.name == "value") {
        // Access second element of tuple (index 1)
        Reg index_reg = allocate_register();
        auto int_type = std::make_shared<::Type>(::TypeTag::Int64);
        Backend::Value one_val = make_i64(1);
       // std::cout << "[DEBUG] Emitting Dict value: "<< std::endl;
        emit_instruction(LIR_Inst(LIR_Op::LoadConst, Type::I64, index_reg, one_val));
        set_register_type(index_reg, int_type);
        
        Reg result_reg = allocate_register();
        emit_instruction(LIR_Inst(LIR_Op::TupleGet, Type::I64, result_reg, object_reg, index_reg));
        set_register_type(result_reg, int_type);
        return result_reg;
    }
    
    // Get the type of the object to find the correct frame
    TypePtr object_type = expr.object->inferred_type;
    TypePtr resolved_object_type = resolve_underlying_type(object_type);
    if (resolved_object_type && resolved_object_type->tag == TypeTag::Frame) {
        auto frame_type_info = std::get_if<FrameType>(&resolved_object_type->extra);
        if (frame_type_info) {
            std::string resolved_name = resolve_qualified_frame_name(frame_type_info->name);
            auto it = frame_table_.find(resolved_name);
            if (it != frame_table_.end()) {
                // Check visibility
                auto vis_it = it->second.field_visibilities.find(expr.name);
                if (vis_it != it->second.field_visibilities.end()) {
                    if (!is_visible(vis_it->second, resolved_name)) {
                        report_error("Cannot access " + LM::Frontend::AST::visibilityToString(vis_it->second) +
                                   " field '" + expr.name + "' of frame '" + resolved_name + "'");
                        return 0;
                    }
                }

                auto offset_it = it->second.field_offsets.find(expr.name);
                if (offset_it != it->second.field_offsets.end()) {
                    // Found the field - emit FrameGetField
                    Reg dst = allocate_register();

                    TypePtr field_lang_type = it->second.fields[offset_it->second].second;
                    Type field_abi_type = language_type_to_abi_type(field_lang_type);

                    // Check if we are in a parallel block and need atomic access
                    LIR_Op get_op = LIR_Op::FrameGetField;
                    if (is_in_concurrency_context()) {
                        get_op = LIR_Op::FrameGetFieldAtomic;
                    }

                    emit_instruction(LIR_Inst(get_op, field_abi_type, dst, object_reg, static_cast<uint32_t>(offset_it->second)));

                    // Set field type
                    if (offset_it->second < it->second.fields.size()) {
                        set_register_language_type(dst, field_lang_type);
                        set_register_abi_type(dst, field_abi_type);
                        set_register_type(dst, field_lang_type);
                    }

                    return dst;
                }
            }
        }
    } else {
        // Fallback: search all frames
        for (const auto& [frame_name, frame_info] : frame_table_) {
            auto offset_it = frame_info.field_offsets.find(expr.name);
            if (offset_it != frame_info.field_offsets.end()) {
                // Found the field - emit FrameGetField
                Reg dst = allocate_register();
                TypePtr field_lang_type = frame_info.fields[offset_it->second].second;
                Type field_abi_type = language_type_to_abi_type(field_lang_type);
                emit_instruction(LIR_Inst(LIR_Op::FrameGetField, field_abi_type, dst, object_reg, static_cast<uint32_t>(offset_it->second)));

                // Set field type
                if (offset_it->second < frame_info.fields.size()) {
                    set_register_language_type(dst, field_lang_type);
                    set_register_abi_type(dst, field_abi_type);
                    set_register_type(dst, field_lang_type);
                }

                return dst;
            }
        }
    }
    
    // If we get here, it's either a method call or unknown field
    // Check for special channel methods
    if (expr.name == "send") {
        // For channel.send(value), we need to return a special marker that this is a method call
        // The actual call will be handled in emit_call_expr
        Reg method_marker = allocate_register();
        auto int_type = std::make_shared<::Type>(::TypeTag::Int);
        emit_instruction(LIR_Inst(LIR_Op::LoadConst, Type::I64, method_marker, 
                                make_i64(-1))); // Special marker
        set_register_type(method_marker, int_type);
        return method_marker;
    }
    
    // For now, we'll treat it as an error
    report_error("Unknown field or method: " + expr.name);
    return 0;
}


Reg Generator::emit_tuple_expr(LM::Frontend::AST::TupleExpr& expr) {
    // Create a new tuple using TupleCreate operation
    Reg tuple_reg = allocate_register();
    Type abi_type = language_type_to_abi_type(expr.inferred_type);
    
    // Emit TupleCreate instruction with the correct size
    emit_instruction(LIR_Inst(LIR_Op::TupleCreate, abi_type, tuple_reg, 0, 0, static_cast<uint32_t>(expr.elements.size())));
    set_register_type(tuple_reg, expr.inferred_type);
    set_register_language_type(tuple_reg, expr.inferred_type);
    
    // Use TupleSet to add elements to the tuple
    for (size_t i = 0; i < expr.elements.size(); i++) {
        Reg element_reg = emit_expr(*expr.elements[i]);
        Reg index_reg = allocate_register();
        auto int_type = std::make_shared<::Type>(::TypeTag::Int64);
        Backend::Value index_val = make_i64(i);
        emit_instruction(LIR_Inst(LIR_Op::LoadConst, Type::I64, index_reg, index_val));
        set_register_type(index_reg, int_type);
        emit_instruction(LIR_Inst(LIR_Op::TupleSet, Type::Void, tuple_reg, index_reg, element_reg));
    }
    
    return tuple_reg;
}


Reg Generator::emit_dict_expr(LM::Frontend::AST::DictExpr& expr) {
    // Create a new dictionary using DictCreate operation
    Reg dict_reg = allocate_register();
    Type abi_type = language_type_to_abi_type(expr.inferred_type);
    
    // Emit DictCreate instruction with default int hash/compare functions
    emit_instruction(LIR_Inst(LIR_Op::DictCreate, abi_type, dict_reg, 0, 0));
    set_register_type(dict_reg, expr.inferred_type);
    set_register_language_type(dict_reg, expr.inferred_type);
    
    // Add key-value pairs to the dictionary
    for (const auto& [key_expr, value_expr] : expr.entries) {
        Reg key_reg = emit_expr(*key_expr);
        Reg value_reg = emit_expr(*value_expr);
        
        // Use DictSet operation to add each pair
        emit_instruction(LIR_Inst(LIR_Op::DictSet, abi_type, dict_reg, key_reg, value_reg));
    }
    
    return dict_reg;
}


Reg Generator::emit_range_expr(LM::Frontend::AST::RangeExpr& expr) {
    Reg start_reg = emit_expr(*expr.start);
    Reg end_reg = emit_expr(*expr.end);
    Reg step_reg;
    if (expr.step) {
        step_reg = emit_expr(*expr.step);
    } else {
        step_reg = allocate_register();
        auto int_type = std::make_shared<::Type>(::TypeTag::Int64);
        Backend::Value one_val = make_i64(1);
        emit_instruction(LIR_Inst(LIR_Op::LoadConst, Type::I64, step_reg, one_val));
        set_register_type(step_reg, int_type);
    }

    Reg range_tuple = allocate_register();
    Type abi_type = language_type_to_abi_type(expr.inferred_type);
    emit_instruction(LIR_Inst(LIR_Op::TupleCreate, abi_type, range_tuple, 0, 0, 3));

    Reg idx0 = allocate_register();
    Reg idx1 = allocate_register();
    Reg idx2 = allocate_register();
    auto int_type = std::make_shared<::Type>(::TypeTag::Int64);
    emit_instruction(LIR_Inst(LIR_Op::LoadConst, Type::I64, idx0, make_i64(0)));
    emit_instruction(LIR_Inst(LIR_Op::LoadConst, Type::I64, idx1, make_i64(1)));
    emit_instruction(LIR_Inst(LIR_Op::LoadConst, Type::I64, idx2, make_i64(2)));

    emit_instruction(LIR_Inst(LIR_Op::TupleSet, Type::Void, range_tuple, idx0, start_reg));
    emit_instruction(LIR_Inst(LIR_Op::TupleSet, Type::Void, range_tuple, idx1, end_reg));
    emit_instruction(LIR_Inst(LIR_Op::TupleSet, Type::Void, range_tuple, idx2, step_reg));

    set_register_type(range_tuple, expr.inferred_type ? expr.inferred_type : std::make_shared<::Type>(::TypeTag::Range));
    return range_tuple;
}


Reg Generator::emit_lambda_expr(LM::Frontend::AST::LambdaExpr& expr) {
    // Stable lexical names prevent collisions across separately compiled modules.
    std::string lambda_name = current_function_->name + ".__lambda_" + std::to_string(lambda_counter_++);
    
    auto fn_decl = std::make_shared<LM::Frontend::AST::FunctionDeclaration>();
    fn_decl->name = lambda_name;
    fn_decl->memory_info.semantic_id = expr.memory_info.semantic_id;
    fn_decl->params = expr.params;
    fn_decl->returnType = expr.returnType;
    fn_decl->body = expr.body;
    fn_decl->inferred_type = expr.inferred_type;

    std::vector<std::string> effective_captures = expr.capturedVars;
    if (expr.body) {
        std::set<std::string> used_names;
        std::vector<std::shared_ptr<LM::Frontend::AST::Statement>> lambda_body_statements;
        lambda_body_statements.push_back(expr.body);
        find_accessed_variables_recursive(lambda_body_statements, used_names);
        for (const auto& used_name : used_names) {
            bool is_param = false;
            for (const auto& param : expr.params) {
                if (param.first == used_name) { is_param = true; break; }
            }
            if (!is_param && resolve_variable(used_name) != UINT32_MAX &&
                std::find(effective_captures.begin(), effective_captures.end(), used_name) == effective_captures.end()) {
                effective_captures.push_back(used_name);
            }
        }
    }
    
    // Set captures for the new function's generation
    auto prev_captures = current_lambda_captures_;
    current_lambda_captures_ = effective_captures;
    
    generate_function(*fn_decl);
    
    current_lambda_captures_ = prev_captures;

    // Create the lambda/closure object
    Reg func_reg = allocate_register();
    auto string_type = std::make_shared<::Type>(::TypeTag::String);
    Backend::Value name_val = BOX_PTR(lm_str_from_cstr(lambda_name.c_str()));
    Reg name_reg = allocate_register();
    emit_instruction(LIR_Inst(LIR_Op::LoadConst, Type::Ptr, name_reg, name_val));

    if (effective_captures.empty()) {
        // Simple function pointer
        emit_instruction(LIR_Inst(LIR_Op::Mov, Type::Ptr, func_reg, name_reg, 0));
    } else {
        // Bundle into a Tuple: (lambda_name, capture1, capture2, ...)
        Reg closure_tuple = allocate_register();
        uint32_t tuple_size = static_cast<uint32_t>(effective_captures.size() + 1);
        emit_instruction(LIR_Inst(LIR_Op::TupleCreate, Type::Ptr, closure_tuple, 0, 0, tuple_size));
        
        // Set lambda name at index 0
        Reg zero_idx = allocate_register();
        emit_instruction(LIR_Inst(LIR_Op::LoadConst, Type::I64, zero_idx, make_i64(0)));
        emit_instruction(LIR_Inst(LIR_Op::TupleSet, Type::Void, closure_tuple, zero_idx, name_reg));

        // Set captured variables
        for (size_t i = 0; i < effective_captures.size(); ++i) {
            Reg val_reg = resolve_variable(effective_captures[i]);
            if (val_reg == UINT32_MAX) {
                // If not found in local scope, it might be in current lambda's env
                if (env_register_ != UINT32_MAX) {
                    auto it = std::find(current_lambda_captures_.begin(), current_lambda_captures_.end(), effective_captures[i]);
                    if (it != current_lambda_captures_.end()) {
                        size_t inner_idx = std::distance(current_lambda_captures_.begin(), it);
                        Reg inner_idx_reg = allocate_register();
                        emit_instruction(LIR_Inst(LIR_Op::LoadConst, Type::I64, inner_idx_reg, make_i64((int64_t)(inner_idx + 1))));
                        
                        val_reg = allocate_register();
                        emit_instruction(LIR_Inst(LIR_Op::TupleGet, Type::I64, val_reg, env_register_, inner_idx_reg));
                    }
                }
            }
            
            if (val_reg == UINT32_MAX) continue;

            Reg idx_reg = allocate_register();
            emit_instruction(LIR_Inst(LIR_Op::LoadConst, Type::I64, idx_reg, make_i64((int64_t)(i + 1))));
            emit_instruction(LIR_Inst(LIR_Op::TupleSet, Type::Void, closure_tuple, idx_reg, val_reg));
        }
        
        emit_instruction(LIR_Inst(LIR_Op::Mov, Type::Ptr, func_reg, closure_tuple, 0));
    }

    auto func_type = std::make_shared<::Type>(::TypeTag::Function);
    set_register_language_type(func_reg, func_type);
    set_register_abi_type(func_reg, Type::Ptr);
    
    return func_reg;
}

// Statement handlers

Reg Generator::emit_error_construct_expr(LM::Frontend::AST::ErrorConstructExpr& expr) {
    Reg dst = allocate_register();
    
    // For the unified Type? system, err() creates a generic error
    TypePtr result_type = expr.inferred_type ? expr.inferred_type : std::make_shared<::Type>(::TypeTag::ErrorUnion);
    set_register_type(dst, result_type);
    
    // Enhanced error construction with custom type and message
    std::string errorType = expr.errorType.empty() ? "DefaultError" : expr.errorType;
    std::string errorMessage = "Operation failed";
    
    // If there are arguments, the first one should be the error message
    if (!expr.arguments.empty()) {
        // Handle string literal messages
        if (auto literalExpr = std::dynamic_pointer_cast<LM::Frontend::AST::LiteralExpr>(expr.arguments[0])) {
            if (std::holds_alternative<std::string>(literalExpr->value)) {
                errorMessage = std::get<std::string>(literalExpr->value);
            }
        }
        // Support dynamic error messages from expressions
        Reg message_reg = emit_expr(*expr.arguments[0]);
        emit_instruction(LIR_Inst(LIR_Op::Param, message_reg, 0, 0));
    }
    
    // Create the instruction with error information in the comment
    LIR_Inst error_inst(LIR_Op::ConstructError, Type::Ptr, dst, 0, 0);
    error_inst.comment = "ERROR_INFO:" + errorType + ":" + errorMessage;
    emit_instruction(error_inst);
    
    return dst;
}


Reg Generator::emit_ok_construct_expr(LM::Frontend::AST::OkConstructExpr& expr) {
    Reg dst = allocate_register();
    
    // First evaluate the value to be wrapped
    Reg value_reg = emit_expr(*expr.value);
    
    // Create ok value using the unified system
    TypePtr result_type = expr.inferred_type ? expr.inferred_type : std::make_shared<::Type>(::TypeTag::ErrorUnion);
    set_register_type(dst, result_type);
    
    // Generate ConstructOk instruction with the actual value
    emit_instruction(LIR_Inst(LIR_Op::ConstructOk, Type::Ptr, dst, value_reg, 0));
    return dst;
}


Reg Generator::emit_fallible_expr(LM::Frontend::AST::FallibleExpr& expr) {
    // Evaluate the expression that may return a Result (Type?)
    Reg result_reg = emit_expr(*expr.expression);
    
    // Create a register to hold the error check result
    Reg is_error_reg = allocate_register();
    auto bool_type = std::make_shared<::Type>(::TypeTag::Bool);
    set_register_type(is_error_reg, bool_type);
    
    // Check if the result contains an error
    emit_instruction(LIR_Inst(LIR_Op::IsError, Type::Bool, is_error_reg, result_reg, 0));
    
    if (cfg_context_.building_cfg) {
        // CFG mode: create blocks for error handling
        LIR_BasicBlock* error_block = create_basic_block("error_handling");
        LIR_BasicBlock* success_block = create_basic_block("success_unwrap");
        LIR_BasicBlock* continue_block = create_basic_block("fallible_continue");
        
        // Create a register to hold the final result (either unwrapped value or else block result)
        Reg final_result_reg = allocate_register();
        
        // If it's an error, jump to error handling block
        emit_instruction(LIR_Inst(LIR_Op::JumpIf, Type::Void, 0, is_error_reg, 0, error_block->id));
        
        // Explicit jump to success block to ensure correct control flow
        emit_instruction(LIR_Inst(LIR_Op::Jump, Type::Void, 0, 0, 0, success_block->id));
        
        // Set up CFG edges
        add_block_edge(get_current_block(), error_block);
        add_block_edge(get_current_block(), success_block);
        
        // === Success Block: unwrap the value ===
        set_current_block(success_block);
        
        Reg unwrapped_reg = allocate_register();
        TypePtr fallible_type = get_register_type(result_reg);
        TypePtr success_type = type_system_->ANY_TYPE;
        if (fallible_type && fallible_type->tag == ::TypeTag::ErrorUnion) {
            if (auto* eu = std::get_if<ErrorUnionType>(&fallible_type->extra)) {
                if (eu->successType) success_type = eu->successType;
            }
        }
        set_register_type(unwrapped_reg, success_type);
        Type success_abi = language_type_to_abi_type(success_type);
        emit_instruction(LIR_Inst(LIR_Op::Unwrap, success_abi, unwrapped_reg, result_reg, 0));
        
        // Move unwrapped value to final result register
        emit_instruction(LIR_Inst(LIR_Op::Mov, success_abi, final_result_reg, unwrapped_reg, 0));
        
        // Jump to continue block
        emit_instruction(LIR_Inst(LIR_Op::Jump, Type::Void, 0, 0, 0, continue_block->id));
        add_block_edge(success_block, continue_block);
        
        // === Error Block: handle error ===
        set_current_block(error_block);
        
        if (expr.elseHandler) {
            // ? else {} construct - execute the else block instead of propagating          
            // Allocate register for the else block result
            Reg default_reg = allocate_register();
            
            // Set up else block context
            else_context_.in_else_block = true;
            else_context_.result_register = default_reg;
            
            // Execute the else block statements
            emit_stmt(*expr.elseHandler);
            
            // Clear else block context
            else_context_.in_else_block = false;
            else_context_.result_register = UINT32_MAX;
            
            // Move default value to final result register
            emit_instruction(LIR_Inst(LIR_Op::Mov, Type::I64, final_result_reg, default_reg, 0));
            
            // Jump to continue block
            emit_instruction(LIR_Inst(LIR_Op::Jump, Type::Void, 0, 0, 0, continue_block->id));
            add_block_edge(error_block, continue_block);
            
        } else {
            // Simple ? operator - propagate error by returning
            emit_instruction(LIR_Inst(LIR_Op::Return, Type::Void, result_reg, 0, 0));
            // No edge to continue block since we return
        }
        
        // === Continue Block: merge point for both paths ===
        set_current_block(continue_block);
        
        return final_result_reg; // Return the final result register
        
    } else {
        // Non-CFG mode: use labels and jumps
        uint32_t error_label = generate_label();
        uint32_t continue_label = generate_label();
        
        // If it's an error, jump to error handling
        emit_label_jump(LIR_Op::JumpIf, is_error_reg, error_label);
        
        // Success path: unwrap the value
        Reg unwrapped_reg = allocate_register();
        TypePtr success_type = type_system_->STRING_TYPE;
        set_register_type(unwrapped_reg, success_type);
        
        emit_instruction(LIR_Inst(LIR_Op::Unwrap, Type::I64, unwrapped_reg, result_reg, 0));
        
        // Jump to continue execution
        emit_label_jump(LIR_Op::Jump, 0, continue_label);
        
        // Error handling block
        place_label(error_label);
        
        if (expr.elseHandler) {
            // ? else {} construct - execute the else block           
            // Set up else block context
            else_context_.in_else_block = true;
            else_context_.result_register = unwrapped_reg;
            
            // Execute the else block statements
            emit_stmt(*expr.elseHandler);
            
            // Clear else block context
            else_context_.in_else_block = false;
            else_context_.result_register = UINT32_MAX;
            
        } else {
            // Simple ? operator - propagate error by returning
            emit_instruction(LIR_Inst(LIR_Op::Return, Type::Void, result_reg, 0, 0));
        }
        
        // Continue label
        place_label(continue_label);
        
        return unwrapped_reg;
    }
}


Reg Generator::emit_this_expr(LM::Frontend::AST::ThisExpr& expr) {
    if (this_register_ == UINT32_MAX) {
        report_error("'this' used outside of method context");
        return 0;
    }
    return this_register_;
}

// Smart module system implementations

Reg Generator::emit_channel_offer_expr(LM::Frontend::AST::ChannelOfferExpr& expr) {

    // Evaluate value to offer
    Reg value_reg = emit_expr(*expr.value);
    
    // Evaluate channel
    Reg channel_reg = emit_expr(*expr.channel);
    
    // Generate ChannelOffer instruction
    Reg result = allocate_register();
    emit_instruction(LIR_Inst(LIR_Op::ChannelOffer, result, channel_reg, value_reg));
    set_register_type(result, std::make_shared<::Type>(::TypeTag::Bool));
    
    return result;
}


Reg Generator::emit_channel_poll_expr(LM::Frontend::AST::ChannelPollExpr& expr) {
    // Evaluate channel
    Reg channel_reg = emit_expr(*expr.channel);
    
    // Generate ChannelPoll instruction
    Reg result = allocate_register();
    emit_instruction(LIR_Inst(LIR_Op::ChannelPoll, result, channel_reg));
    set_register_type(result, std::make_shared<::Type>(::TypeTag::Any)); // Returns Option<T>
    
    return result;
}


Reg Generator::emit_channel_send_expr(LM::Frontend::AST::ChannelSendExpr& expr) {

    // Evaluate value to send
    Reg value_reg = emit_expr(*expr.value);
    
    // Evaluate channel
    Reg channel_reg = emit_expr(*expr.channel);
    
    // Generate ChannelSend instruction (blocking)
    Reg result = allocate_register();
    emit_instruction(LIR_Inst(LIR_Op::ChannelSend, result, channel_reg, value_reg));
    set_register_type(result, std::make_shared<::Type>(::TypeTag::Nil)); // Void return
    
    return result;
}


Reg Generator::emit_channel_recv_expr(LM::Frontend::AST::ChannelRecvExpr& expr) {

    // Evaluate channel
    Reg channel_reg = emit_expr(*expr.channel);
    
    // Generate ChannelRecv instruction (blocking)
    Reg result = allocate_register();
    emit_instruction(LIR_Inst(LIR_Op::ChannelRecv, result, channel_reg));
    set_register_type(result, std::make_shared<::Type>(::TypeTag::Any)); // Returns T
    
    return result;
}
// Frame system implementations

Reg Generator::emit_cast_expr(LM::Frontend::AST::CastExpr& expr) {
    Reg source = emit_expr(*expr.expression);
    Reg dst = allocate_register();

    TypePtr source_type = get_register_language_type(source);
    TypePtr target_type = expr.inferred_type;

    if (is_decimal_type(source_type) || is_decimal_type(target_type)) {
        // Use DecRescale opcode for decimal rescaling
        Type abi_type = language_type_to_abi_type(target_type);
        emit_instruction(LIR_Inst(LIR_Op::DecRescale, abi_type, dst, source, 0));
        set_register_language_type(dst, target_type);
        set_register_type(dst, target_type);
        return dst;
    }

    if (!source_type || !target_type || source_type->tag != target_type->tag) {
        Type abi_type = language_type_to_abi_type(target_type);
        emit_instruction(LIR_Inst(LIR_Op::Cast, abi_type, dst, source, 0));
        set_register_language_type(dst, target_type);
        set_register_type(dst, target_type);
        return dst;
    }

    // Default fallback to Mov for other casts (already handled by type checker)
    Type abi_type = language_type_to_abi_type(target_type);
    emit_instruction(LIR_Inst(LIR_Op::Mov, abi_type, dst, source, 0));
    set_register_language_type(dst, target_type);
    set_register_type(dst, target_type);
    return dst;
}


Reg Generator::emit_frame_instantiation_expr(LM::Frontend::AST::FrameInstantiationExpr& expr) {
    // Reuse the same logic as emit_call_expr for frame instantiation
    LM::Frontend::AST::CallExpr callExpr;
    callExpr.callee = std::make_shared<LM::Frontend::AST::VariableExpr>();
    static_cast<LM::Frontend::AST::VariableExpr*>(callExpr.callee.get())->name = expr.frameName;
    callExpr.arguments = expr.positionalArgs;
    callExpr.namedArgs = expr.namedArgs;
    callExpr.line = expr.line;
    callExpr.inferred_type = expr.inferred_type;
    
    return emit_call_expr(callExpr);
}


} // namespace LIR
} // namespace LM
