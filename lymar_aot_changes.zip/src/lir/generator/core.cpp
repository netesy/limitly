#include "../generator.hh"
#include "../../memory/lir_analysis.hh"
#include "../functions.hh"
#include "../verifier.hh"
#include "../../frontend/module_manager.hh"
#include "../function_registry.hh"
#include "../builtin_functions.hh"
#include "../builtin_callable.hh"
#include "../../frontend/ast.hh"
#include "../../frontend/scanner.hh"
#include <algorithm>
#include <map>
#include <limits>

using namespace LM::LIR;

namespace LM {
namespace LIR {

// Static member initialization
bool Generator::optimization_enabled_ = true;
bool Generator::show_optimization_debug_ = false;

Generator::Generator() : current_function_(nullptr), next_register_(0), next_label_(0) {
    // Initialize LIR function system
    FunctionUtils::initializeFunctions();
}


std::unique_ptr<LIR_Function> Generator::generate_program(const LM::Frontend::TypeCheckResult& type_check_result) {
    try {
        ownership_facts_ = type_check_result.program->ownership_facts;
        // Set type system reference BEFORE Pass 0
        type_system_ = type_check_result.type_system;

        // PASS 0: Collect function, frame, and module signatures only
        collect_trait_signatures(*type_check_result.program);
        collect_frame_signatures(*type_check_result.program);
        collect_function_signatures(type_check_result);
        collect_module_signatures(*type_check_result.program);

        // PASS 1: Lower function bodies into separate LIR functions
        lower_function_bodies(type_check_result);
    
    // PASS 2: Generate main function with top-level code only
    m_is_terminated = false;
    current_module_ = "root";
    current_function_ = std::make_unique<LIR_Function>("__top_level_wrapper__", 0);
    next_register_ = 0;
    next_label_ = 0;
    scope_stack_.clear();
    loop_stack_.clear();
    register_types_.clear();
    register_abi_types_.clear();
    register_language_types_.clear();
    
    start_cfg_build();
    enter_scope();
    
    // 1. Module Initializations in Topological Order
    auto& manager = LM::Frontend::ModuleManager::getInstance();
    auto sorted_modules = manager.get_topological_order();
    
    for (const auto& module_path : sorted_modules) {
        std::string init_func_name = module_path + ".__init__";
        if (LIRFunctionManager::getInstance().hasFunction(init_func_name)) {
            std::vector<Reg> empty_args;
            Reg init_res = allocate_register();
            emit_instruction(LIR_Inst(LIR_Op::Call, init_res, init_func_name, empty_args));
        }
    }

    // 2. Generate top-level statements
    for (const auto& stmt : type_check_result.program->statements) {
        if (!stmt) continue;
        if (auto func_stmt = dynamic_cast<LM::Frontend::AST::FunctionDeclaration*>(stmt.get())) {
            continue;
        }
        emit_stmt(*stmt);
    }

    // 3. Automatically call main() if defined
    if (LIRFunctionManager::getInstance().hasFunction("main") || function_table_.count("main")) {
        std::vector<Reg> empty_args;
        Reg main_res = allocate_register();
        emit_instruction(LIR_Inst(LIR_Op::Call, main_res, "main", empty_args));
    }
    
    // Call exit_scope BEFORE implicit return to ensure deinitializers are called
    exit_scope();
    current_module_ = "";

    // Add implicit return if none exists
    if (get_current_block() && !get_current_block()->has_terminator()) {
        // For main function, use halt instead of return for proper termination
        if (current_function_->name == "__top_level_wrapper__") {
            emit_instruction(LIR_Inst(LIR_Op::Ret, Type::Void, 0, UINT32_MAX, 0)); // Use Ret for main termination
        } else {
            emit_instruction(LIR_Inst(LIR_Op::Return, Type::Void, 0, UINT32_MAX, 0));
        }
    }

    // Finish CFG building for main
    finish_cfg_build();

    

    if (ownership_facts_) {
        std::vector<std::string> errors;
        if (!Verifier::verify_ownership(*current_function_, errors)) {
            for (const auto& error : errors) report_error(error);
            return nullptr;
        }
    }

    // Optimize the generated LIR (but NOT for top-level wrapper)
    Optimizer optimizer(*current_function_);
    if (current_function_->name != "__top_level_wrapper__") {
        optimizer.optimize();
    }else{
        optimizer.remove_redundant_entry_calls();
    }


    if (ownership_facts_) {
        std::vector<std::string> ownership_errors;
        if (!Verifier::verify_ownership(*current_function_, ownership_errors))
            for (const auto& error : ownership_errors) report_error(error);
    }

    // Collect metrics
    auto metrics = MetricsCollector::collect(*current_function_);
    if (type_check_result.program->statements.size() > 0) {
        // Only print metrics if there's actual code
        // metrics.print();
    }

    materialize_builtin_callables(*current_function_);
    auto result = std::move(current_function_);
    current_function_ = nullptr;
    scope_stack_.clear();
    register_types_.clear();
    
    return result;
    } catch (const std::exception& e) {
        std::cerr << "ERROR in LIR generate_program: " << e.what() << "\n";
        return nullptr;
    } catch (...) {
        std::cerr << "ERROR: Unknown exception in LIR generate_program\n";
        return nullptr;
    }
}


void Generator::generate_function(LM::Frontend::AST::FunctionDeclaration& fn) {
    auto& func_manager = LIRFunctionManager::getInstance();
    
    // Save current function state to allow recursive calls (e.g. lambdas)
    auto saved_references = std::move(checked_references_);
    checked_references_.clear();
    auto saved_function = std::move(current_function_);
    size_t saved_lambda_counter = lambda_counter_;
    lambda_counter_ = 0;
    uint32_t saved_next_reg = next_register_;
    uint32_t saved_next_label = next_label_;
    auto saved_scope_stack = std::move(scope_stack_);
    auto saved_loop_stack = std::move(loop_stack_);
    auto saved_reg_types = std::move(register_types_);
    auto saved_reg_abi_types = std::move(register_abi_types_);
    auto saved_reg_lang_types = std::move(register_language_types_);
    auto saved_cfg_context = cfg_context_;
    Reg saved_env_register = env_register_;
    Reg saved_this_register = this_register_;
    uint32_t saved_region_counter = generator_region_counter_;
    auto saved_region_stack = std::move(generator_region_stack_);
    bool saved_is_terminated = m_is_terminated;
    
    generator_region_counter_ = 0;
    generator_region_stack_.clear();

    // Create function with parameters (including optional parameters)
    size_t total_params = fn.params.size() + fn.optionalParams.size();
    
    // Add hidden environment parameter if this is a closure
    bool is_closure = !current_lambda_captures_.empty();
    if (is_closure) {
        total_params++;
    }

    m_is_terminated = false;
    current_function_ = std::make_unique<LIR_Function>(fn.name, total_params);
    next_register_ = total_params;

    if (is_closure) {
        env_register_ = static_cast<Reg>(total_params - 1);
    } else {
        env_register_ = UINT32_MAX;
    }
    next_label_ = 0;
    scope_stack_.clear();
    loop_stack_.clear();
    register_types_.clear();
    
    start_cfg_build();
    enter_scope();
    
    // Register regular parameters
    for (size_t i = 0; i < fn.params.size(); ++i) {
        bind_variable(fn.params[i].first, static_cast<Reg>(i));
        TypePtr p_type = fn.params[i].second ? convert_ast_type_to_lir_type(fn.params[i].second) : nullptr;
        set_register_language_type(static_cast<Reg>(i), p_type);
        set_register_type(static_cast<Reg>(i), p_type);
    }
    
    // Register optional parameters
    for (size_t i = 0; i < fn.optionalParams.size(); ++i) {
        size_t reg_index = fn.params.size() + i;
        bind_variable(fn.optionalParams[i].first, static_cast<Reg>(reg_index));
        TypePtr p_type = fn.optionalParams[i].second.first ? convert_ast_type_to_lir_type(fn.optionalParams[i].second.first) : nullptr;
        set_register_language_type(static_cast<Reg>(reg_index), p_type);
        set_register_type(static_cast<Reg>(reg_index), p_type);
    }
    
    // Register environment parameter if this is a closure
    if (is_closure) {
        bind_variable("__env", env_register_);
        set_register_type(env_register_, nullptr);
    }
    
    // Emit function body
    if (fn.body) {
        emit_stmt(*fn.body);
    }
    
    // Call exit_scope BEFORE implicit return to ensure deinitializers are called
    exit_scope();

    // Add implicit return if none exists
    if (get_current_block() && !get_current_block()->has_terminator()) {
        emit_instruction(LIR_Inst(LIR_Op::Return, Type::Void, 0, UINT32_MAX, 0));
    }
    
    finish_cfg_build();
    
    if (ownership_facts_) {
        const auto id = fn.memory_info.semantic_id;
        current_function_->inferred_effects = ownership_facts_->functions[id];
        current_function_->ownership_parameters = ownership_facts_->parameters[id];
        for (auto capture : current_function_->inferred_effects.captures_read)
            current_function_->ownership_captures.push_back(capture);
        for (auto capture : current_function_->inferred_effects.captures_mutated)
            if (std::find(current_function_->ownership_captures.begin(), current_function_->ownership_captures.end(), capture) == current_function_->ownership_captures.end()) current_function_->ownership_captures.push_back(capture);
        current_function_->memory_effects.parameters.clear();
        for (auto flags : current_function_->inferred_effects.parameters)
            current_function_->memory_effects.parameters.push_back(flags & Memory::Consume ? Memory::Ownership::Owned : flags & Memory::Opaque ? Memory::Ownership::Unspecified : flags & Memory::Mutate ? Memory::Ownership::WriteBorrow : Memory::Ownership::ReadBorrow);
        current_function_->memory_effects.parameters.resize(current_function_->param_count, Memory::Ownership::ReadBorrow);
        if (current_function_->inferred_effects.return_aliases.size() == 1) {
            current_function_->memory_effects.borrowed_parameter = *current_function_->inferred_effects.return_aliases.begin();
            current_function_->memory_effects.result = Memory::Ownership::ReadBorrow;
        }
    }
    // Convert LIR_Function to LIRFunction and update the registration
    auto result = std::move(current_function_);
    current_function_ = nullptr;
    
    // Create proper LIRFunction from our LIR_Function
    std::vector<LIRParameter> params;
    for (const auto& param : fn.params) {
        LIRParameter lir_param;
        lir_param.name = param.first;
        TypePtr p_type = param.second ? convert_ast_type_to_lir_type(param.second) : nullptr;
        lir_param.type = language_type_to_abi_type(p_type);
        params.push_back(lir_param);
    }
    for (const auto& optional_param : fn.optionalParams) {
        LIRParameter lir_param;
        lir_param.name = optional_param.first;
        TypePtr p_type = optional_param.second.first ? convert_ast_type_to_lir_type(optional_param.second.first) : nullptr;
        lir_param.type = language_type_to_abi_type(p_type);
        params.push_back(lir_param);
    }
    if (is_closure) {
        LIRParameter env_param;
        env_param.name = "__env";
        env_param.type = Type::Ptr;
        params.push_back(env_param);
    }
    
    Type return_abi_type = Type::I64;
    if (fn.returnType.has_value()) {
        auto lang_type = convert_ast_type_to_lir_type(fn.returnType.value());
        return_abi_type = language_type_to_abi_type(lang_type);
    }

    auto lir_func = std::make_shared<LIRFunction>(fn.name, params, return_abi_type, nullptr);
    lir_func->memory_effects_ = result->memory_effects;
    lir_func->inferred_effects_ = result->inferred_effects;
    lir_func->ownership_parameters_ = result->ownership_parameters;
    lir_func->ownership_captures_ = result->ownership_captures;
    lir_func->ownership_provenance_ = result->ownership_provenance;
    lir_func->register_count_ = result->register_count;
    lir_func->setInstructions(result->instructions);
    lir_func->setRegisterLanguageTypes(result->register_language_types);
    lir_func->setRegisterTypes(result->register_types);
    
    // Optimize the generated LIR for this function
    if (false && Generator::is_optimization_enabled()) {
        Optimizer optimizer(*result);
        optimizer.optimize();
        lir_func->setInstructions(result->instructions);
    }

    // Register with manager AFTER instructions and optimization are complete
    func_manager.registerFunction(lir_func);

    // Restore previous state
    checked_references_ = std::move(saved_references);
    current_function_ = std::move(saved_function);
    lambda_counter_ = saved_lambda_counter;
    next_register_ = saved_next_reg;
    next_label_ = saved_next_label;
    scope_stack_ = std::move(saved_scope_stack);
    loop_stack_ = std::move(saved_loop_stack);
    register_types_ = std::move(saved_reg_types);
    register_abi_types_ = std::move(saved_reg_abi_types);
    register_language_types_ = std::move(saved_reg_lang_types);
    cfg_context_ = saved_cfg_context;
    env_register_ = saved_env_register;
    this_register_ = saved_this_register;
    generator_region_counter_ = saved_region_counter;
    generator_region_stack_ = std::move(saved_region_stack);
    m_is_terminated = saved_is_terminated;
}


Reg Generator::allocate_register() {
    if (!current_function_) {
        // If no current function, we can't allocate registers
        // This shouldn't happen in normal operation, but prevents crashes
        return next_register_++;
    }
    return next_register_++;
}


void Generator::enter_scope() {
    scope_stack_.push_back({});
    
    uint32_t region = ++generator_region_counter_;
    generator_region_stack_.push_back(region);
    emit_instruction(LIR_Inst(LIR_Op::RegionEnter, Type::Void, 0, 0, 0, region));
}


void Generator::exit_scope() {
    if (!scope_stack_.empty()) {
        // Region exit finalizes frames at their actual ownership lifetime.
        // A lexical constructor register may refer to an escaping/shared frame.
        scope_stack_.pop_back();
    }
    
    if (!generator_region_stack_.empty()) {
        uint32_t region = generator_region_stack_.back();
        generator_region_stack_.pop_back();
        uint32_t parent = generator_region_stack_.empty() ? 0 : generator_region_stack_.back();
        // Surviving bindings can receive newly allocated values by assignment.
        for (const auto& scope : scope_stack_) {
            for (const auto& [name, reg] : scope.vars)
                emit_instruction(LIR_Inst(LIR_Op::RegionMove, Type::Void, 0, reg, 0, parent));
        }
        emit_instruction(LIR_Inst(LIR_Op::RegionExit, Type::Void, 0, 0, 0, region));
    }
}


// Helper function to get memory_info from a statement if available
std::optional<LM::Frontend::AST::MemoryInfo> Generator::get_memory_info_from_statement(const LM::Frontend::AST::Statement& stmt) {
    return stmt.memory_info.region_id > 0 ? std::optional(stmt.memory_info) : std::nullopt;
}

// Helper function to get memory_info from an expression if available
std::optional<LM::Frontend::AST::MemoryInfo> Generator::get_memory_info_from_expression(const LM::Frontend::AST::Expression& expr) {
    return expr.memory_info.region_id > 0 ? std::optional(expr.memory_info) : std::nullopt;
}

// Emit RegionEnter based on memory_info from statement
// Lexical generator scopes own region emission; checker annotations do not
// create a second, potentially mismatched set of runtime scopes.
void Generator::emit_region_enter_from_memory_info(const LM::Frontend::AST::Statement&) {}
void Generator::emit_region_exit_from_memory_info(const LM::Frontend::AST::Statement&) {}


void Generator::bind_variable(const std::string& name, Reg reg) {
    //// std::cout << "[DEBUG] Binding variable '" << name << "' to register " << reg << std::endl;
    if (scope_stack_.empty()) {
        //// std::cout << "[DEBUG] Creating new scope for variable binding" << std::endl;
        enter_scope();
    }
    scope_stack_.back().vars[name] = reg;
}


void Generator::update_variable_binding(const std::string& name, Reg reg) {
    for (auto it = scope_stack_.rbegin(); it != scope_stack_.rend(); ++it) {
        auto found = it->vars.find(name);
        if (found != it->vars.end()) {
            found->second = reg;
            return;
        }
    }
    bind_variable(name, reg);
}


Reg Generator::resolve_variable(const std::string& name) {
   // std::cout << "[DEBUG] Resolving variable '" << name << "' in " << scope_stack_.size() << " scopes" << std::endl;
    for (auto it = scope_stack_.rbegin(); it != scope_stack_.rend(); ++it) {
        auto found = it->vars.find(name);
        if (found != it->vars.end()) {
           // std::cout << "[DEBUG] Found variable '" << name << "' -> register " << found->second << std::endl;
            return found->second;
        }
    }
   // std::cout << "[DEBUG] Variable '" << name << "' not found" << std::endl;
    return UINT32_MAX;
}


void Generator::set_register_type(Reg reg, TypePtr type) {
    register_types_[reg] = type;
    if (type) {
        set_register_language_type(reg, type);
    }
}


TypePtr Generator::get_register_type(Reg reg) const {
    auto it = register_types_.find(reg);
    if (it != register_types_.end()) {
        return it->second;
    }
    return nullptr;
}

// New simplified type methods

void Generator::set_register_abi_type(Reg reg, Type abi_type) {
    register_abi_types_[reg] = abi_type;
    if (current_function_) {
        current_function_->set_register_abi_type(reg, abi_type);
    }
}


void Generator::set_register_language_type(Reg reg, TypePtr lang_type) {
    register_language_types_[reg] = lang_type;
    register_types_[reg] = lang_type; // Sync register_types_ for binary operator operations
    if (current_function_) {
        current_function_->set_register_language_type(reg, lang_type);
    }
    
    // Also set the ABI type
    if (lang_type && type_system_) {
        Type abi_type = language_type_to_abi_type(lang_type);
        set_register_abi_type(reg, abi_type);
    }
}


Type Generator::get_register_abi_type(Reg reg) const {
    auto it = register_abi_types_.find(reg);
    if (it != register_abi_types_.end()) {
        return it->second;
    }
    return Type::Void;
}


TypePtr Generator::get_register_language_type(Reg reg) const {
    auto it = register_language_types_.find(reg);
    if (it != register_language_types_.end()) {
        return it->second;
    }
    return nullptr;
}


Type Generator::language_type_to_abi_type(TypePtr lang_type) {
    if (!type_system_ || !lang_type) return Type::Void;
    return LIR::language_type_to_abi_type(lang_type);
}


Type Generator::get_expression_abi_type(LM::Frontend::AST::Expression& expr) {
    if (expr.inferred_type && type_system_) {
        return language_type_to_abi_type(expr.inferred_type);
    }
    return Type::Void;
}


void Generator::emit_typed_instruction(const LIR_Inst& inst) {
    // Set the ABI type for the destination register if not already set
    if (inst.dst != UINT32_MAX && inst.result_type != Type::Void) {
        set_register_abi_type(inst.dst, inst.result_type);
    }
    
    // Emit the instruction
    emit_instruction(inst);
}


void Generator::set_register_value(Reg reg, ValuePtr value) {
    register_values_[reg] = value;
    // Also set the type for consistency
    if (value) {
        set_register_type(reg, value->type);
    }
}


ValuePtr Generator::get_register_value(Reg reg) {
    // First check if we have a stored value
    auto it = register_values_.find(reg);
    if (it != register_values_.end()) {
        return it->second;
    }
    
    // If no stored value, try to create one from the type
    TypePtr type = get_register_type(reg);
    if (type) {
        if (type->tag == ::TypeTag::Int) {
            return std::make_shared<Value>(type, static_cast<int64_t>(0));
        } else if (type->tag == ::TypeTag::Float32) {
            return std::make_shared<Value>(type, 0.0);
        } else if (type->tag == ::TypeTag::Bool) {
            return std::make_shared<Value>(type, false);
        } else if (type->tag == ::TypeTag::String) {
            return std::make_shared<Value>(type, std::string(""));
        }
    }
    
    // Fallback: return an int value
    auto int_type = std::make_shared<::Type>(::TypeTag::Int);
    return std::make_shared<Value>(int_type, static_cast<int64_t>(0));
}


void Generator::emit_ownership_event(const Memory::OwnershipEvent& event) {
    if (event.empty()) return;
    LIR_Inst marker(LIR_Op::Nop, Type::Void, UINT32_MAX, UINT32_MAX, UINT32_MAX);
    marker.ownership = event;
    emit_instruction(marker);
}

void Generator::emit_instruction(const LIR_Inst& inst) {
    if (m_is_terminated) {
        return;
    }
    if (current_function_ && inst.isReturn() && !generator_region_stack_.empty()) {
        // All explicit and implicit returns use the same lifetime cleanup,
        // including frame methods and synthesized work-item functions.
        if (inst.a != UINT32_MAX)
            emit_instruction(LIR_Inst(LIR_Op::RegionMove, Type::Void, 0, inst.a, 0, 0));
        for (auto it = generator_region_stack_.rbegin(); it != generator_region_stack_.rend(); ++it)
            emit_instruction(LIR_Inst(LIR_Op::RegionExit, Type::Void, 0, 0, 0, *it));
    }
    LIR_Inst contracted = inst;
    std::set<Reg> task_captures;
    if (inst.op == LIR_Op::TaskContextAlloc) {
        for (const auto& scope : scope_stack_)
            for (const auto& [name, reg] : scope.vars) task_captures.insert(reg);
        for (const auto& [binding, handle] : checked_references_) task_captures.insert(handle);
        if (env_register_ != UINT32_MAX) task_captures.insert(env_register_);
        if (this_register_ != UINT32_MAX) task_captures.insert(this_register_);
        contracted.imm = 8;
        for (auto reg : task_captures) contracted.imm = std::max(contracted.imm, 9 + reg);
    }

    if (ownership_facts_ && inst.op == LIR_Op::Call && inst.func_name.ends_with(".__init__")) {
        const auto module = inst.func_name.substr(0, inst.func_name.size() - 9);
        auto found = ownership_facts_->module_initializations.find(module);
        if (found != ownership_facts_->module_initializations.end())
            contracted.ownership.initializes.assign(found->second.begin(), found->second.end());
    }
    if (current_function_) {
        if (cfg_context_.building_cfg && cfg_context_.current_block) {
            if (cfg_context_.current_block->has_terminator()) {
                // If the block is already terminated, create a new block for subsequent instructions
                LIR_BasicBlock* new_block = create_basic_block("unreachable");
                set_current_block(new_block);
            }
            cfg_context_.current_block->add_instruction(contracted);
        } else {
            current_function_->instructions.push_back(contracted);
        }
        
        current_function_->register_count = std::max(current_function_->register_count, next_register_);
        if (inst.dst != UINT32_MAX && inst.result_type != Type::Void && !inst.isReturn()) {
            auto type = get_register_type(inst.dst);
            if (type) {
                // Use the ABI type conversion instead of legacy method
                Type abi_type = language_type_to_abi_type(type);
                current_function_->set_register_abi_type(inst.dst, abi_type);
            }
        }
        if (inst.op == LIR_Op::TaskContextAlloc) {
            for (auto reg : task_captures)
                emit_instruction(LIR_Inst(LIR_Op::TaskSetField, Type::Void, reg, inst.dst, 0, reg < 3 ? 5 + reg : 8 + reg));
        }
    }
}

// Error handling

bool Generator::has_errors() const {
    return !errors_.empty();
}


std::vector<std::string> Generator::get_errors() const {
    return errors_;
}


void Generator::report_error(const std::string& message) {
    errors_.push_back(message);
}

// AST node visitors

void Generator::cleanup_memory() {
}

// Loop management methods

uint32_t Generator::generate_label() {
    return next_label_++;
}


void Generator::enter_loop() {
    loop_stack_.push_back({INVALID_LOOP_LABEL, INVALID_LOOP_LABEL, INVALID_LOOP_LABEL, generator_region_stack_.size()}); // Placeholder, will be set by set_loop_labels
}


void Generator::exit_loop() {
    if (!loop_stack_.empty()) {
        loop_stack_.pop_back();
    }
}


void Generator::set_loop_labels(uint32_t start_label, uint32_t end_label, uint32_t continue_label) {
    if (!loop_stack_.empty()) {
        if (loop_stack_.back().start_label == INVALID_LOOP_LABEL) {
            loop_stack_.back().start_label = start_label;
        }
        if (end_label != INVALID_LOOP_LABEL) {
            loop_stack_.back().end_label = end_label;
        }
        if (continue_label != INVALID_LOOP_LABEL) {
            loop_stack_.back().continue_label = continue_label;
        }
    }
}


uint32_t Generator::get_break_label() {
    if (loop_stack_.empty()) {
        report_error("break statement not in loop");
        return INVALID_LOOP_LABEL;
    }
    if (loop_stack_.back().end_label == INVALID_LOOP_LABEL) {
        report_error("break statement used before loop exit label is initialized");
    }
    return loop_stack_.back().end_label;
}


uint32_t Generator::get_continue_label() {
    if (loop_stack_.empty()) {
        report_error("continue statement not in loop");
        return INVALID_LOOP_LABEL;
    }
    if (loop_stack_.back().continue_label == INVALID_LOOP_LABEL) {
        report_error("continue statement used before loop continue label is initialized");
    }
    return loop_stack_.back().continue_label;
}


bool Generator::in_loop() const {
    return !loop_stack_.empty();
}

// CFG building methods

void Generator::start_cfg_build() {
    cfg_context_.building_cfg = true;
    cfg_context_.entry_block = create_basic_block("entry");
    cfg_context_.exit_block = create_basic_block("exit");
    set_current_block(cfg_context_.entry_block);
    
    // Set entry and exit in CFG
    current_function_->cfg->entry_block_id = cfg_context_.entry_block->id;
    current_function_->cfg->exit_block_id = cfg_context_.exit_block->id;
    
    cfg_context_.entry_block->is_entry = true;
    cfg_context_.exit_block->is_exit = true;
}


void Generator::ensure_all_blocks_terminated() {
    if (!current_function_ || !current_function_->cfg) {
        return;
    }
    
    // Ensure all blocks have proper terminators
    for (const auto& block : current_function_->cfg->blocks) {
        if (!block) continue;
        
        // Check if block has a terminator
        if (!block->has_terminator()) {
            // Only add terminator if the block is not the exit block
            if (cfg_context_.exit_block && block.get() != cfg_context_.exit_block) {
                // Temporarily set this block as current to emit instruction
                auto saved_current = cfg_context_.current_block;
                cfg_context_.current_block = block.get();
                
                emit_instruction(LIR_Inst(LIR_Op::Jump, 0, 0, 0, cfg_context_.exit_block->id));
                add_block_edge(block.get(), cfg_context_.exit_block);
                
                // Restore current block
                cfg_context_.current_block = saved_current;
            } else if (block.get() == cfg_context_.exit_block) {
                // Exit block should have a return statement
                auto saved_current = cfg_context_.current_block;
                cfg_context_.current_block = block.get();
                
                emit_instruction(LIR_Inst(LIR_Op::Ret, Type::Void, 0, UINT32_MAX, 0));
                
                // Restore current block
                cfg_context_.current_block = saved_current;
            }
        }
    }
}


void Generator::finish_cfg_build() {
    cfg_context_.building_cfg = false;
    
    // If current block doesn't have terminator, add jump to exit
    if (cfg_context_.current_block && !cfg_context_.current_block->has_terminator()) {
        emit_instruction(LIR_Inst(LIR_Op::Jump, 0, 0, 0, cfg_context_.exit_block->id));
        add_block_edge(cfg_context_.current_block, cfg_context_.exit_block);
    }
    
    // Remove unreachable blocks before flattening
    remove_unreachable_blocks();

    // Validate CFG integrity after edge cleanup and before linearization.
    if (!validate_cfg()) {
        report_error("CFG validation failed before flattening for function: " + current_function_->name);
    }
    
    // Flatten CFG blocks into linear instruction stream for JIT consumption
    flatten_cfg_to_instructions();
    Memory::infer_lir_effects(*current_function_);
    std::vector<std::string> memory_errors;
    if (!Verifier::verify_memory_regions(*current_function_, memory_errors)) {
        for (const auto& error : memory_errors) report_error(error);
    }
    
    cfg_context_.current_block = nullptr;
    cfg_context_.entry_block = nullptr;
    cfg_context_.exit_block = nullptr;
}


void Generator::remove_unreachable_blocks() {
    if (!current_function_ || !current_function_->cfg) {
        return;
    }
    
    // Perform reachability analysis from entry block
    std::unordered_set<uint32_t> reachable_blocks;
    std::vector<uint32_t> worklist;
    
    // Start from entry block
    if (current_function_->cfg->entry_block_id != UINT32_MAX) {
        worklist.push_back(current_function_->cfg->entry_block_id);
        reachable_blocks.insert(current_function_->cfg->entry_block_id);
    }
    
    // DFS to find all reachable blocks
    while (!worklist.empty()) {
        uint32_t current_id = worklist.back();
        worklist.pop_back();
        
        auto current_block = current_function_->cfg->get_block(current_id);
        if (!current_block) continue;
        
        // Add all successor blocks to worklist
        for (uint32_t successor_id : current_block->successors) {
            if (reachable_blocks.find(successor_id) == reachable_blocks.end()) {
                reachable_blocks.insert(successor_id);
                worklist.push_back(successor_id);
            }
        }
    }
    
    // Remove unreachable blocks
    auto& blocks = current_function_->cfg->blocks;
    for (auto& block : blocks) {
        if (block && reachable_blocks.find(block->id) == reachable_blocks.end()) {
            block.reset();  // Set to nullptr to maintain index consistency
        }
    }
}


void Generator::flatten_cfg_to_instructions() {
    if (!current_function_ || !current_function_->cfg) {
        return;
    }
    
    // Clear existing linear instructions
    current_function_->instructions.clear();
    
    // Create a map from block ID to instruction position (label)
    std::unordered_map<uint32_t, size_t> block_positions;
    
    // Use DFS to find a linearization (Reverse Post-Order is best)
    std::vector<LIR_BasicBlock*> sorted_blocks;
    std::unordered_set<uint32_t> visited;
    
    std::function<void(uint32_t)> visit = [&](uint32_t block_id) {
        if (visited.count(block_id)) return;
        visited.insert(block_id);
        
        auto block = current_function_->cfg->get_block(block_id);
        if (!block) return;
        
        // Visit successors (in reverse order often helps with linear layout)
        for (auto it = block->successors.rbegin(); it != block->successors.rend(); ++it) {
            visit(*it);
        }
        
        sorted_blocks.push_back(block);
    };

    if (current_function_->cfg->entry_block_id != UINT32_MAX) {
        visit(current_function_->cfg->entry_block_id);
    }
    
    // Reverse to get topological/linear order
    std::reverse(sorted_blocks.begin(), sorted_blocks.end());
    
    // Safety check: ensure ALL blocks are present if they are referenced anywhere
    std::unordered_set<uint32_t> referenced_blocks;
    for (const auto& block : current_function_->cfg->blocks) {
        if (!block) continue;
        for (const auto& inst : block->instructions) {
            if (inst.op == LIR_Op::Jump || inst.op == LIR_Op::JumpIf || inst.op == LIR_Op::JumpIfFalse) {
                referenced_blocks.insert(inst.imm);
            }
        }
    }

    for (uint32_t ref_id : referenced_blocks) {
        if (visited.find(ref_id) == visited.end()) {
            auto block = current_function_->cfg->get_block(ref_id);
            if (block) {
                // If a referenced block was missed (e.g. by jump optimization), force it in
                visit(ref_id);
            }
        }
    }

    // Reachable blocks only are in sorted_blocks at this point.
    // We intentionally don't add remaining blocks as they are unreachable.
    
    // Calculate positions for each block
    size_t current_pos = 0;
    for (const auto* block : sorted_blocks) {
        block_positions[block->id] = current_pos;
        current_pos += block->instructions.size();
    }
    
    // Second pass: emit instructions with proper label targets
    for (const auto* block : sorted_blocks) {
        // Emit all instructions in this block
        for (const auto& inst : block->instructions) {
            LIR_Inst modified_inst = inst;
            
            // Update jump targets to use instruction positions as labels
            if (inst.op == LIR_Op::Jump || inst.op == LIR_Op::JumpIf || inst.op == LIR_Op::JumpIfFalse) {
                auto it = block_positions.find(inst.imm);
                if (it != block_positions.end()) {
                    modified_inst.imm = it->second; // Use instruction position as label
                } else {
                    // Block not found - this might be an error
                    std::cerr << "Warning: Jump target block " << inst.imm << " not found in block_positions" << std::endl;
                }
            } else if (inst.op == LIR_Op::Label) {
                modified_inst.imm = static_cast<Imm>(current_function_->instructions.size());
            }
            
            current_function_->instructions.push_back(modified_inst);
        }
    }
}


void Generator::emit_label_jump(LIR_Op op, Reg cond, uint32_t label) {
    if (!current_function_) return;
    if (m_is_terminated) return;
    if (cfg_context_.building_cfg) {
        report_error("Internal error: symbolic label jump emitted while building CFG");
        return;
    }
    auto& state = linear_label_states_[current_function_.get()];
    state.fixups.emplace_back(current_function_->instructions.size(), label);
    // Target is a placeholder; resolve_linear_labels() patches it.
    if (op == LIR_Op::Jump) {
        emit_instruction(LIR_Inst(LIR_Op::Jump, Type::Void, 0, 0, 0, 0));
    } else {
        emit_instruction(LIR_Inst(op, Type::Void, 0, cond, 0, 0));
    }
}


void Generator::place_label(uint32_t label) {
    m_is_terminated = false;
    if (!current_function_) return;
    auto& state = linear_label_states_[current_function_.get()];
    state.positions[label] = current_function_->instructions.size();
    // dst/a/b are unused (UINT32_MAX = no register); imm is set to the label's own
    // instruction index by resolve_linear_labels(), which is the convention the
    // verifier, optimizer and Fyra builder all read (Label.imm == Jump.imm).
    emit_instruction(LIR_Inst(LIR_Op::Label, Type::Void, UINT32_MAX, UINT32_MAX, UINT32_MAX, label));
}


void Generator::resolve_linear_labels(LIR_Function* func) {
    if (!func) return;
    auto it = linear_label_states_.find(func);
    if (it == linear_label_states_.end()) return;
    LinearLabelState state = std::move(it->second);
    linear_label_states_.erase(it);

    for (const auto& [label, position] : state.positions) {
        // Label.imm becomes its own position so Jump.imm == Label.imm identifies it uniquely.
        func->instructions[position].imm = static_cast<Imm>(position);
    }
    for (const auto& [jump_index, label] : state.fixups) {
        auto pos = state.positions.find(label);
        if (pos == state.positions.end()) {
            report_error("Internal error: jump to unplaced label " + std::to_string(label) +
                         " in function " + func->name);
            continue;
        }
        func->instructions[jump_index].imm = pos->second;
    }
}


LIR_BasicBlock* Generator::create_basic_block(const std::string& label) {
    if (!cfg_context_.building_cfg) {
        report_error("Cannot create basic block outside of CFG build");
        return nullptr;
    }
    
    LIR_BasicBlock* block = current_function_->cfg->create_block(label);
    return block;
}


void Generator::set_current_block(LIR_BasicBlock* block) {
    cfg_context_.current_block = block;
    m_is_terminated = false;
}


void Generator::add_block_edge(LIR_BasicBlock* from, LIR_BasicBlock* to) {
    if (from && to) {
        current_function_->cfg->add_edge(from->id, to->id);
    }
}


LIR_BasicBlock* Generator::get_current_block() const {
    return cfg_context_.current_block;
}


bool Generator::validate_cfg() {
    if (!current_function_ || !current_function_->cfg) {
        report_error("CFG validation: No CFG to validate");
        return false;
    }
    
    bool is_valid = true;
    
    // Check 1: Entry block exists and is reachable
    if (current_function_->cfg->entry_block_id == UINT32_MAX) {
        report_error("CFG validation: No entry block defined");
        is_valid = false;
    } else {
        auto entry_block = current_function_->cfg->get_block(current_function_->cfg->entry_block_id);
        if (!entry_block) {
            report_error("CFG validation: Entry block not found");
            is_valid = false;
        }
    }
    
    // Check 2: All blocks have proper terminators or valid successors
    for (const auto& block : current_function_->cfg->blocks) {
        if (!block) continue;
        
        bool has_terminator = block->has_terminator();
        bool has_successors = !block->successors.empty();
        
        // A block must either have a terminator (return/jump) or successors
        // Exception: success_unwrap blocks in error propagation can continue without terminators
        // Exception: entry blocks in simple functions can fall through without explicit terminators
        // Exception: continuation blocks (fallible_continue, if_end, etc.) can continue without terminators
        if (!has_terminator && !has_successors && !block->is_exit) {
            // Allow success_unwrap blocks to not have terminators (they continue execution)
            if (block->label.find("success_unwrap") == std::string::npos &&
                // Allow entry blocks in simple functions to fall through
                !(block->is_entry && current_function_->cfg->blocks.size() <= 2) &&
                // Allow continuation blocks to not have terminators
                block->label.find("_continue") == std::string::npos &&
                block->label.find("_end") == std::string::npos) {
                report_error("CFG validation: Block " + std::to_string(block->id) + 
                            " (" + block->label + ") has no terminator and no successors");
                is_valid = false;
            }
        }
        
        // Check that all successor blocks exist
        for (uint32_t successor_id : block->successors) {
            auto successor_block = current_function_->cfg->get_block(successor_id);
            if (!successor_block) {
                report_error("CFG validation: Block " + std::to_string(block->id) + 
                            " references non-existent successor " + std::to_string(successor_id));
                is_valid = false;
            }
        }

        // Check that terminator jump targets resolve to valid blocks and CFG edges.
        for (const auto& inst : block->instructions) {
            if (inst.op != LIR_Op::Jump && inst.op != LIR_Op::JumpIf && inst.op != LIR_Op::JumpIfFalse) {
                continue;
            }

            uint32_t target_id = inst.imm;
            auto target_block = current_function_->cfg->get_block(target_id);
            if (!target_block) {
                report_error("CFG validation: Block " + std::to_string(block->id) +
                            " has jump to non-existent block " + std::to_string(target_id));
                is_valid = false;
                continue;
            }

            if (std::find(block->successors.begin(), block->successors.end(), target_id) == block->successors.end()) {
                report_error("CFG validation: Block " + std::to_string(block->id) +
                            " has jump to block " + std::to_string(target_id) +
                            " without a corresponding CFG edge");
                is_valid = false;
            }
        }
        
        // Check that predecessor/successor relationships are symmetric
        for (uint32_t successor_id : block->successors) {
            auto successor_block = current_function_->cfg->get_block(successor_id);
            if (successor_block) {
                bool found_back_edge = false;
                for (uint32_t pred_id : successor_block->predecessors) {
                    if (pred_id == block->id) {
                        found_back_edge = true;
                        break;
                    }
                }
                if (!found_back_edge) {
                    report_error("CFG validation: Asymmetric edge from block " + 
                                std::to_string(block->id) + " to " + std::to_string(successor_id));
                    is_valid = false;
                }
            }
        }
    }
    
    // Check 3: Error propagation blocks must terminate with return
    for (const auto& block : current_function_->cfg->blocks) {
        if (!block) continue;
        
        if (block->label.find("error_propagation") != std::string::npos) {
            if (!block->has_terminator()) {
                report_error("CFG validation: Error propagation block " + std::to_string(block->id) + 
                            " must terminate with return");
                is_valid = false;
            } else {
                // Check that the last instruction is a return
                if (!block->instructions.empty()) {
                    const auto& last_inst = block->instructions.back();
                    if (last_inst.op != LIR_Op::Return && last_inst.op != LIR_Op::Ret) {
                        report_error("CFG validation: Error propagation block " + std::to_string(block->id) + 
                                    " must end with return instruction");
                        is_valid = false;
                    }
                }
            }
        }
    }
    
    // Check 4: Main function must have proper termination after unwrap
    if (current_function_->name == "main") {
        // Look for unwrap instructions followed by proper termination
        for (const auto& block : current_function_->cfg->blocks) {
            if (!block) continue;
            
            for (size_t i = 0; i < block->instructions.size(); ++i) {
                const auto& inst = block->instructions[i];
                if (inst.op == LIR_Op::Unwrap) {
                    // After unwrap, we should either:
                    // 1. Have a return/halt in the same block
                    // 2. Have successors that lead to proper termination
                    bool has_proper_termination = false;
                    
                    // Check remaining instructions in this block
                    for (size_t j = i + 1; j < block->instructions.size(); ++j) {
                        const auto& next_inst = block->instructions[j];
                        if (next_inst.op == LIR_Op::Return || next_inst.op == LIR_Op::Ret) {
                            has_proper_termination = true;
                            break;
                        }
                    }
                    
                    // If no termination in this block, check if block has terminator
                    if (!has_proper_termination && block->has_terminator()) {
                        has_proper_termination = true;
                    }
                    
                    if (!has_proper_termination) {
                        report_error("CFG validation: Main function unwrap at block " + 
                                    std::to_string(block->id) + " must be followed by proper termination");
                        is_valid = false;
                    }
                }
            }
        }
    }
    
    return is_valid;
}


std::shared_ptr<::Type> Generator::convert_ast_type_to_lir_type(const std::shared_ptr<LM::Frontend::AST::TypeAnnotation>& ast_type) {
    if (!ast_type) {
        return nullptr;
    }

    if (ast_type->isFallible || ast_type->isOptional) {
        // Temporarily clear modifiers to avoid infinite recursion
        bool saved_fallible = ast_type->isFallible;
        bool saved_optional = ast_type->isOptional;
        const_cast<LM::Frontend::AST::TypeAnnotation*>(ast_type.get())->isFallible = false;
        const_cast<LM::Frontend::AST::TypeAnnotation*>(ast_type.get())->isOptional = false;
        
        auto success = convert_ast_type_to_lir_type(ast_type);
        
        const_cast<LM::Frontend::AST::TypeAnnotation*>(ast_type.get())->isFallible = saved_fallible;
        const_cast<LM::Frontend::AST::TypeAnnotation*>(ast_type.get())->isOptional = saved_optional;
        
        if (!success) success = std::make_shared<::Type>(::TypeTag::Any);
        
        if (saved_fallible) {
            ::ErrorUnionType eut;
            eut.successType = success;
            eut.errorTypes = ast_type->errorTypes;
            return std::make_shared<::Type>(::TypeTag::ErrorUnion, eut);
        } else {
            // Optional: Union of success and Nil
            ::UnionType ut;
            ut.types.push_back(success);
            ut.types.push_back(std::make_shared<::Type>(::TypeTag::Nil));
            return std::make_shared<::Type>(::TypeTag::Union, ut);
        }
    }

    if (ast_type->isUnion) {
        ::UnionType ut;
        for (const auto& subtype : ast_type->unionTypes) {
            auto converted = convert_ast_type_to_lir_type(subtype);
            if (converted) {
                ut.types.push_back(converted);
            }
        }
        return std::make_shared<::Type>(::TypeTag::Union, ut);
    }

    if (ast_type->isList) {
        auto elem = convert_ast_type_to_lir_type(ast_type->elementType);
        if (!elem) elem = std::make_shared<::Type>(::TypeTag::Any);
        ::ListType lt;
        lt.elementType = elem;
        return std::make_shared<::Type>(::TypeTag::List, lt);
    }

    if (ast_type->isDict) {
        auto key = convert_ast_type_to_lir_type(ast_type->keyType);
        if (!key) key = std::make_shared<::Type>(::TypeTag::Any);
        auto val = convert_ast_type_to_lir_type(ast_type->valueType);
        if (!val) val = std::make_shared<::Type>(::TypeTag::Any);
        ::DictType dt;
        dt.keyType = key;
        dt.valueType = val;
        return std::make_shared<::Type>(::TypeTag::Dict, dt);
    }

    if (ast_type->isTuple) {
        ::TupleType tt;
        for (const auto& subtype : ast_type->tupleTypes) {
            auto converted = convert_ast_type_to_lir_type(subtype);
            if (converted) {
                tt.elementTypes.push_back(converted);
            }
        }
        return std::make_shared<::Type>(::TypeTag::Tuple, tt);
    }
    
    // Use the type checker's resolved aliases rather than treating an alias
    // spelling as an opaque pointer in parameter and arithmetic lowering.
    std::string typeName = ast_type->typeName;
    if (type_system_) {
        auto resolved = type_system_->getType(typeName);
        if (resolved && resolved->tag != ::TypeTag::Nil) return resolved;
        if (auto alias = type_system_->resolveTypeAlias(typeName)) return alias;
    }
    // Convert AST type to LIR type
    if (ast_type->isPrimitive || typeName == "int" || typeName == "uint" ||
        typeName == "float" || typeName == "bool" || typeName == "str" ||
        typeName == "string" || typeName == "void") {

        if (typeName == "int" || typeName == "i64") {
            return std::make_shared<::Type>(::TypeTag::Int64);
        } else if (typeName == "uint" || typeName == "u64") {
            return std::make_shared<::Type>(::TypeTag::UInt64);
        } else if (typeName == "float" || typeName == "f64") {
            return std::make_shared<::Type>(::TypeTag::Float64);
        } else if (typeName == "bool") {
            return std::make_shared<::Type>(::TypeTag::Bool);
        } else if (typeName == "str" || typeName == "string") {
            return std::make_shared<::Type>(::TypeTag::String);
        } else if (typeName == "void") {
            return std::make_shared<::Type>(::TypeTag::Nil);
        }
    }
    
    // Check if it's a frame type
    if (frame_table_.find(typeName) != frame_table_.end()) {
        auto type = std::make_shared<::Type>(::TypeTag::Frame);
        FrameType ft;
        ft.name = typeName;
        type->extra = ft;
        return type;
    }
    
    // Fallback: try to find frame by unqualified name
    for (const auto& [qualified_name, frame_info] : frame_table_) {
        size_t last_dot = qualified_name.rfind('.');
        if (last_dot != std::string::npos && qualified_name.substr(last_dot + 1) == typeName) {
            auto type = std::make_shared<::Type>(::TypeTag::Frame);
            FrameType ft;
            ft.name = qualified_name;
            type->extra = ft;
            return type;
        }
    }

    // Default to Any type for complex or unknown types
    return std::make_shared<::Type>(::TypeTag::Any);
}

// Symbol collection methods (Pass 0)

bool Generator::is_visible(LM::Frontend::AST::VisibilityLevel level, const std::string& frame_name) {
    if (level == LM::Frontend::AST::VisibilityLevel::Public) return true;

    // If current_function_ is null, we are in top-level code (main function)
    // Only public members are visible here
    if (!current_function_) {
        return level == LM::Frontend::AST::VisibilityLevel::Public;
    }

    // Check if we are inside a method of the same frame
    size_t pos = current_function_->name.find(frame_name + ".");
    if (pos == 0 || (pos != std::string::npos && current_function_->name[pos - 1] == '.')) {
        return true;
    }

    // Check for init and deinit methods too
    if (current_function_->name == frame_name + ".init" ||
        current_function_->name == frame_name + ".deinit" ||
        current_function_->name.find("." + frame_name + ".init") != std::string::npos ||
        current_function_->name.find("." + frame_name + ".deinit") != std::string::npos) {
        return true;
    }

    // Handle inheritance (Protected) when implemented
    if (level == LM::Frontend::AST::VisibilityLevel::Protected) {
        auto* target_info = type_system_->getFrameInfo(frame_name);
        if (target_info) {
            for (const auto& trait : target_info->implements) {
                // If current frame context is also a method of a frame implementing same trait
                // We need to extract current frame name from current_function_->name
                auto dot_pos = current_function_->name.find(".");
                if (dot_pos != std::string::npos) {
                    std::string current_frame_name = current_function_->name.substr(0, dot_pos);
                    auto* current_info = type_system_->getFrameInfo(current_frame_name);
                    if (current_info) {
                        for (const auto& ctrait : current_info->implements) {
                            if (trait == ctrait) return true;
                        }
                    }
                }
            }
        }
    }

    return false;
}

// Channel operation implementations

} // namespace LIR
} // namespace LM
