#ifndef LYMAR_LIR_VERIFIER_H
#define LYMAR_LIR_VERIFIER_H

#include "lir.hh"
#include <string>
#include <vector>
#include <unordered_set>

namespace LM {
namespace LIR {

class Verifier {
public:
    static bool verify(const LIR_Function& func, std::vector<std::string>& errors);
    static bool verify_ownership(const LIR_Function& func, std::vector<std::string>& errors);
    static bool verify_memory_regions(const LIR_Function& func, std::vector<std::string>& errors);

private:
    static bool verify_instruction(const LIR_Inst& inst, const LIR_Function& func, std::vector<std::string>& errors);
    static bool verify_control_flow(const LIR_Function& func, std::vector<std::string>& errors);
    static bool detect_infinite_loops(const LIR_Function& func, std::vector<std::string>& errors);
    // H27: conservative, linear / flow-insensitive checks.
    static bool verify_use_before_def(const LIR_Function& func, std::vector<std::string>& errors);
    static bool verify_terminators(const LIR_Function& func, std::vector<std::string>& errors);
    static bool verify_bit_vector_semantics(const LIR_Function& func, std::vector<std::string>& errors);
    static bool verify_float_arithmetic_semantics(const LIR_Function& func, std::vector<std::string>& errors);
    static bool verify_collections_and_strings(const LIR_Function& func, std::vector<std::string>& errors);
    static bool verify_enums_unions_and_contracts(const LIR_Function& func, std::vector<std::string>& errors);
};

} // namespace LIR
} // namespace LM

#endif // LYMAR_LIR_VERIFIER_H
