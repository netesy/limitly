#pragma once
// Shared resource algorithms; independent of AST, LIR and value representation.
#include <cstdint>
#include <cstddef>
#include <cstring>
#include <cstdio>
#include <string>
namespace LM::Runtime {
// ===================== SHA Implementations =====================

class SHA256 {
public:
    SHA256() { reset(); }

    void reset() {
        state_[0] = 0x6a09e667; state_[1] = 0xbb67ae85;
        state_[2] = 0x3c6ef372; state_[3] = 0xa54ff53a;
        state_[4] = 0x510e527f; state_[5] = 0x9b05688c;
        state_[6] = 0x1f83d9ab; state_[7] = 0x5be0cd19;
        buflen_ = 0; totlen_ = 0;
    }

    void update(const uint8_t* data, size_t len) {
        totlen_ += len;
        size_t i = 0;
        while (i < len) {
            size_t space = 64 - buflen_;
            size_t chunk = (len - i < space) ? (len - i) : space;
            std::memcpy(buf_ + buflen_, data + i, chunk);
            buflen_ += chunk;
            i += chunk;
            if (buflen_ == 64) {
                transform(buf_);
                buflen_ = 0;
            }
        }
    }

    std::string digest() {
        uint64_t total_bits = totlen_ * 8;
        uint8_t pad = 0x80;
        update(&pad, 1);
        pad = 0;
        while (buflen_ != 56) update(&pad, 1);
        uint8_t len_be[8];
        for (int i = 7; i >= 0; i--) {
            len_be[i] = (uint8_t)(total_bits & 0xFF);
            total_bits >>= 8;
        }
        update(len_be, 8);

        std::string result;
        result.reserve(64);
        for (int i = 0; i < 8; i++) {
            char hex[9];
            std::snprintf(hex, sizeof(hex), "%08x", (unsigned)state_[i]);
            result += hex;
        }
        return result;
    }

private:
    static uint32_t rotr(uint32_t x, int n) { return (x >> n) | (x << (32 - n)); }
    static uint32_t ch(uint32_t x, uint32_t y, uint32_t z) { return (x & y) ^ (~x & z); }
    static uint32_t maj(uint32_t x, uint32_t y, uint32_t z) { return (x & y) ^ (x & z) ^ (y & z); }
    static uint32_t ep0(uint32_t x) { return rotr(x,2) ^ rotr(x,13) ^ rotr(x,22); }
    static uint32_t ep1(uint32_t x) { return rotr(x,6) ^ rotr(x,11) ^ rotr(x,25); }
    static uint32_t sig0(uint32_t x) { return rotr(x,7) ^ rotr(x,18) ^ (x >> 3); }
    static uint32_t sig1(uint32_t x) { return rotr(x,17) ^ rotr(x,19) ^ (x >> 10); }

    void transform(const uint8_t block[64]) {
        static const uint32_t K[64] = {
            0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
            0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
            0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
            0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
            0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
            0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
            0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
            0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2
        };
        uint32_t W[64];
        for (int i = 0; i < 16; i++) {
            W[i] = ((uint32_t)block[i*4] << 24) | ((uint32_t)block[i*4+1] << 16) |
                   ((uint32_t)block[i*4+2] << 8) | (uint32_t)block[i*4+3];
        }
        for (int i = 16; i < 64; i++) {
            W[i] = sig1(W[i-2]) + W[i-7] + sig0(W[i-15]) + W[i-16];
        }
        uint32_t a = state_[0], b = state_[1], c = state_[2], d = state_[3];
        uint32_t e = state_[4], f = state_[5], g = state_[6], h = state_[7];
        for (int i = 0; i < 64; i++) {
            uint32_t t1 = h + ep1(e) + ch(e,f,g) + K[i] + W[i];
            uint32_t t2 = ep0(a) + maj(a,b,c);
            h = g; g = f; f = e; e = d + t1;
            d = c; c = b; b = a; a = t1 + t2;
        }
        state_[0] += a; state_[1] += b; state_[2] += c; state_[3] += d;
        state_[4] += e; state_[5] += f; state_[6] += g; state_[7] += h;
    }

    uint32_t state_[8];
    uint8_t buf_[64];
    size_t buflen_;
    uint64_t totlen_;
};

class SHA512 {
public:
    SHA512() { reset(); }
    void reset() {
        state_[0] = 0x6a09e667f3bcc908ULL; state_[1] = 0xbb67ae8584caa73bULL;
        state_[2] = 0x3c6ef372fe94f82bULL; state_[3] = 0xa54ff53a5f1d36f1ULL;
        state_[4] = 0x510e527fade682d1ULL; state_[5] = 0x9b05688c2b3e6c1fULL;
        state_[6] = 0x1f83d9abfb41bd6bULL; state_[7] = 0x5be0cd19137e2179ULL;
        buflen_ = 0; totlen_ = 0;
    }
    void update(const uint8_t* data, size_t len) {
        totlen_ += len;
        size_t i = 0;
        while (i < len) {
            size_t space = 128 - buflen_;
            size_t chunk = (len - i < space) ? (len - i) : space;
            std::memcpy(buf_ + buflen_, data + i, chunk);
            buflen_ += chunk; i += chunk;
            if (buflen_ == 128) { transform(buf_); buflen_ = 0; }
        }
    }
    std::string digest() {
        uint64_t total_bits_hi = (totlen_ >> 61);
        uint64_t total_bits_lo = totlen_ * 8;
        uint8_t pad = 0x80; update(&pad, 1); pad = 0;
        while (buflen_ != 112) update(&pad, 1);
        uint8_t len_be[16];
        for (int i = 7; i >= 0; i--) { len_be[i] = (uint8_t)(total_bits_hi & 0xFF); total_bits_hi >>= 8; }
        for (int i = 15; i >= 8; i--) { len_be[i] = (uint8_t)(total_bits_lo & 0xFF); total_bits_lo >>= 8; }
        update(len_be, 16);
        std::string result;
        result.reserve(128);
        for (int i = 0; i < 8; i++) {
            char hex[17];
            std::snprintf(hex, sizeof(hex), "%016llx", (unsigned long long)state_[i]);
            result += hex;
        }
        return result;
    }
private:
    static uint64_t rotr(uint64_t x, int n) { return (x >> n) | (x << (64 - n)); }
    static uint64_t ep0(uint64_t x) { return rotr(x,28)^rotr(x,34)^rotr(x,39); }
    static uint64_t ep1(uint64_t x) { return rotr(x,14)^rotr(x,18)^rotr(x,41); }
    static uint64_t sig0(uint64_t x) { return rotr(x,1)^rotr(x,8)^(x>>7); }
    static uint64_t sig1(uint64_t x) { return rotr(x,19)^rotr(x,61)^(x>>6); }
    static uint64_t ch(uint64_t x, uint64_t y, uint64_t z) { return (x&y)^(~x&z); }
    static uint64_t maj(uint64_t x, uint64_t y, uint64_t z) { return (x&y)^(x&z)^(y&z); }

    void transform(const uint8_t block[128]) {
        static const uint64_t K[80] = {
            0x428a2f98d728ae22ULL, 0x7137449123ef65cdULL, 0xb5c0fbcfec4d3b2fULL, 0xe9b5dba58189dbbcULL,
            0x3956c25bf348b538ULL, 0x59f111f1b605d019ULL, 0x923f82a4af194f9bULL, 0xab1c5ed5da6d8118ULL,
            0xd807aa98a3030242ULL, 0x12835b0145706fbeULL, 0x243185be4ee4b28cULL, 0x550c7dc3d5ffb4e2ULL,
            0x72be5d74f27b896fULL, 0x80deb1fe3b1696b1ULL, 0x9bdc06a725c71235ULL, 0xc19bf174cf692694ULL,
            0xe49b69c19ef14ad2ULL, 0xefbe4786384f25e3ULL, 0x0fc19dc68b8cd5b5ULL, 0x240ca1cc77ac9c65ULL,
            0x2de92c6f592b0275ULL, 0x4a7484aa6ea6e483ULL, 0x5cb0a9dcbd41fbd4ULL, 0x76f988da831153b5ULL,
            0x983e5152ee66dfabULL, 0xa831c66d2db43210ULL, 0xb00327c898fb213fULL, 0xbf597fc7beef0ee4ULL,
            0xc6e00bf33da88fc2ULL, 0xd5a79147930aa725ULL, 0x06ca6351e003826fULL, 0x142929670a0e6e70ULL,
            0x27b70a8546d22ffcULL, 0x2e1b21385c26c926ULL, 0x4d2c6dfc5ac42aedULL, 0x53380d139d95b3dfULL,
            0x650a73548baf63deULL, 0x766a0abb3c77b2a8ULL, 0x81c2c92e47edaee6ULL, 0x92722c851482353bULL,
            0xa2bfe8a14cf10364ULL, 0xa81a664bbc423001ULL, 0xc24b8b70d0f89791ULL, 0xc76c51a30654be30ULL,
            0xd192e819d6ef5218ULL, 0xd69906245565a910ULL, 0xf40e35855771202aULL, 0x106aa07032bbd1b8ULL,
            0x19a4c116b8d2d0c8ULL, 0x1e376c085141ab53ULL, 0x2748774cdf8eeb99ULL, 0x34b0bcb5e19b48a8ULL,
            0x391c0cb3c5c95a63ULL, 0x4ed8aa4ae3418acbULL, 0x5b9cca4f7763e373ULL, 0x682e6ff3d6b2b8a3ULL,
            0x748f82ee5defb2fcULL, 0x78a5636f43172f60ULL, 0x84c87814a1f0ab72ULL, 0x8cc702081a6439ecULL,
            0x90befffa23631e28ULL, 0xa4506cebde82bde9ULL, 0xbef9a3f7b2c67915ULL, 0xc67178f2e372532bULL,
            0xca273eceea26619cULL, 0xd186b8c721c0c207ULL, 0xeada7dd6cde0eb1eULL, 0xf57d4f7fee6ed178ULL,
            0x06f067aa72176fbaULL, 0x0a637dc5a2c898a6ULL, 0x113f9804bef90daeULL, 0x1b710b35131c471bULL,
            0x28db77f523047d84ULL, 0x32caab7b40c72493ULL, 0x3c9ebe0a15c9bebcULL, 0x431d67c49c100d4cULL,
            0x4cc5d4becb3e42b6ULL, 0x597f299cfc657e2aULL, 0x5fcb6fab3ad6faecULL, 0x6c44198c4a475817ULL
        };
        uint64_t W[80];
        for (int i = 0; i < 16; i++) {
            W[i] = ((uint64_t)block[i*8] << 56) | ((uint64_t)block[i*8+1] << 48) |
                   ((uint64_t)block[i*8+2] << 40) | ((uint64_t)block[i*8+3] << 32) |
                   ((uint64_t)block[i*8+4] << 24) | ((uint64_t)block[i*8+5] << 16) |
                   ((uint64_t)block[i*8+6] << 8) | (uint64_t)block[i*8+7];
        }
        for (int i = 16; i < 80; i++) {
            W[i] = sig1(W[i-2]) + W[i-7] + sig0(W[i-15]) + W[i-16];
        }
        uint64_t a = state_[0], b = state_[1], c = state_[2], d = state_[3];
        uint64_t e = state_[4], f = state_[5], g = state_[6], h = state_[7];
        for (int i = 0; i < 80; i++) {
            uint64_t t1 = h + ep1(e) + ch(e,f,g) + K[i] + W[i];
            uint64_t t2 = ep0(a) + maj(a,b,c);
            h = g; g = f; f = e; e = d + t1;
            d = c; c = b; b = a; a = t1 + t2;
        }
        state_[0] += a; state_[1] += b; state_[2] += c; state_[3] += d;
        state_[4] += e; state_[5] += f; state_[6] += g; state_[7] += h;
    }

    uint64_t state_[8];
    uint8_t buf_[128];
    size_t buflen_;
    uint64_t totlen_;
};

class SHA1 {
public:
    SHA1() { reset(); }
    void reset() {
        h0_ = 0x67452301; h1_ = 0xEFCDAB89; h2_ = 0x98BADCFE;
        h3_ = 0x10325476; h4_ = 0xC3D2E1F0;
        buflen_ = 0; totlen_ = 0;
    }
    void update(const uint8_t* data, size_t len) {
        totlen_ += len;
        size_t i = 0;
        while (i < len) {
            size_t space = 64 - buflen_;
            size_t chunk = (len - i < space) ? (len - i) : space;
            std::memcpy(buf_ + buflen_, data + i, chunk);
            buflen_ += chunk; i += chunk;
            if (buflen_ == 64) { transform(buf_); buflen_ = 0; }
        }
    }
    std::string digest() {
        uint64_t total_bits = totlen_ * 8;
        uint8_t pad = 0x80; update(&pad, 1); pad = 0;
        while (buflen_ != 56) update(&pad, 1);
        uint8_t len_be[8];
        for (int i = 7; i >= 0; i--) { len_be[i] = (uint8_t)(total_bits & 0xFF); total_bits >>= 8; }
        update(len_be, 8);
        char hex[41];
        std::snprintf(hex, sizeof(hex), "%08x%08x%08x%08x%08x", h0_, h1_, h2_, h3_, h4_);
        return std::string(hex);
    }
private:
    static uint32_t rotl(uint32_t x, int n) { return (x << n) | (x >> (32 - n)); }
    static uint32_t ch(uint32_t x, uint32_t y, uint32_t z) { return (x & y) ^ (~x & z); }
    static uint32_t parity(uint32_t x, uint32_t y, uint32_t z) { return x ^ y ^ z; }
    static uint32_t maj(uint32_t x, uint32_t y, uint32_t z) { return (x & y) ^ (x & z) ^ (y & z); }
    void transform(const uint8_t block[64]) {
        uint32_t W[80];
        for (int i = 0; i < 16; i++) {
            W[i] = ((uint32_t)block[i*4] << 24) | ((uint32_t)block[i*4+1] << 16) |
                   ((uint32_t)block[i*4+2] << 8) | (uint32_t)block[i*4+3];
        }
        for (int i = 16; i < 80; i++) {
            W[i] = rotl(W[i-3]^W[i-8]^W[i-14]^W[i-16], 1);
        }
        uint32_t a = h0_, b = h1_, c = h2_, d = h3_, e = h4_;
        for (int i = 0; i < 80; i++) {
            uint32_t f, k;
            if (i < 20)      { f = ch(b, c, d);     k = 0x5A827999; }
            else if (i < 40) { f = parity(b, c, d); k = 0x6ED9EBA1; }
            else if (i < 60) { f = maj(b, c, d);    k = 0x8F1BBCDC; }
            else             { f = parity(b, c, d); k = 0xCA62C1D6; }
            uint32_t t = rotl(a, 5) + f + e + k + W[i];
            e = d; d = c; c = rotl(b, 30); b = a; a = t;
        }
        h0_ += a; h1_ += b; h2_ += c; h3_ += d; h4_ += e;
    }
    uint32_t h0_, h1_, h2_, h3_, h4_;
    uint8_t buf_[64];
    size_t buflen_;
    uint64_t totlen_;
};

class MD5 {
public:
    MD5() { reset(); }
    void reset() { a0_ = 0x67452301; b0_ = 0xEFCDAB89; c0_ = 0x98BADCFE; d0_ = 0x10325476; buflen_ = 0; totlen_ = 0; }
    void update(const uint8_t* data, size_t len) {
        totlen_ += len;
        size_t i = 0;
        while (i < len) {
            size_t space = 64 - buflen_;
            size_t chunk = (len - i < space) ? (len - i) : space;
            std::memcpy(buf_ + buflen_, data + i, chunk);
            buflen_ += chunk; i += chunk;
            if (buflen_ == 64) { transform(buf_); buflen_ = 0; }
        }
    }
    std::string digest() {
        uint64_t total_bits = totlen_ * 8;
        uint8_t pad = 0x80; update(&pad, 1); pad = 0;
        while (buflen_ != 56) update(&pad, 1);
        uint8_t len_le[8] = {}; uint64_t tb = total_bits;
        for (int i = 0; i < 8; i++) { len_le[i] = (uint8_t)(tb & 0xFF); tb >>= 8; }
        update(len_le, 8);
        char hex[33];
        std::snprintf(hex, sizeof(hex), "%08x%08x%08x%08x", a0_, b0_, c0_, d0_);
        return std::string(hex);
    }
private:
    static uint32_t F(uint32_t x, uint32_t y, uint32_t z) { return (x & y) | (~x & z); }
    static uint32_t G(uint32_t x, uint32_t y, uint32_t z) { return (x & z) | (y & ~z); }
    static uint32_t H(uint32_t x, uint32_t y, uint32_t z) { return x ^ y ^ z; }
    static uint32_t I(uint32_t x, uint32_t y, uint32_t z) { return y ^ (x | ~z); }
    static uint32_t rotl(uint32_t x, int n) { return (x << n) | (x >> (32 - n)); }

    void transform(const uint8_t block[64]) {
        static const uint32_t T[64] = {
            0xd76aa478, 0xe8c7b756, 0x242070db, 0xc1bdceee, 0xf57c0faf, 0x4787c62a, 0xa8304613, 0xfd469501,
            0x698098d8, 0x8b44f7af, 0xffff5bb1, 0x895cd7be, 0x6b901122, 0xfd987193, 0xa679438e, 0x49b40821,
            0xf61e2562, 0xc040b340, 0x265e5a51, 0xe9b6c7aa, 0xd62f105d, 0x02441453, 0xd8a1e681, 0xe7d3fbc8,
            0x21e1cde6, 0xc33707d6, 0xf4d50d87, 0x455a14ed, 0xa9e3e905, 0xfcefa3f8, 0x676f02d9, 0x8d2a4c8a,
            0xfffa3942, 0x8771f681, 0x6d9d6122, 0xfde5380c, 0xa4beea44, 0x4bdecfa9, 0xf6bb4b60, 0xbebfbc70,
            0x289b7ec6, 0xeaa127fa, 0xd4ef3085, 0x04881d05, 0xd9d4d039, 0xe6db99e5, 0x1fa27cf8, 0xc4ac5665,
            0xf4292244, 0x432aff97, 0xab9423a7, 0xfc93a039, 0x655b59c3, 0x8f0ccc92, 0xffeff47d, 0x85845dd1,
            0x6fa87e4f, 0xfe2ce6e0, 0xa3014314, 0x4e0811a1, 0xf7537e82, 0xbd3af235, 0x2ad7d2bb, 0xeb86d391
        };
        uint32_t M[16];
        for (int i = 0; i < 16; i++) {
            M[i] = (uint32_t)block[i*4] | ((uint32_t)block[i*4+1] << 8) |
                   ((uint32_t)block[i*4+2] << 16) | ((uint32_t)block[i*4+3] << 24);
        }
        uint32_t a = a0_, b = b0_, c = c0_, d = d0_;
        for (int i = 0; i < 64; i++) {
            uint32_t f, g; int s;
            if (i < 16)      { f = F(b, c, d); g = i;          static const int ss[] = {7, 12, 17, 22}; s = ss[i%4]; }
            else if (i < 32) { f = G(b, c, d); g = (5*i+1)%16; static const int ss[] = {5, 9, 14, 20}; s = ss[i%4]; }
            else if (i < 48) { f = H(b, c, d); g = (3*i+5)%16; static const int ss[] = {4, 11, 16, 23}; s = ss[i%4]; }
            else             { f = I(b, c, d); g = (7*i)%16;   static const int ss[] = {6, 10, 15, 21}; s = ss[i%4]; }
            uint32_t temp = b + rotl(a + f + T[i] + M[g], s);
            a = d; d = c; c = b; b = temp;
        }
        a0_ += a; b0_ += b; c0_ += c; d0_ += d;
    }
    uint32_t a0_, b0_, c0_, d0_;
    uint8_t buf_[64];
    size_t buflen_;
    uint64_t totlen_;
};

inline std::string compute_hmac(const std::string& algo, const std::string& key, const std::string& data) {
    size_t block_size = 64;
    if (algo == "sha512") block_size = 128;

    std::string k = key;
    if (k.size() > block_size) {
        if (algo == "sha256") { SHA256 h; h.update((const uint8_t*)k.data(), k.size()); k = h.digest(); }
        else if (algo == "sha512") { SHA512 h; h.update((const uint8_t*)k.data(), k.size()); k = h.digest(); }
        else if (algo == "sha1") { SHA1 h; h.update((const uint8_t*)k.data(), k.size()); k = h.digest(); }
        else if (algo == "md5") { MD5 h; h.update((const uint8_t*)k.data(), k.size()); k = h.digest(); }
    }
    if (k.size() < block_size) k.append(block_size - k.size(), '\0');

    std::string o_key_pad = k, i_key_pad = k;
    for (size_t i = 0; i < block_size; i++) {
        o_key_pad[i] ^= 0x5c;
        i_key_pad[i] ^= 0x36;
    }

    std::string i_hash;
    if (algo == "sha256") { SHA256 h; h.update((const uint8_t*)i_key_pad.data(), i_key_pad.size()); h.update((const uint8_t*)data.data(), data.size()); i_hash = h.digest(); }
    else if (algo == "sha512") { SHA512 h; h.update((const uint8_t*)i_key_pad.data(), i_key_pad.size()); h.update((const uint8_t*)data.data(), data.size()); i_hash = h.digest(); }
    else if (algo == "sha1") { SHA1 h; h.update((const uint8_t*)i_key_pad.data(), i_key_pad.size()); h.update((const uint8_t*)data.data(), data.size()); i_hash = h.digest(); }
    else if (algo == "md5") { MD5 h; h.update((const uint8_t*)i_key_pad.data(), i_key_pad.size()); h.update((const uint8_t*)data.data(), data.size()); i_hash = h.digest(); }

    if (algo == "sha256") { SHA256 h; h.update((const uint8_t*)o_key_pad.data(), o_key_pad.size()); h.update((const uint8_t*)i_hash.data(), i_hash.size()); return h.digest(); }
    else if (algo == "sha512") { SHA512 h; h.update((const uint8_t*)o_key_pad.data(), o_key_pad.size()); h.update((const uint8_t*)i_hash.data(), i_hash.size()); return h.digest(); }
    else if (algo == "sha1") { SHA1 h; h.update((const uint8_t*)o_key_pad.data(), o_key_pad.size()); h.update((const uint8_t*)i_hash.data(), i_hash.size()); return h.digest(); }
    else if (algo == "md5") { MD5 h; h.update((const uint8_t*)o_key_pad.data(), o_key_pad.size()); h.update((const uint8_t*)i_hash.data(), i_hash.size()); return h.digest(); }
    return "";
}

class HashEngine {
public:
    bool open(const std::string& algorithm) {
        algorithm_=algorithm;
        if(algorithm=="sha256") sha256_.reset();
        else if(algorithm=="sha512") sha512_.reset();
        else if(algorithm=="sha1") sha1_.reset();
        else if(algorithm=="md5") md5_.reset();
        else return false;
        return true;
    }
    void write(const char* bytes,size_t length) {
        auto* data=reinterpret_cast<const uint8_t*>(bytes);
        if(algorithm_=="sha256") sha256_.update(data,length);
        else if(algorithm_=="sha512") sha512_.update(data,length);
        else if(algorithm_=="sha1") sha1_.update(data,length);
        else if(algorithm_=="md5") md5_.update(data,length);
    }
    std::string read() {
        if(algorithm_=="sha256") return sha256_.digest();
        if(algorithm_=="sha512") return sha512_.digest();
        if(algorithm_=="sha1") return sha1_.digest();
        if(algorithm_=="md5") return md5_.digest();
        return {};
    }
private:
    std::string algorithm_;
    SHA256 sha256_; SHA512 sha512_; SHA1 sha1_; MD5 md5_;
};
}
