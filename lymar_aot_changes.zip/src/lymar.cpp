#include "lymar.hh"
#include "frontend/scanner.hh"
#include "frontend/parser.hh"
#include "frontend/cst/printer.hh"
#include "frontend/ast/printer.hh"
#include "frontend/type_checker.hh"
#include "frontend/memory_checker.hh"
#include "frontend/optimizer/stream_fusion.hh"
#include "frontend/module_manager.hh"
#include "memory/ownership.hh"
#include "lir/generator.hh"
#include "lir/functions.hh"
#include "backend/vm/register.hh"
#include "error/debugger.hh"

// Fyra backend - conditionally compiled if available
#ifdef FYRA_AVAILABLE
#include "backend/fyra/fyra.hh"
#include "backend/fyra/builder.hh"
#include "ir/IRContext.h"
#include "ir/Module.h"
#include "ir/Function.h"
#endif

#include <iostream>
#include <fstream>
#include <sstream>
#include <filesystem>

namespace LM {

static std::string readFile(const std::string& filename) {
    std::ifstream file(filename);
    if (!file.is_open()) {
        throw std::runtime_error("Could not open file: " + filename);
    }
    std::stringstream buffer;
    buffer << file.rdbuf();
    return buffer.str();
}

int Compiler::executeFile(const std::string& filename, const CompileOptions& options) {
    try {
        std::string source = readFile(filename);
        std::string exported_module;
        // A module library must be lowered in its module namespace, not as an
        // application root (whose uncalled functions are otherwise unreachable).
        if (options.use_aot && (options.artifact_type == ArtifactType::SharedLibrary ||
                                options.artifact_type == ArtifactType::StaticLibrary)) {
            std::filesystem::path module_path(filename);
            module_path.replace_extension();
            std::string name = module_path.generic_string();
            if (name.starts_with("./")) name.erase(0, 2);
            std::replace(name.begin(), name.end(), '/', '.');
            if (name.ends_with(".index")) name.resize(name.size() - 6);
            exported_module = name;
            source = "import " + name + ";";
        }
        LM::Frontend::Scanner scanner(source, filename);
        scanner.scanTokens();

        if (options.print_tokens) {
            std::cout << "=== Tokens ===\n";
            for (const auto& token : scanner.getTokens()) {
                std::cout << scanner.tokenTypeToString(token.type)
                          << ": '" << token.lexeme << "' (line " << token.line << ")\n";
            }
            std::cout << "\n";
            return 0;
        }

        LM::Frontend::Parser parser(scanner, options.print_cst);
        std::shared_ptr<LM::Frontend::AST::Program> ast = parser.parse();
        if (LM::Error::Debugger::hasError()) {
            std::cerr << "Parser hasError is true! reportedErrors size: " << LM::Error::Debugger::hasError() << std::endl;
            return 1;
        }

        LM::Frontend::ModuleManager::getInstance().set_include_dirs(options.include_dirs);

        ast = LM::Frontend::AST::StreamFusionVisitor::optimizeProgram(ast);

        const auto verification_policy = options.strict_verification
            ? LM::Frontend::VerificationPolicy::Strict
            : LM::Frontend::VerificationPolicy::Hybrid;
        auto type_check_result = LM::Frontend::TypeCheckerFactory::check_program(ast, source, filename, verification_policy);
        if (!type_check_result.success || !type_check_result.errors.empty()) {
            for (const auto& err : type_check_result.errors) {
                std::cerr << "Type Check Error: " << err << std::endl;
            }
            return 1;
        }

        auto memory_check_result = LM::Frontend::MemoryCheckerFactory::check_program(type_check_result.program, source, filename);
        if (!memory_check_result.success) {
            std::cerr << "Memory Check Failed! Local errors count: " << memory_check_result.errors.size() << std::endl;
            for (const auto& err : memory_check_result.errors) {
                std::cerr << "  Memory Error: " << err << std::endl;
            }
            return 1;
        }
        ast = memory_check_result.program;

        if (options.print_cst) {
            std::cout << "=== CST ===\n";
            const auto* cstRoot = parser.getCST();
            if (cstRoot) std::cout << Frontend::CST::Printer::printCST(cstRoot) << "\n";
            return 0;
        }

        if (options.print_ast) {
            std::cout << "=== AST ===\n";
            LM::Frontend::AST::ASTPrinter printer;
            printer.process(ast);
            std::cout << "\n";
            return 0;
        }

        LIR::Generator lir_generator;
        lir_generator.set_import_aliases(type_check_result.import_aliases);
        lir_generator.set_registered_modules(type_check_result.registered_modules);

        auto lir_function = lir_generator.generate_program(type_check_result);
        if (lir_generator.has_errors()) {
            std::cerr << "[ERROR] LIR generation had errors:" << std::endl;
            for (const auto& err : lir_generator.get_errors()) {
                std::cerr << "  " << err << std::endl;
            }
            return 1;
        }
        if (!lir_function) {
            std::cerr << "[ERROR] LIR generation failed" << std::endl;
            return 1;
        }

        if (options.print_lir) {
             std::cout << "\n=== Final LIR ===\n";
             if (lir_function) {
                 LIR::Disassembler disassembler(*lir_function);
                 std::cout << disassembler.disassemble() << "\n";
             }
             return 0;
        }

        if (options.use_aot || options.use_wasm || options.use_wasi || options.print_fyra_ir) {
#ifdef FYRA_AVAILABLE
            try {
                LM::Backend::Fyra::FyraCompiler fyra;
                fyra.set_debug_mode(options.debug);

                LM::Backend::Fyra::FyraCompileOptions fyra_options;
                fyra_options.exported_module = exported_module;
                fyra_options.platform = (options.target == "windows" ? LM::Backend::Fyra::Platform::Windows :
                                         (options.target == "macos" ? LM::Backend::Fyra::Platform::MacOS :
                                          (options.target == "wasm" ? LM::Backend::Fyra::Platform::WASM : LM::Backend::Fyra::Platform::Linux)));
                fyra_options.arch = (options.arch == "aarch64" ? LM::Backend::Fyra::Architecture::AArch64 :
                                     (options.arch == "wasm32" ? LM::Backend::Fyra::Architecture::WASM32 :
                                      (options.arch == "riscv64" ? LM::Backend::Fyra::Architecture::RISCV64 : LM::Backend::Fyra::Architecture::X86_64)));
                fyra_options.opt_level = (LM::Backend::Fyra::OptimizationLevel)options.opt_level;
                fyra_options.output_file = options.output_file;
                fyra_options.strip = options.strip;
                fyra_options.dump_intermediate = options.dump_intermediate;

                switch (options.artifact_type) {
                    case LM::ArtifactType::Object:
                        fyra_options.artifact_kind = LM::Backend::Fyra::ArtifactKind::Object;
                        break;
                    case LM::ArtifactType::StaticLibrary:
                        fyra_options.artifact_kind = LM::Backend::Fyra::ArtifactKind::StaticLibrary;
                        break;
                    case LM::ArtifactType::SharedLibrary:
                        fyra_options.artifact_kind = LM::Backend::Fyra::ArtifactKind::SharedLibrary;
                        break;
                    case LM::ArtifactType::Assembly:
                        fyra_options.artifact_kind = LM::Backend::Fyra::ArtifactKind::Assembly;
                        break;
                    case LM::ArtifactType::Executable:
                    default:
                        fyra_options.artifact_kind = LM::Backend::Fyra::ArtifactKind::Executable;
                        break;
                }

                if (options.print_fyra_ir) {
                    auto ir_context = std::make_shared<ir::IRContext>();
                    LM::Backend::Fyra::LIRToFyraIRBuilder builder(ir_context);
                    auto fyra_ir_module = builder.build(*lir_function, exported_module);
                    if (!fyra_ir_module || builder.has_errors()) {
                        std::cerr << "[ERROR] LIR to Fyra IR lowering failed" << std::endl;
                        for (const auto& err : builder.get_errors()) {
                            std::cerr << "  Details: " << err << std::endl;
                        }
                        return 1;
                    }
                    fyra_ir_module->print(std::cout);
                    return 0;
                }

                auto result = fyra.compile(*lir_function, fyra_options);
                for (const auto& warning : result.warnings)
                    std::cerr << "[WARN] " << warning << '\n';
                if (!result.success) {
                    std::cerr << "[ERROR] AOT Compilation Failed" << std::endl;
                    std::cerr << "  Message: " << result.error_message << std::endl;
                    return 1;
                }
                return 0;
            } catch (const std::exception& e) {
                std::cerr << "[ERROR] Exception in Fyra backend: " << e.what() << std::endl;
                return 1;
            }
#else
            std::cerr << "Error: Fyra backend not available. AOT/WASM compilation is disabled.\n";
            std::cerr << "Please install Fyra or use the register VM instead.\n";
            return 1;
#endif
        } else {
            LM::Backend::VM::Register::RegisterVM register_vm;
            register_vm.execute_function(*lir_function);
        }
    } catch (const std::exception& e) {
        std::cerr << "Error: " << e.what() << "\n";
        return 1;
    }
    return 0;
}

std::string Formatter::format(const std::string& source) {
    return source;
}

}
