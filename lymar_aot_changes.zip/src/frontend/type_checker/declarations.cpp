#include "../type_checker.hh"
#include "../module_manager.hh"
#include <filesystem>
#include <algorithm>

namespace fs = std::filesystem;

using namespace LM::Frontend;

namespace LM {
namespace Frontend {

TypePtr TypeChecker::check_contract_statement(std::shared_ptr<LM::Frontend::AST::ContractStatement> contract_stmt) {
    if (!contract_stmt) return nullptr;
    
    if (!contract_stmt->condition) {
        add_error("contract statement missing condition", contract_stmt->line, 0, 
                get_code_context(contract_stmt->line), "contract", "contract(condition, message)");
        return type_system.NIL_TYPE;
    }
    
    if (!contract_stmt->message) {
        add_error("contract statement missing message", contract_stmt->line, 0, 
                get_code_context(contract_stmt->line), "contract", "contract(condition, message)");
        return type_system.NIL_TYPE;
    }
    
    // Check condition is boolean
    TypePtr conditionType = check_expression(contract_stmt->condition);
    if (!is_boolean_type(conditionType) && conditionType->tag != TypeTag::Any) {
        add_error("contract condition must be boolean, got " + conditionType->toString(), 
                contract_stmt->line, 0, get_code_context(contract_stmt->line), "condition", "boolean expression");
    }
    
    // Check message is string
    TypePtr messageType = check_expression(contract_stmt->message);
    if (!is_string_type(messageType) && messageType->tag != TypeTag::Any) {
        add_error("contract message must be string, got " + messageType->toString(), 
                contract_stmt->line, 0, get_code_context(contract_stmt->line), "message", "string literal or expression");
    }
    
    // Evaluate static contract condition at stage 0 compile-time using constant evaluation or SMT solver
    long long val_int = 0;
    double val_double = 0.0;
    bool is_int = false;
    if (evaluate_const_expr(contract_stmt->condition, val_int, val_double, is_int, this)) {
        bool cond_true = is_int ? (val_int != 0) : (val_double != 0.0);
        if (cond_true) {
            contract_stmt->verification_state = LM::Frontend::AST::ContractVerificationState::StaticallyProven;
        } else {
            contract_stmt->verification_state = LM::Frontend::AST::ContractVerificationState::Counterexample;
            std::string msg = "Contract assertion failed";
            if (auto lit_msg = std::dynamic_pointer_cast<LM::Frontend::AST::LiteralExpr>(contract_stmt->message)) {
                if (std::holds_alternative<std::string>(lit_msg->value)) {
                    msg = std::get<std::string>(lit_msg->value);
                }
            }
            add_error("compile-time contract violation: " + msg, contract_stmt->line);
        }
    } else {
        // Evaluate via SMT Solver Helper
        SMTProofResult smt_res = SMTVerifier::verify_obligation(contract_stmt->condition);
        if (smt_res.status == SMTProofStatus::Proven) {
            contract_stmt->verification_state = LM::Frontend::AST::ContractVerificationState::StaticallyProven;
        } else if (smt_res.status == SMTProofStatus::Counterexample) {
            contract_stmt->verification_state = LM::Frontend::AST::ContractVerificationState::Counterexample;
            std::string msg = "Contract assertion failed (SMT Counterexample)";
            if (auto lit_msg = std::dynamic_pointer_cast<LM::Frontend::AST::LiteralExpr>(contract_stmt->message)) {
                if (std::holds_alternative<std::string>(lit_msg->value)) {
                    msg = std::get<std::string>(lit_msg->value);
                }
            }
            add_error("compile-time contract violation: " + msg, contract_stmt->line);
        } else {
            contract_stmt->verification_state = LM::Frontend::AST::ContractVerificationState::UnsupportedOrUnknown;
            if (verification_policy_ == VerificationPolicy::Strict) {
                add_error("strict verification could not prove contract: " + smt_res.message,
                          contract_stmt->line);
            }
        }
    }

    contract_stmt->inferred_type = type_system.NIL_TYPE;
    return type_system.NIL_TYPE;
}

static bool is_catch_all_pattern(std::shared_ptr<LM::Frontend::AST::Expression> pattern) {
    if (!pattern) return false;

    // Check if it is a VariableExpr
    if (auto var = std::dynamic_pointer_cast<LM::Frontend::AST::VariableExpr>(pattern)) {
        return true;
    }

    // Check for or pattern where at least one pattern is a catch-all
    if (auto or_pat = std::dynamic_pointer_cast<LM::Frontend::AST::OrPatternExpr>(pattern)) {
        for (const auto& p : or_pat->patterns) {
            if (is_catch_all_pattern(p)) return true;
        }
    }

    return false;
}

static void collect_matched_variants(std::shared_ptr<LM::Frontend::AST::Expression> pattern, std::unordered_set<std::string>& matched) {
    if (!pattern) return;
    if (auto member = std::dynamic_pointer_cast<LM::Frontend::AST::MemberExpr>(pattern)) {
        matched.insert(member->name);
    } else if (auto binding = std::dynamic_pointer_cast<LM::Frontend::AST::BindingPatternExpr>(pattern)) {
        std::string typeName = binding->typeName;
        size_t last_dot = typeName.find_last_of('.');
        if (last_dot != std::string::npos) {
            matched.insert(typeName.substr(last_dot + 1));
        } else {
            matched.insert(typeName);
        }
    } else if (auto or_pat = std::dynamic_pointer_cast<LM::Frontend::AST::OrPatternExpr>(pattern)) {
        for (const auto& p : or_pat->patterns) {
            collect_matched_variants(p, matched);
        }
    }
}

TypePtr TypeChecker::check_match_statement(std::shared_ptr<LM::Frontend::AST::MatchStatement> match_stmt) {
    if (!match_stmt) return nullptr;
    
    // Check the matched expression
    TypePtr matchType = check_expression(match_stmt->value);
    TypePtr unified_branch_type = nullptr;

    // Check each case
    for (auto& matchCase : match_stmt->cases) {
        enter_scope();

        // Validate pattern compatibility and register bindings
        matchCase.pattern->inferred_type = matchType;
        validate_pattern_compatibility(matchCase.pattern, matchType, match_stmt->line);

        // Check guard if present
        if (matchCase.guard) {
            TypePtr guardType = check_expression(matchCase.guard);
            if (!is_boolean_type(guardType) && guardType->tag != TypeTag::Any) {
                add_error("Match guard must be a boolean expression", match_stmt->line);
            }
        }
        
        // Check case body
        TypePtr branch_type = check_statement(matchCase.body);
        
        // Mandate 2: All branches must resolve to a single unified type
        if (!unified_branch_type) {
            unified_branch_type = branch_type;
        } else if (branch_type) {
            try {
                unified_branch_type = type_system.getCommonType(unified_branch_type, branch_type);
            } catch (const std::exception& e) {
                add_error("Match branch type mismatch: " + std::string(e.what()), match_stmt->line);
            }
        }
        
        exit_scope();
    }

    TypePtr result_type = unified_branch_type ? unified_branch_type : type_system.NIL_TYPE;
    match_stmt->inferred_type = result_type;
    
    // Convert cases to shared_ptr vector for function calls
    std::vector<std::shared_ptr<LM::Frontend::AST::MatchCase>> case_ptrs;
    case_ptrs.reserve(match_stmt->cases.size());
    for (const auto& case_item : match_stmt->cases) {
        case_ptrs.push_back(std::make_shared<LM::Frontend::AST::MatchCase>(case_item));
    }
    
    // Enhanced exhaustiveness checking for different type categories
    if (is_error_union_type(matchType)) {
        if (!is_exhaustive_error_match(case_ptrs, matchType)) {
            auto* errorUnionPtr = std::get_if<ErrorUnionType>(&matchType->extra);
            if (!errorUnionPtr) {
                throw std::runtime_error("Missing ErrorUnionType data in ErrorUnion type");
            }
            auto& errorUnion = *errorUnionPtr;
            
            if (errorUnion.isGenericError) {
                add_error("Match statement is not exhaustive for error union type. Must handle both success case (val pattern) and error case (err pattern)", 
                        match_stmt->line);
            } else {
                std::string missingPatterns = "Must handle success case (val pattern) and all error types: [" + 
                                            join_error_types(errorUnion.errorTypes) + "]";
                add_error("Match statement is not exhaustive for error union type. " + missingPatterns, 
                        match_stmt->line);
            }
        }
    } else if (is_union_type(matchType)) {
        // Union type exhaustiveness checking
        if (!is_exhaustive_union_match(matchType, case_ptrs)) {
            std::string missingVariants = get_missing_union_variants(matchType, case_ptrs);
            add_error("Match statement is not exhaustive for union type " + matchType->toString() + 
                    ". Missing patterns for: " + missingVariants, match_stmt->line);
        }
    } else if (type_system.isOptionType(matchType)) {
        // Option type exhaustiveness checking
        if (!is_exhaustive_option_match(case_ptrs)) {
            add_error("Match statement is not exhaustive for Option type. Must handle both Some and None cases", 
                        match_stmt->line);
        }
    } else if (matchType->tag == TypeTag::Enum) {
        // Enum type exhaustiveness checking
        bool has_catch_all = false;
        for (const auto& case_item : match_stmt->cases) {
            if (is_catch_all_pattern(case_item.pattern)) {
                has_catch_all = true;
                break;
            }
        }

        if (!has_catch_all) {
            auto* enumInfoPtr = std::get_if<EnumType>(&matchType->extra);
            if (enumInfoPtr) {
                std::unordered_set<std::string> matched_variants;
                for (const auto& case_item : match_stmt->cases) {
                    collect_matched_variants(case_item.pattern, matched_variants);
                }

                std::vector<std::string> missing;
                for (const auto& val : enumInfoPtr->values) {
                    if (matched_variants.find(val) == matched_variants.end()) {
                        missing.push_back(val);
                    }
                }

                if (!missing.empty()) {
                    std::string missing_str = "";
                    for (size_t i = 0; i < missing.size(); ++i) {
                        if (i > 0) missing_str += ", ";
                        missing_str += missing[i];
                    }
                    add_error("pattern_exhaustive: Match statement is not exhaustive for Enum type '" + enumInfoPtr->name + "'. Missing patterns: [" + missing_str + "]", match_stmt->line);
                }
            }
        }
    } else if (is_integer_type(matchType) || is_numeric_type(matchType) || is_string_type(matchType)) {
        // Integer and primitive matches require a catch-all wildcard
        bool has_catch_all = false;
        for (const auto& case_item : match_stmt->cases) {
            if (is_catch_all_pattern(case_item.pattern)) {
                has_catch_all = true;
                break;
            }
        }

        if (!has_catch_all) {
            add_error("pattern_exhaustive: Match statement is not exhaustive for type '" + matchType->toString() + "'. A wildcard pattern (_) or default branch is required", match_stmt->line);
        }
    }
    
    return result_type;
}

void TypeChecker::register_builtin_function(const std::string& name, 
                                            const std::vector<TypePtr>& param_types,
                                            TypePtr return_type) {
    FunctionSignature sig;
    sig.name = name;
    sig.param_types = param_types;
    sig.return_type = return_type;
    sig.declaration = nullptr; // Builtin functions have no declaration
    
    function_signatures[name] = sig;
    TypePtr func_type = type_system.createFunctionType(sig.param_types, sig.return_type);
    declare_variable(name, func_type);
    variable_types[name] = func_type;
}

// =============================================================================
// FRAME DECLARATION AND INSTANTIATION TYPE CHECKING
// =============================================================================

TypePtr TypeChecker::check_trait_declaration(std::shared_ptr<LM::Frontend::AST::TraitDeclaration> trait) {
    if (!trait) return nullptr;

    if (trait->hasExplicitVisibility) {
        add_error("`trait` declarations cannot have a visibility modifier (`trait` is already public by default)", trait->line);
    }

    TraitInfo trait_info;
    trait_info.name = trait->name;
    trait_info.extends = trait->extends;
    trait_info.declaration = trait;

    // Resolve parent traits
    for (const auto& parent_name : trait->extends) {
        if (trait_declarations.find(parent_name) == trait_declarations.end()) {
            add_error("Unknown parent trait: " + parent_name, trait->line);
        }
    }

    // Register methods
    for (const auto& method : trait->methods) {
        std::string method_name = trait->name + "." + method->name;
        FunctionSignature signature;
        signature.name = method_name;
        signature.return_type = method->returnType ? resolve_type_annotation(method->returnType.value()) : type_system.NIL_TYPE;
        
        // Traits are like frames in that they have a 'this' pointer for their methods
        // but it's a polymorphic 'this' (the frame that implements the trait)
        signature.param_types.push_back(type_system.ANY_TYPE); // 'this'
        
        for (const auto& param : method->params) {
            signature.param_types.push_back(resolve_type_annotation(param.second));
        }
        function_signatures[method_name] = signature;
    }

    trait_declarations[trait->name] = trait_info;
    
        TypePtr trait_type = std::make_shared<::Type>(TypeTag::Trait);
    TraitType trait_extra;
    trait_extra.name = trait->name;
    trait_extra.extends = trait->extends;
    for (const auto& method : trait->methods) {
        TypePtr ret_type = method->returnType ? resolve_type_annotation(method->returnType.value()) : type_system.NIL_TYPE;
        trait_extra.methodSignatures.push_back({method->name, ret_type});
    }
    trait_type->extra = trait_extra;
    type_system.addUserDefinedType(trait->name, trait_type);
    trait->inferred_type = trait_type;
    
    return trait_type;
}

TypePtr TypeChecker::check_mixin_declaration(std::shared_ptr<LM::Frontend::AST::MixinDeclaration> mixin) {
    if (!mixin) return nullptr;
    mixin_declarations[mixin->name] = mixin;
    mixin->inferred_type = type_system.NIL_TYPE;
    return type_system.NIL_TYPE;
}

TypePtr TypeChecker::check_frame_declaration(std::shared_ptr<LM::Frontend::AST::FrameDeclaration> frame) {
    return check_frame_declaration_with_name(frame->name, frame);
}

TypePtr TypeChecker::check_frame_declaration_with_name(const std::string& name, std::shared_ptr<LM::Frontend::AST::FrameDeclaration> frame) {
    if (!frame) return nullptr;

    if (frame->hasExplicitVisibility) {
        add_error("`frame` declarations cannot have a visibility modifier (`frame` is already public by default)", frame->line);
    }

    // Inject mixins into frame fields and methods
    for (const auto& mixin_name : frame->mixins) {
        auto mixin_it = mixin_declarations.find(mixin_name);
        if (mixin_it != mixin_declarations.end()) {
            const auto& mixin_decl = mixin_it->second;
            for (const auto& field : mixin_decl->fields) {
                frame->fields.push_back(field);
            }
            for (const auto& method : mixin_decl->methods) {
                frame->methods.push_back(method);
            }
        } else {
            add_error("Unknown mixin '" + mixin_name + "' included in frame '" + frame->name + "'", frame->line);
        }
    }

    // Strict `:` trait validation (reject frame inheritance)
    for (const auto& trait_name : frame->implements) {
        if (frame_declarations.count(trait_name) && trait_declarations.count(trait_name) == 0) {
            add_error("Cannot extend frame '" + trait_name + "'. Lymar is a pure composition language; frame inheritance has been eliminated. Use traits, mixins, or embedding instead.", frame->line);
        }
    }
    
    size_t initial_error_count = errors.size();

    // Set current frame context
    auto prev_frame = current_frame;
    current_frame = frame;
    
    // Create frame info for tracking
    FrameInfo frame_info;
    frame_info.name = name;
    frame_info.declaration = frame;
    
    // Verify trait implementations recursively
    std::vector<std::string> trait_worklist = frame->implements;
    std::unordered_set<std::string> visited_traits;

    while (!trait_worklist.empty()) {
        std::string trait_name = trait_worklist.back();
        trait_worklist.pop_back();

        if (visited_traits.count(trait_name)) continue;
        visited_traits.insert(trait_name);

        auto it = trait_declarations.find(trait_name);
        if (it == trait_declarations.end()) {
            add_error("Frame '" + frame->name + "' implements unknown trait: " + trait_name, frame->line);
            continue;
        }

        const auto& trait_info = it->second;
        for (const auto& trait_method : trait_info.declaration->methods) {
            // Check if frame implements this method
            bool implemented = false;
            for (const auto& frame_method : frame->methods) {
                if (frame_method->name == trait_method->name) {
                    implemented = true;
                    break;
                }
            }
            
            if (!implemented) {
                // Check if trait has default implementation
                if (trait_method->body && !trait_method->body->statements.empty()) {
                    // It has a default implementation, we're good
                } else {
                    add_error("Frame '" + frame->name + "' does not implement required trait method: " + trait_method->name, frame->line);
                }
            }
        }

        // Add parent traits to verify them too
        trait_worklist.reserve(trait_worklist.size() + trait_info.extends.size());
        for (const auto& parent : trait_info.extends) {
            trait_worklist.push_back(parent);
        }
    }

    // Process anonymous field embedding (`embed TypeName;`)
    for (const auto& embed_stmt : frame->embeds) {
        auto embedded_it = frame_declarations.find(embed_stmt->typeName);
        if (embedded_it != frame_declarations.end()) {
            const auto& embedded_info = embedded_it->second;
            for (const auto& [efield_name, efield_type] : embedded_info.fields) {
                frame_info.fields.push_back({efield_name, efield_type});
                frame_info.field_has_default.push_back({efield_name, true});
            }
            if (embedded_info.declaration) {
                for (const auto& efield : embedded_info.declaration->fields) {
                    bool exists = false;
                    for (const auto& existing : frame->fields) {
                        if (existing->name == efield->name) { exists = true; break; }
                    }
                    if (!exists) frame->fields.push_back(efield);
                }
            }
        } else {
            auto mixin_it = mixin_declarations.find(embed_stmt->typeName);
            if (mixin_it != mixin_declarations.end()) {
                const auto& mixin_decl = mixin_it->second;
                for (const auto& field : mixin_decl->fields) {
                    TypePtr ftype = resolve_type_annotation(field->type);
                    frame_info.fields.push_back({field->name, ftype});
                    frame_info.field_has_default.push_back({field->name, field->defaultValue != nullptr});
                    bool exists = false;
                    for (const auto& existing : frame->fields) {
                        if (existing->name == field->name) { exists = true; break; }
                    }
                    if (!exists) frame->fields.push_back(field);
                }
                for (const auto& method : mixin_decl->methods) {
                    bool exists = false;
                    for (const auto& existing : frame->methods) {
                        if (existing->name == method->name) { exists = true; break; }
                    }
                    if (!exists) frame->methods.push_back(method);
                }
            } else {
                add_error("Unknown type '" + embed_stmt->typeName + "' in embed statement", frame->line);
            }
        }
    }

    // Check all fields
    for (const auto& field : frame->fields) {
        if (!field) continue;
        
        // Resolve field type
        TypePtr field_type = nullptr;
        if (field->type) {
            field_type = resolve_type_annotation(field->type);
        } else {
            add_error("Frame field '" + field->name + "' must have a type annotation", frame->line);
            field_type = type_system.ANY_TYPE;
        }
        
        // Check if field has a default value
        bool has_default = (field->defaultValue != nullptr);
        
        // If field has default value, check its type
        if (has_default) {
            TypePtr default_type = check_expression(field->defaultValue);
            if (!is_type_compatible(field_type, default_type)) {
                add_type_error(field_type->toString(), default_type->toString(), frame->line);
            }
        }
        
        // Store field info
        frame_info.fields.push_back({field->name, field_type});
        frame_info.field_has_default.push_back({field->name, has_default});
    }
    
    // Store frame info BEFORE checking methods so they can reference the frame
    frame_declarations[name] = frame_info;
    
    // Create a frame type
    TypePtr frame_type = type_system.createFrameType(name);
    frame->inferred_type = frame_type;
    
    // Declare the frame name as a type in the current scope
    declare_variable(name, frame_type);
    
    // Check init() method if present
    if (frame->init) {
        // Type check init method
        // Init methods are like regular methods but called during instantiation
        enter_scope();
        
        // Declare parameters
        for (const auto& param : frame->init->parameters) {
            TypePtr param_type = resolve_type_annotation(param.second);
            declare_variable(param.first, param_type);
        }
        
        // Check optional parameters
        for (const auto& opt_param : frame->init->optionalParams) {
            TypePtr param_type = resolve_type_annotation(opt_param.second.first);
            declare_variable(opt_param.first, param_type);
            
            // Check default value if present
            if (opt_param.second.second) {
                TypePtr default_type = check_expression(opt_param.second.second);
                if (!is_type_compatible(param_type, default_type)) {
                    add_type_error(param_type->toString(), default_type->toString(), frame->line);
                }
            }
        }
        
        auto prev_return_type = current_return_type;
        current_return_type = type_system.NIL_TYPE;

        // Check init body
        if (frame->init->body) {
            check_statement(frame->init->body);
        }
        
        current_return_type = prev_return_type;
        exit_scope();
    }
    
    // Check deinit() method if present
    if (frame->deinit) {
        // Type check deinit method
        // Deinit methods should have no parameters
        if (!frame->deinit->parameters.empty() || !frame->deinit->optionalParams.empty()) {
            add_error("deinit() method cannot have parameters", frame->line);
        }
        
        // Check deinit body
        if (frame->deinit->body) {
            enter_scope();
            auto prev_return_type = current_return_type;
            current_return_type = type_system.NIL_TYPE;
            check_statement(frame->deinit->body);
            current_return_type = prev_return_type;
            exit_scope();
        }
    }
    
    // Check other methods
    for (const auto& method : frame->methods) {
        if (!method) continue;
        
        enter_scope();
        
        // Declare parameters
        for (const auto& param : method->parameters) {
            TypePtr param_type = resolve_type_annotation(param.second);
            declare_variable(param.first, param_type);
        }
        
        // Check optional parameters
        for (const auto& opt_param : method->optionalParams) {
            TypePtr param_type = resolve_type_annotation(opt_param.second.first);
            declare_variable(opt_param.first, param_type);
            
            // Check default value if present
            if (opt_param.second.second) {
                TypePtr default_type = check_expression(opt_param.second.second);
                if (!is_type_compatible(param_type, default_type)) {
                    add_type_error(param_type->toString(), default_type->toString(), frame->line);
                }
            }
        }
        
        // Set the return type of the method for return statements checked within its body
        TypePtr return_type = method->returnType ? resolve_type_annotation(method->returnType) : type_system.NIL_TYPE;
        auto prev_return_type = current_return_type;
        current_return_type = return_type;

        // Check method body
        if (method->body) {
            check_statement(method->body);
        }
        
        current_return_type = prev_return_type;
        exit_scope();
    }
    
    // Restore previous frame context
    current_frame = prev_frame;
    
    if (errors.size() > initial_error_count) {
        failed_frames.insert(name);
    }

    return frame_type;
}

TypePtr TypeChecker::check_frame_instantiation_expr(std::shared_ptr<LM::Frontend::AST::FrameInstantiationExpr> expr) {
    if (!expr) return nullptr;
    
    // Look up the frame declaration
    auto frame_it = frame_declarations.find(expr->frameName);
    if (frame_it == frame_declarations.end()) {
        add_error("Unknown frame type: " + expr->frameName, expr->line);
        return type_system.ANY_TYPE;
    }
    
    const FrameInfo& frame_info = frame_it->second;
    

    // Use the qualified name from frame_declarations (which is the actual registered name)
    // This ensures module frames use their full qualified name (e.g., test_module_frame.Counter)
    std::string frame_qualified_name = frame_info.name;
    
    
    
    // Track which fields are initialized
    std::vector<std::string> initialized_fields;
    
    
    // Check that all required fields are provided
    std::set<std::string> provided_fields;
    
    // Check positional arguments (if any)
    if (!expr->positionalArgs.empty()) {
        add_error("Frame instantiation does not support positional arguments. Use named arguments: " + 
                 expr->frameName + "(field1=value1, field2=value2)", expr->line);
    }
    
    // Check named arguments
    for (const auto& [field_name, field_value] : expr->namedArgs) {
        // Check if field exists in frame
        bool field_found = false;
        TypePtr expected_type = nullptr;
        
        for (size_t i = 0; i < frame_info.fields.size(); ++i) {
            if (frame_info.fields[i].first == field_name) {
                field_found = true;
                expected_type = frame_info.fields[i].second;
                break;
            }
        }
        
        if (!field_found) {
            add_error("Frame '" + expr->frameName + "' has no field named '" + field_name + "'", expr->line);
            continue;
        }
        
        // ===== NEW: CHECK FIELD TYPE SAFETY =====
        
        // Check field value type
        TypePtr actual_type = check_expression(field_value);
        if (!is_type_compatible(expected_type, actual_type)) {
            add_type_error(expected_type->toString(), actual_type->toString(), expr->line);
        }
        
        provided_fields.insert(field_name);
        initialized_fields.push_back(field_name);
    }
    
    // Check that all required fields (those without defaults) are provided
    for (size_t i = 0; i < frame_info.fields.size(); ++i) {
        const std::string& field_name = frame_info.fields[i].first;
        bool has_default = frame_info.field_has_default[i].second;
        
        if (!has_default && provided_fields.find(field_name) == provided_fields.end()) {
            add_error("Frame instantiation missing required field: '" + field_name + "'", expr->line);
        }
    }
    
    
    // Verify all non-optional fields initialized
    verify_frame_full_initialization(expr->frameName, initialized_fields, expr->line);
    
    
    // Return the frame type using the qualified name
    TypePtr frame_type = type_system.createFrameType(frame_qualified_name);
    expr->inferred_type = frame_type;
    
    return frame_type;
}

// Helper: Collect all function dependencies (functions called by a function)
static std::set<std::string> collect_function_dependencies(
    const std::shared_ptr<LM::Frontend::AST::FunctionDeclaration>& func,
    const std::unordered_map<std::string, std::shared_ptr<LM::Frontend::AST::FunctionDeclaration>>& all_functions) {
    
    std::set<std::string> dependencies;
    if (!func || !func->body) return dependencies;
    
    // Walk the AST and find all function calls
    std::function<void(const std::shared_ptr<LM::Frontend::AST::Statement>&)> visit_stmt = 
        [&](const std::shared_ptr<LM::Frontend::AST::Statement>& stmt) {
            if (!stmt) return;
            
            // Check if it's an expression statement
            if (auto expr_stmt = std::dynamic_pointer_cast<LM::Frontend::AST::ExprStatement>(stmt)) {
                // Visit the expression
                std::function<void(const std::shared_ptr<LM::Frontend::AST::Expression>&)> visit_expr = 
                    [&](const std::shared_ptr<LM::Frontend::AST::Expression>& expr) {
                        if (!expr) return;
                        
                        // Check for function calls
                        if (auto call = std::dynamic_pointer_cast<LM::Frontend::AST::CallExpr>(expr)) {
                            if (auto var = std::dynamic_pointer_cast<LM::Frontend::AST::VariableExpr>(call->callee)) {
                                if (all_functions.find(var->name) != all_functions.end()) {
                                    dependencies.insert(var->name);
                                }
                            }
                            // Visit arguments
                            for (const auto& arg : call->arguments) {
                                visit_expr(arg);
                            }
                        }
                        // Recursively visit sub-expressions
                        else if (auto binary = std::dynamic_pointer_cast<LM::Frontend::AST::BinaryExpr>(expr)) {
                            visit_expr(binary->left);
                            visit_expr(binary->right);
                        }
                        else if (auto unary = std::dynamic_pointer_cast<LM::Frontend::AST::UnaryExpr>(expr)) {
                            visit_expr(unary->right);
                        }
                    };
                visit_expr(expr_stmt->expression);
            }
            // Recursively visit block statements
            else if (auto block = std::dynamic_pointer_cast<LM::Frontend::AST::BlockStatement>(stmt)) {
                for (const auto& s : block->statements) {
                    visit_stmt(s);
                }
            }
            else if (auto if_stmt = std::dynamic_pointer_cast<LM::Frontend::AST::IfStatement>(stmt)) {
                visit_stmt(if_stmt->thenBranch);
                if (if_stmt->elseBranch) {
                    visit_stmt(if_stmt->elseBranch);
                }
            }
            else if (auto while_stmt = std::dynamic_pointer_cast<LM::Frontend::AST::WhileStatement>(stmt)) {
                visit_stmt(while_stmt->body);
            }
            else if (auto for_stmt = std::dynamic_pointer_cast<LM::Frontend::AST::ForStatement>(stmt)) {
                visit_stmt(for_stmt->body);
            }
        };
    
    // Visit all statements in the function body
    for (const auto& stmt : func->body->statements) {
        visit_stmt(stmt);
    }
    
    return dependencies;
}

// Helper: Recursively collect all dependencies (transitive closure)
static std::set<std::string> collect_all_dependencies(
    const std::string& symbol_name,
    const std::unordered_map<std::string, std::shared_ptr<LM::Frontend::AST::FunctionDeclaration>>& all_functions,
    std::set<std::string>& visited) {
    
    std::set<std::string> all_deps;
    if (visited.find(symbol_name) != visited.end()) {
        return all_deps;  // Already processed
    }
    visited.insert(symbol_name);
    
    auto it = all_functions.find(symbol_name);
    if (it == all_functions.end()) {
        return all_deps;  // Not a function
    }
    
    // Get direct dependencies
    auto direct_deps = collect_function_dependencies(it->second, all_functions);
    all_deps.insert(direct_deps.begin(), direct_deps.end());
    
    // Recursively get dependencies of dependencies
    for (const auto& dep : direct_deps) {
        auto transitive = collect_all_dependencies(dep, all_functions, visited);
        all_deps.insert(transitive.begin(), transitive.end());
    }
    
    return all_deps;
}

TypePtr TypeChecker::check_import_statement(std::shared_ptr<LM::Frontend::AST::ImportStatement> import_stmt) {
    if (!import_stmt) return nullptr;
    auto& manager = ModuleManager::getInstance();
    auto module = manager.load_module(import_stmt->modulePath);
    if (!module) {
        std::string mod_path = import_stmt->modulePath;
        std::string dir_path = mod_path;
        if (dir_path.ends_with(".index")) {
            dir_path = dir_path.substr(0, dir_path.length() - 6);
        }
        std::replace(dir_path.begin(), dir_path.end(), '.', '/');

        std::string msg;
        if (fs::exists(dir_path) && fs::is_directory(dir_path)) {
            msg = "module `" + mod_path + "` was found, but its entry module could not be loaded";
            msg += "\n\n= reason: expected `" + dir_path + "/index.lm`";
            msg += "\n= help: check that the module contains a valid entry file";
        } else {
            std::vector<std::string> candidates = get_all_available_modules();
            std::string suggestion = find_similar_name(mod_path, candidates);

            msg = "cannot find module `" + mod_path + "`";
            msg += "\n\n= reason: module was not found in import paths";
            if (!suggestion.empty()) {
                msg += "\n= help: did you mean `" + suggestion + "`?";
            } else {
                msg += "\n= help: check that the module exists and that the import path is correct";
            }
        }
        add_error(msg, import_stmt->line);
        return nullptr;
    }

    if (import_stmt->filter && import_stmt->filter->type == LM::Frontend::AST::ImportFilterType::Show) {
        for (const auto& identifier : import_stmt->filter->identifiers) {
            if (!module->public_symbols.count(identifier)) {
                add_error(
                    "Import filter references unknown symbol '" + identifier +
                    "' in module '" + import_stmt->modulePath + "'",
                    import_stmt->line
                );
            }
        }
    }

    auto symbols_to_import = manager.filter_symbols(module, import_stmt->filter);
    std::string alias = import_stmt->alias ? import_stmt->alias.value() : "";
    if (alias.empty()) {
        size_t last_dot = import_stmt->modulePath.find_last_of('.');
        alias = (last_dot != std::string::npos) ? import_stmt->modulePath.substr(last_dot + 1) : import_stmt->modulePath;
    }
    import_aliases[alias] = import_stmt->modulePath;
    
    // Create a pseudo-frame for the module namespace
    FrameInfo alias_info; 
    alias_info.name = alias;
    frame_declarations[alias] = alias_info;
    declare_variable(alias, type_system.createFrameType(alias));
    
    // Register all symbols from the module
    std::vector<std::shared_ptr<LM::Frontend::AST::Statement>> module_declarations(
        module->ast->statements.begin(), module->ast->statements.end());
    module_declarations.insert(module_declarations.end(), module->reexports.begin(), module->reexports.end());
    for (const auto& stmt : module_declarations) {
        std::string name;
        if (auto f = std::dynamic_pointer_cast<LM::Frontend::AST::FunctionDeclaration>(stmt)) name = f->name;
        else if (auto fr = std::dynamic_pointer_cast<LM::Frontend::AST::FrameDeclaration>(stmt)) name = fr->name;
        else if (auto v = std::dynamic_pointer_cast<LM::Frontend::AST::VarDeclaration>(stmt)) name = v->name;
        else if (auto t = std::dynamic_pointer_cast<LM::Frontend::AST::TraitDeclaration>(stmt)) name = t->name;
        else if (auto td = std::dynamic_pointer_cast<LM::Frontend::AST::TypeDeclaration>(stmt)) name = td->name;
        
        // Import all public symbols if no filter, or only filtered symbols
        bool should_import = symbols_to_import.empty() || symbols_to_import.count(name);
        if (!name.empty() && should_import) {
            std::vector<std::pair<std::string, bool>> target_names;
            // Qualified name: alias.name
            target_names.push_back({alias + "." + name, true});
            // Unqualified name: name (if no filter or explicit show)
            if (!import_stmt->filter.has_value() || (import_stmt->filter->type == LM::Frontend::AST::ImportFilterType::Show && symbols_to_import.count(name))) {
                target_names.push_back({name, true});
            }

            std::string full_path_base = import_stmt->modulePath + "." + name;

            // Always include full module path in targets for unified lookup
            bool already_has_full = false;
            for(auto& t : target_names) if(t.first == full_path_base) already_has_full = true;
            if(!already_has_full) target_names.push_back({full_path_base, true});

            for (const auto& target : target_names) {
                const std::string& qname = target.first;
                
                if (auto f = std::dynamic_pointer_cast<LM::Frontend::AST::FunctionDeclaration>(stmt)) {
                    FunctionSignature sig; 
                    if (function_signatures.count(full_path_base)) {
                        sig = function_signatures[full_path_base];
                        sig.name = qname;
                        sig.declaration = f;
                    } else {
                        sig.name = qname; 
                        sig.declaration = f;
                        TypePtr ret_t = nullptr;
                        if (f->returnType.has_value()) {
                            ret_t = resolve_type_annotation(f->returnType.value());
                            if (!ret_t || ret_t->tag == TypeTag::Nil) {
                                ret_t = type_system.getType(import_stmt->modulePath + "." + f->returnType.value()->typeName);
                            }
                            if (!ret_t || ret_t->tag == TypeTag::Nil) {
                                ret_t = type_system.getType(alias + "." + f->returnType.value()->typeName);
                            }
                        }
                        sig.return_type = (f->name == "main") ? type_system.INT64_TYPE : (ret_t ? ret_t : type_system.ANY_TYPE);
                        sig.can_fail = f->canFail || f->throws;
                        sig.error_types = f->declaredErrorTypes;
                        
                        for (const auto& p : f->params) {
                            TypePtr pt = p.second ? resolve_type_annotation(p.second) : nullptr;
                            if (!pt || pt->tag == TypeTag::Nil) {
                                if (p.second) pt = type_system.getType(import_stmt->modulePath + "." + p.second->typeName);
                            }
                            sig.param_types.push_back(pt ? pt : type_system.ANY_TYPE);
                            sig.optional_params.push_back(false);
                            sig.has_default_values.push_back(false);
                        }
                        for (const auto& op : f->optionalParams) {
                            TypePtr pt = op.second.first ? resolve_type_annotation(op.second.first) : nullptr;
                            if (!pt || pt->tag == TypeTag::Nil) {
                                if (op.second.first) pt = type_system.getType(import_stmt->modulePath + "." + op.second.first->typeName);
                            }
                            sig.param_types.push_back(pt ? pt : type_system.ANY_TYPE);
                            sig.optional_params.push_back(true);
                            sig.has_default_values.push_back(op.second.second != nullptr);
                        }
                    }

                    std::vector<std::string> param_names;
                    for (size_t pi = 0; pi < sig.param_types.size(); ++pi) {
                        if (pi < f->params.size()) param_names.push_back(f->params[pi].first);
                        else if (pi - f->params.size() < f->optionalParams.size()) param_names.push_back(f->optionalParams[pi - f->params.size()].first);
                        else param_names.push_back("");
                    }
                    
                    function_signatures[qname] = sig;
                    declare_variable(qname, type_system.createFunctionType(param_names, sig.param_types, sig.return_type, sig.has_default_values));
                    
                    // Register in imported symbols so LIR generator can find it
                    current_program_->imported_symbols[qname] = f;
                } else if (auto td = std::dynamic_pointer_cast<LM::Frontend::AST::TypeDeclaration>(stmt)) {
                    TypePtr underlying = td->inferred_type;
                    if (!underlying || underlying->tag == TypeTag::Nil) {
                        underlying = type_system.getType(full_path_base);
                    }
                    if (!underlying || underlying->tag == TypeTag::Nil) {
                        underlying = resolve_type_annotation(td->type);
                    }
                    if (!underlying || underlying->tag == TypeTag::Nil) {
                        underlying = type_system.getType(import_stmt->modulePath + "." + td->type->typeName);
                    }
                    if (underlying && underlying->tag != TypeTag::Nil) {
                        try {
                            type_system.registerTypeAlias(qname, underlying);
                        } catch (...) {}
                        type_system.addUserDefinedType(qname, underlying);
                        if (underlying->tag == TypeTag::Frame) {
                            if (auto* fd = std::get_if<FrameType>(&underlying->extra)) {
                                auto it = frame_declarations.find(fd->name);
                                if (it != frame_declarations.end()) {
                                    frame_declarations[qname] = it->second;
                                }
                            }
                        }
                    }
                } else if (auto v = std::dynamic_pointer_cast<LM::Frontend::AST::VarDeclaration>(stmt)) {
                    std::string reexported_mod_path;
                    if (v->initializer) {
                        if (auto var_init = std::dynamic_pointer_cast<LM::Frontend::AST::VariableExpr>(v->initializer)) {
                            for (const auto& s : module->ast->statements) {
                                if (auto imp = std::dynamic_pointer_cast<LM::Frontend::AST::ImportStatement>(s)) {
                                    std::string imp_alias = imp->alias ? imp->alias.value() : "";
                                    if (imp_alias.empty()) {
                                        size_t dot = imp->modulePath.find_last_of('.');
                                        imp_alias = (dot != std::string::npos) ? imp->modulePath.substr(dot + 1) : imp->modulePath;
                                    }
                                    if (imp_alias == var_init->name) {
                                        reexported_mod_path = imp->modulePath;
                                        break;
                                    }
                                }
                            }
                        }
                    }

                    if (!reexported_mod_path.empty()) {
                        import_aliases[qname] = reexported_mod_path;
                        FrameInfo alias_info;
                        alias_info.name = qname;
                        frame_declarations[qname] = alias_info;
                        TypePtr frame_type = type_system.createFrameType(qname);
                        type_system.addUserDefinedType(qname, frame_type);
                        declare_variable(qname, frame_type);
                        variable_types[qname] = frame_type;
                        current_program_->imported_symbols[qname] = v;

                        auto reexp_mod = manager.load_module(reexported_mod_path);
                        if (reexp_mod && reexp_mod->ast) {
                            for (const auto& rstmt : reexp_mod->ast->statements) {
                                if (auto rf = std::dynamic_pointer_cast<LM::Frontend::AST::FunctionDeclaration>(rstmt)) {
                                    if (rf->visibility == LM::Frontend::AST::VisibilityLevel::Public) {
                                        std::string sub_qname = qname + "." + rf->name;
                                        FunctionSignature sig;
                                        sig.name = sub_qname;
                                        sig.declaration = rf;
                                        sig.return_type = (rf->name == "main") ? type_system.INT64_TYPE : (rf->returnType.has_value() 
                                            ? resolve_type_annotation(rf->returnType.value()) 
                                            : type_system.ANY_TYPE);
                                        sig.can_fail = rf->canFail || rf->throws;
                                        sig.error_types = rf->declaredErrorTypes;
                                        std::vector<std::string> param_names;
                                        std::vector<bool> has_defaults;
                                        for (const auto& p : rf->params) {
                                            sig.param_types.push_back(p.second ? resolve_type_annotation(p.second) : type_system.ANY_TYPE);
                                            sig.optional_params.push_back(false);
                                            sig.has_default_values.push_back(false);
                                            param_names.push_back(p.first);
                                            has_defaults.push_back(false);
                                        }
                                        for (const auto& op : rf->optionalParams) {
                                            sig.param_types.push_back(op.second.first ? resolve_type_annotation(op.second.first) : type_system.ANY_TYPE);
                                            sig.optional_params.push_back(true);
                                            sig.has_default_values.push_back(op.second.second != nullptr);
                                            param_names.push_back(op.first);
                                            has_defaults.push_back(op.second.second != nullptr);
                                        }
                                        function_signatures[sub_qname] = sig;
                                        declare_variable(sub_qname, type_system.createFunctionType(param_names, sig.param_types, sig.return_type, has_defaults));
                                        current_program_->imported_symbols[sub_qname] = rf;
                                    }
                                } else if (auto rv = std::dynamic_pointer_cast<LM::Frontend::AST::VarDeclaration>(rstmt)) {
                                    if (rv->visibility == LM::Frontend::AST::VisibilityLevel::Public || rv->isConst) {
                                        std::string sub_qname = qname + "." + rv->name;
                                        std::string orig_full = reexported_mod_path + "." + rv->name;
                                        TypePtr var_type = type_system.ANY_TYPE;
                                        if (rv->type.has_value()) {
                                            var_type = resolve_type_annotation(rv->type.value());
                                        } else if (variable_types.count(orig_full)) {
                                            var_type = variable_types[orig_full];
                                        }
                                        declare_variable(sub_qname, var_type);
                                        variable_types[sub_qname] = var_type;
                                        current_program_->imported_symbols[sub_qname] = rv;
                                    }
                                } else if (auto rfr = std::dynamic_pointer_cast<LM::Frontend::AST::FrameDeclaration>(rstmt)) {
                                    if (rfr->visibility == LM::Frontend::AST::VisibilityLevel::Public) {
                                        std::string sub_qname = qname + "." + rfr->name;
                                        FrameInfo fi;
                                        fi.name = sub_qname;
                                        fi.declaration = rfr;
                                        for (const auto& field : rfr->fields) {
                                            fi.fields.push_back({field->name, resolve_type_annotation(field->type)});
                                        }
                                        frame_declarations[sub_qname] = fi;
                                        TypePtr frame_type = type_system.createFrameType(sub_qname);
                                        type_system.addUserDefinedType(sub_qname, frame_type);
                                        declare_variable(sub_qname, frame_type);
                                        current_program_->imported_symbols[sub_qname] = rfr;
                                        for (const auto& method : rfr->methods) {
                                            std::string m_name = sub_qname + "." + method->name;
                                            FunctionSignature sig;
                                            sig.name = m_name;
                                            sig.declaration = method;
                                            sig.return_type = method->returnType ? resolve_type_annotation(method->returnType) : type_system.NIL_TYPE;
                                            sig.param_types.push_back(type_system.createFrameType(sub_qname));
                                            sig.optional_params.push_back(false);
                                            sig.has_default_values.push_back(false);
                                            for (const auto& p : method->parameters) {
                                                sig.param_types.push_back(p.second ? resolve_type_annotation(p.second) : type_system.ANY_TYPE);
                                                sig.optional_params.push_back(false);
                                                sig.has_default_values.push_back(false);
                                            }
                                            for (const auto& op : method->optionalParams) {
                                                sig.param_types.push_back(op.second.first ? resolve_type_annotation(op.second.first) : type_system.ANY_TYPE);
                                                sig.optional_params.push_back(true);
                                                sig.has_default_values.push_back(op.second.second != nullptr);
                                            }
                                            function_signatures[m_name] = sig;
                                        }
                                        if (rfr->init) {
                                            std::string init_name = sub_qname + ".init";
                                            FunctionSignature sig;
                                            sig.name = init_name;
                                            sig.declaration = rfr->init;
                                            sig.return_type = type_system.createFrameType(sub_qname);
                                            sig.param_types.push_back(type_system.createFrameType(sub_qname));
                                            sig.optional_params.push_back(false);
                                            sig.has_default_values.push_back(false);
                                            for (const auto& p : rfr->init->parameters) {
                                                sig.param_types.push_back(p.second ? resolve_type_annotation(p.second) : type_system.ANY_TYPE);
                                                sig.optional_params.push_back(false);
                                                sig.has_default_values.push_back(false);
                                            }
                                            for (const auto& op : rfr->init->optionalParams) {
                                                sig.param_types.push_back(op.second.first ? resolve_type_annotation(op.second.first) : type_system.ANY_TYPE);
                                                sig.optional_params.push_back(true);
                                                sig.has_default_values.push_back(op.second.second != nullptr);
                                            }
                                            function_signatures[init_name] = sig;
                                        }
                                    }
                                }
                            }
                        }
                    } else {
                        TypePtr var_type = type_system.ANY_TYPE;
                        if (v->type.has_value()) {
                            var_type = resolve_type_annotation(v->type.value());
                        } else if (variable_types.count(full_path_base)) {
                            var_type = variable_types[full_path_base];
                        }
                        declare_variable(qname, var_type);
                        current_program_->imported_symbols[qname] = v;
                    }
                } else if (auto fr = std::dynamic_pointer_cast<LM::Frontend::AST::FrameDeclaration>(stmt)) {
                    FrameInfo fi; 
                    fi.name = qname; 
                    fi.declaration = fr;
                    for (const auto& field : fr->fields) {
                        fi.fields.push_back({field->name, resolve_type_annotation(field->type)});
                    }
                    frame_declarations[qname] = fi;
                    
                    // Create and register the frame type
                    TypePtr frame_type = type_system.createFrameType(qname);
                    type_system.addUserDefinedType(qname, frame_type);
                    type_system.addUserDefinedType(full_path_base, frame_type);
                    type_system.addUserDefinedType(alias + "." + name, frame_type);
                    declare_variable(qname, frame_type);
                    
                    // Register in imported symbols so LIR generator can find it
                    current_program_->imported_symbols[qname] = fr;
                    
                    // Register frame methods (e.g. io.File.read)
                    for (const auto& method : fr->methods) {
                        std::string m_name = qname + "." + method->name;
                        FunctionSignature sig; 
                        sig.name = m_name; 
                        sig.declaration = method;
                        sig.return_type = method->returnType ? resolve_type_annotation(method->returnType) : type_system.NIL_TYPE;
                        sig.param_types.push_back(type_system.createFrameType(qname)); // 'this'
                        sig.optional_params.push_back(false);
                        sig.has_default_values.push_back(false);
                        
                        for (const auto& p : method->parameters) {
                             sig.param_types.push_back(p.second ? resolve_type_annotation(p.second) : type_system.ANY_TYPE);
                             sig.optional_params.push_back(false);
                             sig.has_default_values.push_back(false);
                        }
                        for (const auto& op : method->optionalParams) {
                             sig.param_types.push_back(op.second.first ? resolve_type_annotation(op.second.first) : type_system.ANY_TYPE);
                             sig.optional_params.push_back(true);
                             sig.has_default_values.push_back(op.second.second != nullptr);
                        }
                        function_signatures[m_name] = sig;
                    }
                    if (fr->init) {
                        std::string init_name = qname + ".init";
                        FunctionSignature sig; 
                        sig.name = init_name; 
                        sig.declaration = fr->init;
                        sig.return_type = type_system.createFrameType(qname);
                        sig.param_types.push_back(type_system.createFrameType(qname)); // 'this'
                        sig.optional_params.push_back(false);
                        sig.has_default_values.push_back(false);
                        
                        for (const auto& p : fr->init->parameters) {
                             sig.param_types.push_back(p.second ? resolve_type_annotation(p.second) : type_system.ANY_TYPE);
                             sig.optional_params.push_back(false);
                             sig.has_default_values.push_back(false);
                        }
                        for (const auto& op : fr->init->optionalParams) {
                             sig.param_types.push_back(op.second.first ? resolve_type_annotation(op.second.first) : type_system.ANY_TYPE);
                             sig.optional_params.push_back(true);
                             sig.has_default_values.push_back(op.second.second != nullptr);
                        }
                        function_signatures[init_name] = sig;
                    }
                } else if (auto t = std::dynamic_pointer_cast<LM::Frontend::AST::TraitDeclaration>(stmt)) {
                    TraitInfo ti;
                    ti.name = qname;
                    ti.declaration = t;
                    ti.extends = t->extends;
                    trait_declarations[qname] = ti;
                    
                    // Create and register the trait type
                    TypePtr trait_type = std::make_shared<::Type>(TypeTag::Trait);
                    TraitType trait_extra;
                    trait_extra.name = qname;
                    trait_extra.extends = t->extends;
                    for (const auto& method : t->methods) {
                        TypePtr ret_type = method->returnType ? resolve_type_annotation(method->returnType.value()) : type_system.NIL_TYPE;
                        trait_extra.methodSignatures.push_back({method->name, ret_type});
                    }
                    trait_type->extra = trait_extra;
                    type_system.addUserDefinedType(qname, trait_type);
                    type_system.addUserDefinedType(full_path_base, trait_type);
                    type_system.addUserDefinedType(alias + "." + name, trait_type);
                    declare_variable(qname, trait_type);
                    
                    current_program_->imported_symbols[qname] = t;

                    // Register trait methods
                    for (const auto& method : t->methods) {
                        std::string m_name = qname + "." + method->name;
                        FunctionSignature sig; 
                        sig.name = m_name; 
                        sig.declaration = method;
                        sig.return_type = method->returnType ? resolve_type_annotation(method->returnType.value()) : type_system.ANY_TYPE;
                        sig.param_types.push_back(type_system.ANY_TYPE); // 'this' (polymorphic)
                        sig.optional_params.push_back(false);
                        sig.has_default_values.push_back(false);
                        
                        for (const auto& p : method->params) {
                             sig.param_types.push_back(p.second ? resolve_type_annotation(p.second) : type_system.ANY_TYPE);
                             sig.optional_params.push_back(false);
                             sig.has_default_values.push_back(false);
                        }
                        // Trait methods don't support optionalParams in AST yet, but we're ready
                        function_signatures[m_name] = sig;
                    }
                }
            }
        }
    }

    import_stmt->inferred_type = type_system.NIL_TYPE;
    return type_system.NIL_TYPE;
}

void TypeChecker::verify_frame_full_initialization(
    const std::string& frame_name,
    const std::vector<std::string>& initialized_fields,
    int line) {

    auto frame_it = frame_declarations.find(frame_name);
    if (frame_it == frame_declarations.end()) {
        return;
    }

    const FrameInfo& frame_info = frame_it->second;
    for (size_t i = 0; i < frame_info.fields.size(); ++i) {
        const std::string& field_name = frame_info.fields[i].first;
        bool has_default = frame_info.field_has_default[i].second;

        bool is_initialized = false;
        for (const auto& init_field : initialized_fields) {
            if (init_field == field_name) {
                is_initialized = true;
                break;
            }
        }

        if (!is_initialized && !has_default) {
            add_error("Frame '" + frame_name + "' field '" + field_name +
                     "' must be initialized (no default value)", line);
        }
    }
}

} // namespace Frontend
} // namespace LM
