#include "../type_checker.hh"

using namespace LM::Frontend;

namespace LM {
namespace Frontend {

TypePtr TypeChecker::check_statement(std::shared_ptr<LM::Frontend::AST::Statement> stmt) {
    if (!stmt) return nullptr;
    
    if (auto import_stmt = std::dynamic_pointer_cast<LM::Frontend::AST::ImportStatement>(stmt)) {
        return check_import_statement(import_stmt);
    } else if (auto func_decl = std::dynamic_pointer_cast<LM::Frontend::AST::FunctionDeclaration>(stmt)) {
        return check_function_declaration(func_decl);
    } else if (auto frame_decl = std::dynamic_pointer_cast<LM::Frontend::AST::FrameDeclaration>(stmt)) {
        return check_frame_declaration(frame_decl);
    } else if (auto mixin_decl = std::dynamic_pointer_cast<LM::Frontend::AST::MixinDeclaration>(stmt)) {
        return check_mixin_declaration(mixin_decl);
    } else if (auto trait_decl = std::dynamic_pointer_cast<LM::Frontend::AST::TraitDeclaration>(stmt)) {
        return check_trait_declaration(trait_decl);
    } else if (auto dest_decl = std::dynamic_pointer_cast<LM::Frontend::AST::DestructuringDeclaration>(stmt)) {
        return check_destructuring_declaration(dest_decl);
    } else if (auto var_decl = std::dynamic_pointer_cast<LM::Frontend::AST::VarDeclaration>(stmt)) {
        return check_var_declaration(var_decl);
    } else if (auto type_decl = std::dynamic_pointer_cast<LM::Frontend::AST::TypeDeclaration>(stmt)) {
        return check_type_declaration(type_decl);
    } else if (auto block = std::dynamic_pointer_cast<LM::Frontend::AST::BlockStatement>(stmt)) {
        return check_block_statement(block);
    } else if (auto if_stmt = std::dynamic_pointer_cast<LM::Frontend::AST::IfStatement>(stmt)) {
        return check_if_statement(if_stmt);
    } else if (auto while_stmt = std::dynamic_pointer_cast<LM::Frontend::AST::WhileStatement>(stmt)) {
        return check_while_statement(while_stmt);
    } else if (auto for_stmt = std::dynamic_pointer_cast<LM::Frontend::AST::ForStatement>(stmt)) {
        return check_for_statement(for_stmt);
    } else if (auto iter_stmt = std::dynamic_pointer_cast<LM::Frontend::AST::IterStatement>(stmt)) {
        return check_iter_statement(iter_stmt);
    } else if (auto parallel_stmt = std::dynamic_pointer_cast<LM::Frontend::AST::ParallelStatement>(stmt)) {
        return check_parallel_statement(parallel_stmt);
    } else if (auto concurrent_stmt = std::dynamic_pointer_cast<LM::Frontend::AST::ConcurrentStatement>(stmt)) {
        return check_concurrent_statement(concurrent_stmt);
    } else if (auto task_stmt = std::dynamic_pointer_cast<LM::Frontend::AST::TaskStatement>(stmt)) {
        return check_task_statement(task_stmt);
    } else if (auto worker_stmt = std::dynamic_pointer_cast<LM::Frontend::AST::WorkerStatement>(stmt)) {
        return check_worker_statement(worker_stmt);
    } else if (auto break_stmt = std::dynamic_pointer_cast<LM::Frontend::AST::BreakStatement>(stmt)) {
        return type_system.NIL_TYPE;
    } else if (auto continue_stmt = std::dynamic_pointer_cast<LM::Frontend::AST::ContinueStatement>(stmt)) {
        return type_system.NIL_TYPE;
    } else if (auto return_stmt = std::dynamic_pointer_cast<LM::Frontend::AST::ReturnStatement>(stmt)) {
        return check_return_statement(return_stmt);
    } else if (auto match_stmt = std::dynamic_pointer_cast<LM::Frontend::AST::MatchStatement>(stmt)) {
        return check_match_statement(match_stmt);
    } else if (auto contract_stmt = std::dynamic_pointer_cast<LM::Frontend::AST::ContractStatement>(stmt)) {
        return check_contract_statement(contract_stmt);
    } else if (auto staged_stmt = std::dynamic_pointer_cast<LM::Frontend::AST::StagedStatement>(stmt)) {
        return check_staged_statement(staged_stmt);
    } else if (auto staged_block = std::dynamic_pointer_cast<LM::Frontend::AST::StagedBlockStatement>(stmt)) {
        return check_staged_block_statement(staged_block);
    } else if (auto unsafe_stmt = std::dynamic_pointer_cast<LM::Frontend::AST::UnsafeStatement>(stmt)) {
        bool prev = in_unsafe_block;
        in_unsafe_block = true;
        TypePtr body_res = check_statement(unsafe_stmt->body);
        in_unsafe_block = prev;
        unsafe_stmt->inferred_type = type_system.NIL_TYPE;
        return type_system.NIL_TYPE;
    } else if (auto import_stmt = std::dynamic_pointer_cast<LM::Frontend::AST::ImportStatement>(stmt)) {
        return check_import_statement(import_stmt);
    } else if (auto expr_stmt = std::dynamic_pointer_cast<LM::Frontend::AST::ExprStatement>(stmt)) {
        return check_expression(expr_stmt->expression);
    }
    
    return nullptr;
}

TypePtr TypeChecker::check_function_declaration(std::shared_ptr<LM::Frontend::AST::FunctionDeclaration> func) {
    if (!func) return nullptr;

    if (func->isStaged) {
        add_error("staged functions ('staged fn') are not supported yet", func->line);
    }
    for (bool is_staged : func->stagedParams) {
        if (is_staged) {
            add_error("staged parameters ('staged param') are not supported yet", func->line);
            break;
        }
    }
    
    
    // Resolve return type
    TypePtr return_type = type_system.ANY_TYPE; // Default for unannotated functions
    if (func->name == "main") {
        return_type = type_system.INT64_TYPE;
    } else if (func->returnType) {
        return_type = resolve_type_annotation(func->returnType.value());
    }
    
    // Create function signature with enhanced features
    FunctionSignature signature;
    signature.name = func->name;
    signature.return_type = return_type;
    signature.declaration = func;
    signature.can_fail = func->canFail || func->throws;
    signature.error_types = func->declaredErrorTypes;
    
    // Check parameters
    for (const auto& param : func->params) {
        TypePtr param_type = type_system.ANY_TYPE; // Default for untyped parameters
        if (param.second) {
            param_type = resolve_type_annotation(param.second);
        }
        signature.param_types.push_back(param_type);
        signature.optional_params.push_back(false); // Required parameters are not optional
        signature.has_default_values.push_back(false); // Required parameters don't have defaults
    }
    
    // Check optional parameters
    for (const auto& optional_param : func->optionalParams) {
        TypePtr param_type = type_system.ANY_TYPE; // Default for untyped parameters
        if (optional_param.second.first) {
            param_type = resolve_type_annotation(optional_param.second.first);
        }
        signature.param_types.push_back(param_type);
        signature.optional_params.push_back(true); // These are optional parameters
        signature.has_default_values.push_back(optional_param.second.second != nullptr); // Has default if expression exists
    }
    
    function_signatures[func->name] = signature;
    
    // Validate error type annotations
    validate_function_error_types(func);
    
    // Declare the function name as a variable in the current scope
    // This allows the function to be called by name
    std::vector<std::string> param_names;
    for (const auto& p : func->params) param_names.push_back(p.first);
    for (const auto& op : func->optionalParams) param_names.push_back(op.first);
    
    TypePtr function_type = type_system.createFunctionType(param_names, signature.param_types, return_type, signature.has_default_values);
    declare_variable(func->name, function_type);
    
    // Check function body
    current_function = func;
    current_return_type = return_type;
    enter_scope();
    
    // Declare parameters with memory tracking
    for (size_t i = 0; i < func->params.size(); ++i) {
        declare_variable(func->params[i].first, signature.param_types[i]);
        // Function parameters are initialized when the function is called
    }
    
    // Declare optional parameters with memory tracking
    for (size_t i = 0; i < func->optionalParams.size(); ++i) {
        size_t param_index = func->params.size() + i;
        declare_variable(func->optionalParams[i].first, signature.param_types[param_index]);
        // Function parameters are initialized when the function is called
    }
    
    // Check body
    TypePtr body_type = check_statement(func->body);

    // Infer return type for unannotated non-main functions from body.
    if (func->name != "main" && !func->returnType.has_value() && body_type) {
        return_type = body_type;
        signature.return_type = return_type;
        function_signatures[func->name] = signature;
    }
    
    // Validate function body error types
    validate_function_body_error_types(func);
    
    // Exit scope and memory region
    exit_scope();
    
    current_function = nullptr;
    current_return_type = nullptr;
    
    func->inferred_type = return_type;
    return return_type;
}


TypePtr TypeChecker::check_destructuring_declaration(std::shared_ptr<LM::Frontend::AST::DestructuringDeclaration> dest_decl) {
    if (!dest_decl) return nullptr;
    
    TypePtr init_type = check_expression(dest_decl->initializer);
    if (!init_type) {
        add_error("Failed to determine type of initializer in destructuring declaration", dest_decl->line);
        return nullptr;
    }
    
    if (init_type->tag == TypeTag::Tuple) {
        auto* tuple_type = std::get_if<TupleType>(&init_type->extra);
        if (tuple_type) {
            if (dest_decl->names.size() != tuple_type->elementTypes.size()) {
                add_error("Tuple size mismatch in destructuring: expected " + 
                         std::to_string(tuple_type->elementTypes.size()) + " variables, got " + 
                         std::to_string(dest_decl->names.size()), dest_decl->line);
            }
            
            for (size_t i = 0; i < std::min(dest_decl->names.size(), tuple_type->elementTypes.size()); ++i) {
                declare_variable(dest_decl->names[i], tuple_type->elementTypes[i]);
            }
        }
    } else if (init_type->tag == TypeTag::List) {
        auto* list_type = std::get_if<ListType>(&init_type->extra);
        if (list_type) {
            for (const auto& name : dest_decl->names) {
                declare_variable(name, list_type->elementType);
            }
        }
    } else {
        add_error("Cannot destructure non-tuple/list type: " + init_type->toString(), dest_decl->line);
    }
    
    dest_decl->inferred_type = init_type;
    return init_type;
}
TypePtr TypeChecker::check_var_declaration(std::shared_ptr<LM::Frontend::AST::VarDeclaration> var_decl) {
    if (!var_decl) return nullptr;
    
    TypePtr declared_type = nullptr;
    if (var_decl->type) {
        declared_type = resolve_type_annotation(var_decl->type.value());
    }
    
    TypePtr init_type = nullptr;
    if (var_decl->initializer) {
        // Pass the declared type as expected type for better type inference
        init_type = check_expression_with_expected_type(var_decl->initializer, declared_type);
        
        long long val_int = 0;
        double val_double = 0.0;
        bool is_int = false;
        if (var_decl->isConst && evaluate_const_expr(var_decl->initializer, val_int, val_double, is_int, this)) {
            if (is_int) {
                constant_ints[var_decl->name] = val_int;
            } else {
                constant_doubles[var_decl->name] = val_double;
            }
        }

        // Check if initializing from another variable (potential move or module alias)
        if (auto var_expr = std::dynamic_pointer_cast<LM::Frontend::AST::VariableExpr>(var_decl->initializer)) {
            if (import_aliases.count(var_expr->name)) {
                std::string target_mod = import_aliases[var_expr->name];
                import_aliases[var_decl->name] = target_mod;
                FrameInfo alias_info;
                alias_info.name = var_decl->name;
                frame_declarations[var_decl->name] = alias_info;
                TypePtr mod_frame = type_system.createFrameType(var_decl->name);
                declare_variable(var_decl->name, mod_frame);
                variable_types[var_decl->name] = mod_frame;
                var_decl->inferred_type = mod_frame;
                return mod_frame;
            }

        }
    }
    
    TypePtr final_type = nullptr;
    
    if (declared_type && init_type) {
        // Both declared and initialized - check compatibility
        if (is_type_compatible(declared_type, init_type)) {
            final_type = declared_type;
        } else if (is_string_type(declared_type) && is_string_type(init_type)) {
            // String type identity fix
            final_type = declared_type;
        } else {
            add_type_error(declared_type->toString(), init_type->toString(), var_decl->line);
            final_type = declared_type; // Use declared type anyway
        }

        // Refinements are semantic types, not just aliases over their base type.
        // Discharge the assignment obligation immediately when the native SMT
        // fragment can decide it.  Unknown/unsupported expressions remain
        // eligible for the existing runtime path, but definite violations are
        // rejected at compile time.
        if (declared_type->tag == TypeTag::Refined && var_decl->initializer) {
            if (const auto* refined = std::get_if<RefinedType>(&declared_type->extra)) {
                SMTProofResult proof = SMTVerifier::verify_refinement(
                    refined->condition, var_decl->initializer);
                if (proof.status == SMTProofStatus::Counterexample) {
                    add_error("type mismatch: refinement type violation for variable '" + var_decl->name +
                              "': initializer does not satisfy " + declared_type->toString(),
                              var_decl->line);
                } else if (verification_policy_ == VerificationPolicy::Strict &&
                           proof.status != SMTProofStatus::Proven) {
                    add_error("strict verification could not prove refinement for variable '" +
                              var_decl->name + "': " + proof.message, var_decl->line);
                }
            }
        }
    } else if (declared_type) {
        // Only declared
        final_type = declared_type;
    } else if (init_type) {
        // Only initialized - infer type
        final_type = init_type;
    } else {
        // Neither - error
        add_error("Variable declaration without type or initializer", var_decl->line);
        final_type = type_system.STRING_TYPE; // Default
    }
    
    declare_variable(var_decl->name, final_type, var_decl->isConst);

    // Set the inferred type on the variable declaration statement
    var_decl->inferred_type = final_type;
    
    return final_type;
}

TypePtr TypeChecker::check_type_declaration(std::shared_ptr<LM::Frontend::AST::TypeDeclaration> type_decl) {
    if (!type_decl) return nullptr;
    
    // Resolve the underlying type
    TypePtr underlying_type = resolve_type_annotation(type_decl->type);
    if (!underlying_type) {
        add_error("Failed to resolve type for alias: " + type_decl->name, type_decl->line);
        return nullptr;
    }
    
    // Register the type alias in the type system
    type_system.registerTypeAlias(type_decl->name, underlying_type);
    type_system.addUserDefinedType(type_decl->name, underlying_type);
    if (!current_module_name.empty()) {
        type_system.registerTypeAlias(current_module_name + "." + type_decl->name, underlying_type);
        type_system.addUserDefinedType(current_module_name + "." + type_decl->name, underlying_type);
    }
    
    // If the underlying type is a Frame, propagate FrameInfo to frame_declarations
    if (underlying_type->tag == TypeTag::Frame) {
        if (auto* fd = std::get_if<FrameType>(&underlying_type->extra)) {
            auto it = frame_declarations.find(fd->name);
            if (it != frame_declarations.end()) {
                frame_declarations[type_decl->name] = it->second;
                if (!current_module_name.empty()) {
                    frame_declarations[current_module_name + "." + type_decl->name] = it->second;
                }
            }
        }
    }
    
    // Set the inferred type on the type declaration statement
    type_decl->inferred_type = underlying_type;
    
    return underlying_type;
}

TypePtr TypeChecker::check_module_declaration(std::shared_ptr<LM::Frontend::AST::ModuleDeclaration> module_decl) {
    if (!module_decl) return nullptr;

    // Set current module name
    std::string prev_module = current_module_name;
    current_module_name = module_decl->name;


    // Inline members into the program's imported_symbols map
    for (const auto& member : module_decl->publicMembers) {
        std::string name;
        if (auto func = std::dynamic_pointer_cast<LM::Frontend::AST::FunctionDeclaration>(member)) name = func->name;
        else if (auto frame = std::dynamic_pointer_cast<LM::Frontend::AST::FrameDeclaration>(member)) name = frame->name;
        else if (auto var = std::dynamic_pointer_cast<LM::Frontend::AST::VarDeclaration>(member)) name = var->name;

        if (!name.empty()) {
            std::string qualified_name = module_decl->name + "." + name;
            current_program_->imported_symbols[qualified_name] = member;
            // Also inline with original name to allow direct access if not aliased?
            // The main.cpp resolveImports doesn't support aliasing yet, so it just prepends modDecl
            current_program_->imported_symbols[name] = member;
        }
    }

    current_module_name = prev_module;

    return type_system.NIL_TYPE;
}

TypePtr TypeChecker::check_enum_declaration(std::shared_ptr<LM::Frontend::AST::EnumDeclaration> enum_decl) {
    if (!enum_decl) return nullptr;

    if (enum_decl->hasExplicitVisibility) {
        add_error("`enum` declarations cannot have a visibility modifier (`enum` is already public by default)", enum_decl->line);
    }

    // Create or get the base enum type
    TypePtr enumType = type_system.getType(enum_decl->name);
    if (!enumType || enumType->tag == TypeTag::Nil) {
        EnumType enumTypeInfo;
        enumTypeInfo.name = enum_decl->name;
        for (const auto& variant : enum_decl->variants) {
            std::vector<TypePtr> associated;
            for (const auto& t : variant.second) associated.push_back(resolve_type_annotation(t));
            enumTypeInfo.addVariant(variant.first, associated);
        }
        enumType = std::make_shared<::Type>(TypeTag::Enum, enumTypeInfo);
        type_system.addUserDefinedType(enum_decl->name, enumType);
    } else {
        // Replace existing enum type with complete one (from Pass -1)
        EnumType enumTypeInfo;
        enumTypeInfo.name = enum_decl->name;
        for (const auto& variant : enum_decl->variants) {
            std::vector<TypePtr> associated;
            for (const auto& t : variant.second) associated.push_back(resolve_type_annotation(t));
            enumTypeInfo.addVariant(variant.first, associated);
        }
        enumType = std::make_shared<::Type>(TypeTag::Enum, enumTypeInfo);
        type_system.addUserDefinedType(enum_decl->name, enumType);
    }

    // Register variants (qualified only) in global maps
    for (const auto& variant : enum_decl->variants) {
        const std::string& variantName = variant.first;
        const auto& associatedTypes = variant.second;
        std::string qualified = enum_decl->name + "." + variantName;

        if (associatedTypes.empty()) {
            // Unit variant
            variable_types[qualified] = enumType;
            variable_types[variantName] = enumType; // Also register unqualified

            FunctionSignature sig;
            sig.name = variantName;
            sig.return_type = enumType;
            function_signatures[qualified] = sig;
        } else {
            // Variant with associated values - functions as a constructor
            std::vector<TypePtr> paramTypes;
            for (const auto& astType : associatedTypes) {
                paramTypes.push_back(resolve_type_annotation(astType));
            }

            TypePtr constructorType = type_system.createFunctionType(paramTypes, enumType);
            variable_types[qualified] = constructorType;
            variable_types[variantName] = constructorType; // Also register unqualified

            FunctionSignature sig;
            sig.name = variantName;
            sig.param_types = paramTypes;
            sig.return_type = enumType;
            function_signatures[qualified] = sig;

            // Also register as a type if it's a single associated type (for sum-type like behavior)
            if (paramTypes.size() == 1) {
                type_system.registerType(variantName, constructorType);
            }
        }
    }

    enum_decl->inferred_type = enumType;
    return enumType;
}

TypePtr TypeChecker::check_block_statement(std::shared_ptr<LM::Frontend::AST::BlockStatement> block) {
    if (!block) return nullptr;
    
    enter_scope();
    
    TypePtr last_type = nullptr;
    for (const auto& stmt : block->statements) {
        last_type = check_statement(stmt);
    }
    
    exit_scope();
    
    // Set the inferred type on the block statement
    block->inferred_type = last_type;
    
    return last_type;
}

TypePtr TypeChecker::check_if_statement(std::shared_ptr<LM::Frontend::AST::IfStatement> if_stmt) {
    if (!if_stmt) return nullptr;
    
    // Check condition
    TypePtr condition_type = check_expression(if_stmt->condition);
    if (!is_boolean_type(condition_type)) {
        add_type_error("bool", condition_type->toString(), if_stmt->condition->line);
    }
    
    check_statement(if_stmt->thenBranch);
    if (if_stmt->elseBranch) check_statement(if_stmt->elseBranch);

    // Set the inferred type on the if statement
    TypePtr result_type = type_system.NIL_TYPE; // if statements don't produce a value
    if_stmt->inferred_type = result_type;
    
    return result_type;
}

TypePtr TypeChecker::check_while_statement(std::shared_ptr<LM::Frontend::AST::WhileStatement> while_stmt) {
    if (!while_stmt) return nullptr;
    
    // Check condition
    TypePtr condition_type = check_expression(while_stmt->condition);
    if (!is_boolean_type(condition_type)) {
        add_type_error("bool", condition_type->toString(), while_stmt->condition->line);
    }
    
    // Check body
    bool was_in_loop = in_loop;
    in_loop = true;
    
    // NEW: Phase 2 - Control flow safety
    // Validate scope cleanup on loop entry
    
    check_statement(while_stmt->body);
    
    // NEW: Phase 2 - Control flow safety
    // Validate cleanup on loop exit
    
    in_loop = was_in_loop;
    
    // Set the inferred type on the while statement
    TypePtr result_type = type_system.NIL_TYPE;
    while_stmt->inferred_type = result_type;
    
    return result_type;
}

TypePtr TypeChecker::check_for_statement(std::shared_ptr<LM::Frontend::AST::ForStatement> for_stmt) {
    if (!for_stmt) return nullptr;
    
    enter_scope();
    
    // Check initializer
    if (for_stmt->initializer) {
        check_statement(for_stmt->initializer);
    }
    
    // Check condition
    if (for_stmt->condition) {
        TypePtr condition_type = check_expression(for_stmt->condition);
        if (!is_boolean_type(condition_type)) {
            add_type_error("bool", condition_type->toString(), for_stmt->condition->line);
        }
    }
    
    // Check increment
    if (for_stmt->increment) {
        check_expression(for_stmt->increment);
    }
    
    // Check body
    bool was_in_loop = in_loop;
    in_loop = true;
    
    // NEW: Phase 2 - Control flow safety
    // Validate scope cleanup on loop entry
    
    check_statement(for_stmt->body);
    
    // NEW: Phase 2 - Control flow safety
    // Validate cleanup on loop exit
    
    in_loop = was_in_loop;
    
    exit_scope();
    
    // Set the inferred type on the for statement
    TypePtr result_type = type_system.NIL_TYPE;
    for_stmt->inferred_type = result_type;
    
    return result_type;
}

TypePtr TypeChecker::check_iter_statement(std::shared_ptr<LM::Frontend::AST::IterStatement> iter_stmt) {
    if (!iter_stmt) return nullptr;

    // Type-check the iterable expression
    TypePtr iterable_type = check_expression(iter_stmt->iterable);

    // Infer element type(s) from the iterable's inferred type.
    // For lists/ranges/channels there is a single element type; for dicts we
    // can produce a (key, value) pair when two loop variables are bound.
    TypePtr key_type = type_system.ANY_TYPE;
    TypePtr value_type = type_system.ANY_TYPE;
    TypePtr element_type = type_system.ANY_TYPE;
    bool recognized = false;

    if (iterable_type) {
        switch (iterable_type->tag) {
            case TypeTag::List:
                element_type = type_system.getContainerElementType(iterable_type);
                key_type = element_type;
                recognized = true;
                break;
            case TypeTag::String:
                element_type = type_system.INT64_TYPE;
                key_type = element_type;
                recognized = true;
                break;
            case TypeTag::Dict: {
                auto kv = type_system.getDictTypes(iterable_type);
                key_type = kv.first;
                value_type = kv.second;
                element_type = key_type;
                recognized = true;
                break;
            }
            case TypeTag::Range:
                element_type = type_system.INT64_TYPE;
                key_type = element_type;
                recognized = true;
                break;
            case TypeTag::Channel:
                // Channels currently carry no typed element info; default to any.
                element_type = type_system.ANY_TYPE;
                key_type = element_type;
                recognized = true;
                break;
            case TypeTag::Any:
                // Untyped iterable; bind loop vars to any without erroring.
                recognized = true;
                break;
            default:
                recognized = false;
                break;
        }
    }

    if (!recognized) {
        std::string type_name = iterable_type ? iterable_type->toString() : std::string("unknown");
        add_error("Cannot iterate over type " + type_name, iter_stmt->line);
    }

    // Push a scope and bind the loop variable(s).
    enter_scope();

    if (iter_stmt->loopVars.size() == 1) {
        // For a single loop var: lists/ranges/channels bind to the element type;
        // dicts bind to the key type per task spec.
        declare_variable(iter_stmt->loopVars[0], element_type);
    } else if (iter_stmt->loopVars.size() == 2) {
        // Two loop vars: (key, value). For non-dict iterables the second var
        // gets any type as a fallback.
        declare_variable(iter_stmt->loopVars[0], key_type);
        declare_variable(iter_stmt->loopVars[1], value_type);
    } else if (!iter_stmt->loopVars.empty()) {
        // Defensive: bind all loop vars to any.
        for (const auto& var_name : iter_stmt->loopVars) {
            declare_variable(var_name, type_system.ANY_TYPE);
        }
    }

    // Type-check the body in the loop scope.
    bool was_in_loop = in_loop;
    in_loop = true;
    
    // NEW: Phase 2 - Control flow safety
    if (iter_stmt->loopVars.size() > 0) {
    }
    
    // Validate scope cleanup on loop entry
    
    check_statement(iter_stmt->body);
    
    // Validate cleanup on loop exit
    
    in_loop = was_in_loop;

    exit_scope();

    // iter statements do not produce a value.
    TypePtr result_type = type_system.NIL_TYPE;
    iter_stmt->inferred_type = result_type;

    return result_type;
}

TypePtr TypeChecker::check_parallel_statement(std::shared_ptr<LM::Frontend::AST::ParallelStatement> parallel_stmt) {
    if (!parallel_stmt) return nullptr;
    
    enter_scope();
    // Parallel blocks have direct access to outer values subject to the
    // capability analysis performed by the memory checker.
    // For type checking, we check the body normally
    if (parallel_stmt->body) {
        check_statement(parallel_stmt->body);
    }
    exit_scope();
    
    parallel_stmt->inferred_type = type_system.NIL_TYPE;
    return type_system.NIL_TYPE;
}

TypePtr TypeChecker::check_concurrent_statement(std::shared_ptr<LM::Frontend::AST::ConcurrentStatement> concurrent_stmt) {
    if (!concurrent_stmt) return nullptr;
    
    enter_scope();
    
    // Declare channel if present
    if (!concurrent_stmt->channel.empty()) {
        declare_variable(concurrent_stmt->channel, type_system.CHANNEL_TYPE);
    }
    
    // Check body
    if (concurrent_stmt->body) {
        check_statement(concurrent_stmt->body);
    }
    
    exit_scope();
    
    concurrent_stmt->inferred_type = type_system.NIL_TYPE;
    return type_system.NIL_TYPE;
}

TypePtr TypeChecker::check_task_statement(std::shared_ptr<LM::Frontend::AST::TaskStatement> task_stmt) {
    if (!task_stmt) return nullptr;
    
    enter_scope();
    
    // Check iterable
    TypePtr element_type = type_system.ANY_TYPE;
    if (task_stmt->iterable) {
        TypePtr iterable_type = check_expression(task_stmt->iterable);
        if (iterable_type && iterable_type->tag == TypeTag::List)
            element_type = type_system.getContainerElementType(iterable_type);
        else if (iterable_type && iterable_type->tag == TypeTag::Range)
            element_type = type_system.INT64_TYPE;
    }
    
    // Bind loop variable
    if (!task_stmt->loopVar.empty()) {
        declare_variable(task_stmt->loopVar, element_type);
    }
    
    // Check body
    if (task_stmt->body) {
        check_statement(task_stmt->body);
    }
    
    exit_scope();
    
    task_stmt->inferred_type = type_system.NIL_TYPE;
    return type_system.NIL_TYPE;
}

TypePtr TypeChecker::check_worker_statement(std::shared_ptr<LM::Frontend::AST::WorkerStatement> worker_stmt) {
    if (!worker_stmt) return nullptr;
    
    enter_scope();
    
    // Check iterable
    TypePtr element_type = type_system.ANY_TYPE;
    if (worker_stmt->iterable) {
        TypePtr iterable_type = check_expression(worker_stmt->iterable);
        if (iterable_type && iterable_type->tag == TypeTag::List)
            element_type = type_system.getContainerElementType(iterable_type);
        else if (iterable_type && iterable_type->tag == TypeTag::Range)
            element_type = type_system.INT64_TYPE;
    }
    
    // Bind parameter
    if (!worker_stmt->paramName.empty()) {
        declare_variable(worker_stmt->paramName, element_type);
    }
    
    // Check body
    if (worker_stmt->body) {
        check_statement(worker_stmt->body);
    }
    
    exit_scope();
    
    worker_stmt->inferred_type = type_system.NIL_TYPE;
    return type_system.NIL_TYPE;
}

TypePtr TypeChecker::check_return_statement(std::shared_ptr<LM::Frontend::AST::ReturnStatement> return_stmt) {
    if (!return_stmt) return nullptr;
    
    if (!current_return_type) {
        add_error("return statement not allowed at global scope", return_stmt->line);
        return type_system.NIL_TYPE;
    }

    TypePtr return_type = nullptr;
    if (return_stmt->value) {
        return_type = check_expression(return_stmt->value);
        if (!return_type) return nullptr;
        
        // Auto-wrap in ok() if function returns error union type and value is not already wrapped
        if (current_return_type && type_system.isFallibleType(current_return_type)) {
            // Check if the return value is already an error construct or ok construct
            bool is_already_wrapped = false;
            if (auto error_construct = std::dynamic_pointer_cast<LM::Frontend::AST::ErrorConstructExpr>(return_stmt->value)) {
                is_already_wrapped = true;
            } else if (auto ok_construct = std::dynamic_pointer_cast<LM::Frontend::AST::OkConstructExpr>(return_stmt->value)) {
                is_already_wrapped = true;
            } else if (type_system.isFallibleType(return_type)) {
                is_already_wrapped = true;
            } else if (return_type->tag == TypeTag::Nil) {
                is_already_wrapped = true;
            }
            
            if (!is_already_wrapped) {
                // Get the expected success type from the function's return type
                TypePtr expected_success_type = type_system.getFallibleSuccessType(current_return_type);
                
                if (expected_success_type && is_type_compatible(expected_success_type, return_type)) {
                    // Automatically wrap the return value in ok()
                    auto ok_construct = std::make_shared<LM::Frontend::AST::OkConstructExpr>();
                    ok_construct->value = return_stmt->value;
                    ok_construct->line = return_stmt->line;
                    ok_construct->inferred_type = current_return_type;
                    
                    // Replace the return statement's value with the ok construct
                    return_stmt->value = ok_construct;
                    return_type = current_return_type;
                } else {
                    add_type_error(expected_success_type ? expected_success_type->toString() : "unknown", 
                                 return_type->toString(), return_stmt->line);
                }
            }
        }
    } else {
        return_type = type_system.NIL_TYPE;
    }
    
    // Closure captures are fully supported when returning lambdas.

    // Check if return type matches function return type
    if (current_return_type && !is_type_compatible(current_return_type, return_type)) {
        add_type_error(current_return_type->toString(), return_type->toString(), return_stmt->line);
    }
    
    // Set the inferred type on the return statement
    return_stmt->inferred_type = return_type;
    
    return return_type;
}

TypePtr TypeChecker::check_range_expr(std::shared_ptr<LM::Frontend::AST::RangeExpr> expr) {
    if (!expr) return nullptr;
    TypePtr startType = check_expression(expr->start);
    TypePtr endType = check_expression(expr->end);
    if (!is_numeric_type(startType)) add_type_error("numeric", startType->toString(), expr->line);
    if (!is_numeric_type(endType)) add_type_error("numeric", endType->toString(), expr->line);
    if (expr->step) {
        TypePtr stepType = check_expression(expr->step);
        if (!is_numeric_type(stepType)) add_type_error("numeric", stepType->toString(), expr->line);
    }
    TypePtr rangeType = std::make_shared<::Type>(TypeTag::Range);
    expr->inferred_type = rangeType;
    return rangeType;
}

TypePtr TypeChecker::check_staged_statement(std::shared_ptr<LM::Frontend::AST::StagedStatement> staged_stmt) {
    if (!staged_stmt) return type_system.NIL_TYPE;

    if (staged_stmt->declaration) {
        return check_statement(staged_stmt->declaration);
    } else if (staged_stmt->block) {
        auto eval_block = evaluate_staged_statement_node(staged_stmt->block, 0);
        return check_statement(eval_block);
    } else if (staged_stmt->expression) {
        auto eval_expr = evaluate_staged_expression(staged_stmt->expression, 0);
        return check_expression(eval_expr);
    }
    return type_system.NIL_TYPE;
}

TypePtr TypeChecker::check_staged_block_statement(std::shared_ptr<LM::Frontend::AST::StagedBlockStatement> staged_block) {
    if (!staged_block || !staged_block->body) return type_system.NIL_TYPE;

    auto eval_node = evaluate_staged_statement_node(staged_block->body, 0);
    return check_statement(eval_node);
}

std::shared_ptr<LM::Frontend::AST::Statement> TypeChecker::evaluate_staged_statement_node(std::shared_ptr<LM::Frontend::AST::Statement> stmt, size_t depth) {
    static const size_t MAX_RECURSION_DEPTH = 1000;
    if (depth > MAX_RECURSION_DEPTH) {
        add_error("staged evaluation error: maximum recursion depth (1000) exceeded", stmt ? stmt->line : 0);
        return stmt;
    }
    if (!stmt) return nullptr;

    if (auto block = std::dynamic_pointer_cast<LM::Frontend::AST::BlockStatement>(stmt)) {
        std::vector<std::shared_ptr<LM::Frontend::AST::Statement>> new_stmts;
        for (auto& s : block->statements) {
            auto eval_s = evaluate_staged_statement_node(s, depth + 1);
            if (eval_s) new_stmts.push_back(eval_s);
        }
        block->statements = new_stmts;
        return block;
    }

    if (auto if_stmt = std::dynamic_pointer_cast<LM::Frontend::AST::IfStatement>(stmt)) {
        auto eval_cond = evaluate_staged_expression(if_stmt->condition, depth + 1);
        long long val_int = 0;
        double val_double = 0.0;
        bool is_int = false;
        if (evaluate_const_expr(eval_cond, val_int, val_double, is_int, this)) {
            bool cond_true = is_int ? (val_int != 0) : (val_double != 0.0);
            if (cond_true) {
                return evaluate_staged_statement_node(if_stmt->thenBranch, depth + 1);
            } else {
                if (if_stmt->elseBranch) {
                    return evaluate_staged_statement_node(if_stmt->elseBranch, depth + 1);
                } else {
                    auto empty = std::make_shared<LM::Frontend::AST::ExprStatement>();
                    empty->line = if_stmt->line;
                    return empty;
                }
            }
        }
        if_stmt->condition = eval_cond;
        if_stmt->thenBranch = evaluate_staged_statement_node(if_stmt->thenBranch, depth + 1);
        if (if_stmt->elseBranch) {
            if_stmt->elseBranch = evaluate_staged_statement_node(if_stmt->elseBranch, depth + 1);
        }
        return if_stmt;
    }

    if (auto var_decl = std::dynamic_pointer_cast<LM::Frontend::AST::VarDeclaration>(stmt)) {
        if (var_decl->initializer) {
            var_decl->initializer = evaluate_staged_expression(var_decl->initializer, depth + 1);
        }
        return var_decl;
    }

    if (auto expr_stmt = std::dynamic_pointer_cast<LM::Frontend::AST::ExprStatement>(stmt)) {
        if (expr_stmt->expression) {
            expr_stmt->expression = evaluate_staged_expression(expr_stmt->expression, depth + 1);
        }
        return expr_stmt;
    }

    return stmt;
}

} // namespace Frontend
} // namespace LM
